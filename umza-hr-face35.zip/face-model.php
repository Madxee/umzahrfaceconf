<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Delivers the face recognition model files (libs/face-api/model/*.json, *.bin).
 *
 * Some hosts refuse direct downloads of .json/.bin files (403 Forbidden).
 * Serving them through PHP avoids that. Usage: face-model.php/<file name>
 */

$name = '';
if (!empty($_SERVER['PATH_INFO'])) {
    $name = basename($_SERVER['PATH_INFO']);
} elseif (!empty($_GET['f'])) {
    $name = basename($_GET['f']);
} else {
    // Some servers do not set PATH_INFO: read it from the request address
    $uri = strtok($_SERVER['REQUEST_URI'] ?? '', '?');
    $pos = strpos($uri, 'face-model.php/');
    if ($pos !== false) {
        $name = basename(substr($uri, $pos + strlen('face-model.php/')));
    }
}

if (!preg_match('/^[a-z0-9_\-]+\.(json|bin)$/i', $name)) {
    http_response_code(400);
    exit('Bad request');
}
$file = __DIR__ . '/libs/face-api/model/' . $name;
if (!is_file($file) || !is_readable($file)) {
    http_response_code(404);
    exit('Model file not found: ' . $name . ' (upload the folder libs/face-api/model)');
}

while (ob_get_level()) {
    ob_end_clean();
}
header('Content-Type: ' . (str_ends_with($name, '.json') ? 'application/json' : 'application/octet-stream'));
header('Content-Length: ' . filesize($file));
header('Cache-Control: public, max-age=2592000');
header('X-Content-Type-Options: nosniff');
readfile($file);
