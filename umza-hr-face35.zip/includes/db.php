<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Database connection using PDO and settings helper
 */

require_once __DIR__ . '/config.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    $pdo->exec("SET time_zone = '+01:00'");
} catch (PDOException $e) {
    error_log("Database Connection Failed: " . $e->getMessage());
    http_response_code(500);
    die("Database connection failed. Please check the database settings in includes/config.php.");
}

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/migrations.php';

// Apply any pending, non-destructive database upgrades (runs once per version)
try {
    run_migrations($pdo);
} catch (PDOException $e) {
    error_log('Database upgrade error: ' . $e->getMessage());
}

/**
 * Fetch a setting value by key from settings table
 */
function get_setting($key, $default = '') {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT `setting_value` FROM `settings` WHERE `setting_key` = ?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

/**
 * Log user activity (Audit Trail)
 */
function log_activity($user_id, $action, $details = '') {
    global $pdo;
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        
        $stmt = $pdo->prepare("INSERT INTO `activity_logs` (`user_id`, `action`, `details`, `ip_address`, `user_agent`) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $action, $details, $ip, $ua]);
    } catch (PDOException $e) {
        // Fail silently to avoid breaking major operations if logging fails
    }
}

/**
 * Add a notification for a staff member
 */
function add_notification($staff_id, $title, $message) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO `notifications` (`staff_id`, `title`, `message`, `is_read`) VALUES (?, ?, ?, 0)");
        $stmt->execute([$staff_id, $title, $message]);
    } catch (PDOException $e) {
        // Fail silently
    }
}
