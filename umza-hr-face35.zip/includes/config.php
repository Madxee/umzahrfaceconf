<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * System Configuration
 */

// Enable output buffering to prevent "headers already sent" redirect issues
ob_start();

// Error Reporting (Log to server, do not print to screen to prevent redirect crashes)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Time zone (Nigeria - West Africa Time)
date_default_timezone_set('Africa/Lagos');

// Optional local override file (not required). Create includes/config.local.php
// with define('DB_HOST', ...) etc. to override the values below.
if (file_exists(__DIR__ . '/config.local.php')) {
    require_once __DIR__ . '/config.local.php';
}

// Environment variable overrides (useful for testing / Docker)
foreach (['DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME'] as $__k) {
    if (!defined($__k) && getenv('UMZA_' . $__k) !== false) {
        define($__k, getenv('UMZA_' . $__k));
    }
}

// Database Configuration (Dynamic Detection for Localhost vs Production cPanel)
$__is_local = (php_sapi_name() === 'cli' && strtoupper(substr(PHP_OS, 0, 3)) === 'WIN')
    || (isset($_SERVER['HTTP_HOST']) && ($_SERVER['HTTP_HOST'] === 'localhost' || $_SERVER['HTTP_HOST'] === '127.0.0.1' || str_starts_with($_SERVER['HTTP_HOST'], 'localhost:') || str_starts_with($_SERVER['HTTP_HOST'], '127.0.0.1:')));
if ($__is_local) {
    defined('DB_HOST') || define('DB_HOST', 'localhost');
    defined('DB_USER') || define('DB_USER', 'root');
    defined('DB_PASS') || define('DB_PASS', '');
    defined('DB_NAME') || define('DB_NAME', 'umza_hr');
} else {
    defined('DB_HOST') || define('DB_HOST', 'localhost');
    defined('DB_USER') || define('DB_USER', 'madzeedi_hrumza');
    defined('DB_PASS') || define('DB_PASS', 'Madzee44225@');
    defined('DB_NAME') || define('DB_NAME', 'madzeedi_hrumza');
}

// Security Configurations
define('SESSION_LIFETIME', 3600); // 1 Hour session lifetime
define('UPLOAD_MAX_SIZE', 5242880); // 5MB Upload limit
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp', 'pdf', 'doc', 'docx']);
define('ALLOWED_MIMES', [
    'image/jpeg',
    'image/png',
    'image/webp',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
]);

// Base Path Definition
define('BASE_PATH', dirname(__DIR__));
define('UPLOAD_PATH', BASE_PATH . DIRECTORY_SEPARATOR . 'uploads');

// Start Secure Session
function secure_session_start() {
    if (session_status() == PHP_SESSION_NONE) {
        // Force session cookies to be HTTP-only
        ini_set('session.cookie_httponly', 1);
        
        // Force session cookies to be Secure if using HTTPS
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            ini_set('session.cookie_secure', 1);
        }
        
        // Use cookies only for session handling
        ini_set('session.use_only_cookies', 1);
        
        session_start();
    }
}

/**
 * Returns a unique version identifier for assets to bypass browser cache
 */
function get_asset_version($file_relative_path) {
    $full_path = BASE_PATH . '/' . ltrim($file_relative_path, '/');
    if (file_exists($full_path)) {
        return filemtime($full_path);
    }
    return '3.0'; // Fallback
}
