<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Automatic, non-destructive database upgrades.
 *
 * Runs once per version bump (tracked in settings.schema_version). It only
 * ever CREATEs missing tables/columns and INSERTs missing settings, so it is
 * safe to run on the live database: no data is deleted or truncated.
 */

const UMZA_SCHEMA_VERSION = 10;

function db_table_exists(PDO $pdo, $table) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

function db_column_exists(PDO $pdo, $table, $column) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->execute([$table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function db_add_column(PDO $pdo, $table, $column, $definition) {
    if (db_table_exists($pdo, $table) && !db_column_exists($pdo, $table, $column)) {
        $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    }
}

/** Import schema.sql into an empty database (first-time install). */
function db_install_base_schema(PDO $pdo) {
    $file = BASE_PATH . '/schema.sql';
    if (!file_exists($file)) {
        return;
    }
    $sql = file_get_contents($file);
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    foreach (array_filter(array_map('trim', explode(";\n", $sql))) as $statement) {
        $pdo->exec($statement);
    }
}

function run_migrations(PDO $pdo) {
    if (!db_table_exists($pdo, 'staff')) {
        db_install_base_schema($pdo);
    }

    $current = 0;
    try {
        $current = (int)$pdo->query("SELECT `setting_value` FROM `settings` WHERE `setting_key` = 'schema_version'")->fetchColumn();
    } catch (PDOException $e) {
        $current = 0;
    }
    if ($current >= UMZA_SCHEMA_VERSION) {
        return;
    }

    // Only one request should upgrade at a time
    $got_lock = (int)$pdo->query("SELECT GET_LOCK('umza_migrate', 10)")->fetchColumn();
    if (!$got_lock) {
        return;
    }

    try {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

        // ---- Roles ----
        $pdo->exec("ALTER TABLE `staff` MODIFY COLUMN `role` ENUM('Super Admin','Managing Director','HR Director','HR Manager','HR Officer','Department Head','Finance Officer','Staff') DEFAULT 'Staff'");

        // ---- Staff names: other name + chosen display name ----
        db_add_column($pdo, 'staff', 'other_name', "VARCHAR(50) DEFAULT NULL AFTER `first_name`");
        db_add_column($pdo, 'staff', 'name_display_format', "VARCHAR(30) NOT NULL DEFAULT 'first_last' AFTER `last_name`");
        db_add_column($pdo, 'staff', 'display_name', "VARCHAR(160) DEFAULT NULL AFTER `name_display_format`");
        db_add_column($pdo, 'staff', 'blood_group', "VARCHAR(10) DEFAULT NULL");
        db_add_column($pdo, 'staff', 'allergies', "VARCHAR(255) DEFAULT 'N/A'");
        db_add_column($pdo, 'staff', 'verification_sent_at', "DATETIME DEFAULT NULL");

        // ---- Departments & positions management ----
        db_add_column($pdo, 'departments', 'description', "VARCHAR(255) DEFAULT NULL");
        db_add_column($pdo, 'departments', 'head_staff_id', "INT DEFAULT NULL");
        db_add_column($pdo, 'positions', 'is_active', "TINYINT(1) NOT NULL DEFAULT 1");

        // ---- Memos: audience (all staff or one department) ----
        db_add_column($pdo, 'memos', 'audience', "VARCHAR(20) NOT NULL DEFAULT 'All'");
        db_add_column($pdo, 'memos', 'department_id', "INT DEFAULT NULL");
        db_add_column($pdo, 'memos', 'emails_sent', "INT NOT NULL DEFAULT 0");
        $pdo->exec("ALTER TABLE `memos` MODIFY COLUMN `type` VARCHAR(50) NOT NULL");

        // ---- Tables originally created by update_schema.php ----
        $pdo->exec("CREATE TABLE IF NOT EXISTS `shifts` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `start_time` TIME NOT NULL,
            `end_time` TIME NOT NULL,
            `description` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `attendance` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `staff_id` INT NOT NULL,
            `date` DATE NOT NULL,
            `clock_in` TIME DEFAULT NULL,
            `clock_out` TIME DEFAULT NULL,
            `shift_id` INT DEFAULT NULL,
            `status` ENUM('Present','Late','Absent','Half Day') DEFAULT 'Present',
            `overtime_hours` DECIMAL(4,2) DEFAULT 0.00,
            `ip_address` VARCHAR(45) DEFAULT NULL,
            `notes` TEXT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE,
            FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL,
            UNIQUE KEY `staff_date` (`staff_id`, `date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        // Face capture photos for attendance
        db_add_column($pdo, 'attendance', 'clock_in_photo', "VARCHAR(255) DEFAULT NULL");
        db_add_column($pdo, 'attendance', 'clock_out_photo', "VARCHAR(255) DEFAULT NULL");

        $simple_tables = [
            'qualifications' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `institution` VARCHAR(150) NOT NULL, `qualification_name` VARCHAR(150) NOT NULL, `field_of_study` VARCHAR(100) DEFAULT NULL, `year_obtained` INT NOT NULL, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'employment_history' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `company_name` VARCHAR(150) NOT NULL, `position` VARCHAR(100) NOT NULL, `start_date` DATE NOT NULL, `end_date` DATE DEFAULT NULL, `responsibilities` TEXT DEFAULT NULL, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'asset_assignments' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `asset_name` VARCHAR(150) NOT NULL, `asset_code` VARCHAR(100) UNIQUE NOT NULL, `category` VARCHAR(100) DEFAULT NULL, `serial_number` VARCHAR(100) DEFAULT NULL, `assigned_date` DATE NOT NULL, `returned_date` DATE DEFAULT NULL, `status` ENUM('Assigned','Returned','Damaged','Lost') DEFAULT 'Assigned', `remarks` TEXT DEFAULT NULL, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'department_transfers' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `from_department_id` INT DEFAULT NULL, `to_department_id` INT NOT NULL, `transfer_date` DATE NOT NULL, `reason` TEXT DEFAULT NULL, `approved_by` INT DEFAULT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'exit_records' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL UNIQUE, `exit_date` DATE NOT NULL, `exit_type` ENUM('Resigned','Terminated','Retired','Deceased') NOT NULL, `reason` TEXT DEFAULT NULL, `clearance_status` ENUM('Pending','Cleared','Rejected') DEFAULT 'Pending', `remarks` TEXT DEFAULT NULL, `processed_by` INT DEFAULT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'vacancies' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `title` VARCHAR(150) NOT NULL, `department_id` INT NOT NULL, `description` TEXT NOT NULL, `requirements` TEXT DEFAULT NULL, `status` ENUM('Open','Closed') DEFAULT 'Open', `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
            'job_applications' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `vacancy_id` INT NOT NULL, `full_name` VARCHAR(150) NOT NULL, `email` VARCHAR(150) NOT NULL, `phone` VARCHAR(30) NOT NULL, `resume_path` VARCHAR(255) NOT NULL, `cover_letter` TEXT DEFAULT NULL, `status` ENUM('Applied','Shortlisted','Interviewing','Offered','Rejected') DEFAULT 'Applied', `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`vacancy_id`) REFERENCES `vacancies`(`id`) ON DELETE CASCADE",
            'interviews' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `application_id` INT NOT NULL, `interview_date` DATETIME NOT NULL, `interviewer_id` INT DEFAULT NULL, `mode` ENUM('Online','In-Person') DEFAULT 'Online', `remarks` TEXT DEFAULT NULL, `status` ENUM('Scheduled','Completed','Cancelled') DEFAULT 'Scheduled', `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`application_id`) REFERENCES `job_applications`(`id`) ON DELETE CASCADE",
            'training_programs' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `name` VARCHAR(150) NOT NULL, `description` TEXT DEFAULT NULL, `category` ENUM('Aviation','Safety','Cabin Crew','Ground Staff','Pilot Certification','General') NOT NULL, `validity_months` INT DEFAULT 12, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
            'staff_trainings' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `training_program_id` INT NOT NULL, `completion_date` DATE NOT NULL, `expiry_date` DATE DEFAULT NULL, `certificate_path` VARCHAR(255) DEFAULT NULL, `status` ENUM('Passed','Failed','Expired') DEFAULT 'Passed', `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE, FOREIGN KEY (`training_program_id`) REFERENCES `training_programs`(`id`) ON DELETE CASCADE",
            'staff_letters' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `letter_type` ENUM('Employment Letter','Promotion Letter','Confirmation Letter','Query Letter','Warning Letter','Leave Approval Letter','Salary Letter','Experience Letter') NOT NULL, `title` VARCHAR(255) NOT NULL, `content` TEXT NOT NULL, `created_by` INT DEFAULT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'aviation_records' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL UNIQUE, `license_number` VARCHAR(100) DEFAULT NULL, `license_type` ENUM('ATPL','CPL','PPL','Cabin Crew Licence','Dispatcher Licence','Other') DEFAULT NULL, `license_expiry` DATE DEFAULT NULL, `medical_class` ENUM('Class 1','Class 2','Class 3') DEFAULT NULL, `medical_expiry` DATE DEFAULT NULL, `passport_number` VARCHAR(100) DEFAULT NULL, `passport_expiry` DATE DEFAULT NULL, `visa_details` VARCHAR(255) DEFAULT NULL, `visa_expiry` DATE DEFAULT NULL, `airport_access_card_no` VARCHAR(100) DEFAULT NULL, `airport_access_card_expiry` DATE DEFAULT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'flight_schedules' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `flight_number` VARCHAR(50) NOT NULL, `departure_airport` VARCHAR(10) NOT NULL, `arrival_airport` VARCHAR(10) NOT NULL, `departure_time` DATETIME NOT NULL, `arrival_time` DATETIME NOT NULL, `role_on_flight` VARCHAR(100) DEFAULT NULL, `status` ENUM('Scheduled','Completed','Delayed','Cancelled') DEFAULT 'Scheduled', `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'uniform_issuance' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `item_name` VARCHAR(150) NOT NULL, `size` VARCHAR(20) NOT NULL, `quantity` INT NOT NULL DEFAULT 1, `issued_date` DATE NOT NULL, `status` ENUM('New','Replaced') DEFAULT 'New', `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            'kpi_tracking' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `staff_id` INT NOT NULL, `kpi_name` VARCHAR(150) NOT NULL, `target` VARCHAR(100) NOT NULL, `actual` VARCHAR(100) DEFAULT NULL, `score` INT DEFAULT NULL, `evaluation_date` DATE NOT NULL, `evaluator_id` INT DEFAULT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE",
            // New: admin-managed menu shortcuts and top-of-page announcements
            'custom_links' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `title` VARCHAR(100) NOT NULL, `url` VARCHAR(500) NOT NULL, `icon` VARCHAR(60) DEFAULT 'fa-solid fa-link', `audience` VARCHAR(20) NOT NULL DEFAULT 'All', `sort_order` INT NOT NULL DEFAULT 0, `is_active` TINYINT(1) NOT NULL DEFAULT 1, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
            'announcements' => "`id` INT AUTO_INCREMENT PRIMARY KEY, `message` VARCHAR(500) NOT NULL, `style` VARCHAR(20) NOT NULL DEFAULT 'info', `is_active` TINYINT(1) NOT NULL DEFAULT 1, `expires_on` DATE DEFAULT NULL, `created_by` INT DEFAULT NULL, `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP",
        ];
        foreach ($simple_tables as $name => $cols) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS `$name` ($cols) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        }

        // ---- GPS attendance locations (head office, airport stations, routes) ----
        $pdo->exec("CREATE TABLE IF NOT EXISTS `attendance_locations` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(150) NOT NULL,
            `type` VARCHAR(40) NOT NULL DEFAULT 'Airport Station',
            `code` VARCHAR(10) DEFAULT NULL,
            `city` VARCHAR(100) DEFAULT NULL,
            `latitude` DECIMAL(10,7) NOT NULL,
            `longitude` DECIMAL(10,7) NOT NULL,
            `radius_m` INT NOT NULL DEFAULT 300,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `verified` TINYINT(1) NOT NULL DEFAULT 0,
            `notes` VARCHAR(255) DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS `staff_locations` (
            `staff_id` INT NOT NULL,
            `location_id` INT NOT NULL,
            PRIMARY KEY (`staff_id`, `location_id`),
            FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`location_id`) REFERENCES `attendance_locations`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        foreach (['in', 'out'] as $w) {
            db_add_column($pdo, 'attendance', "clock_{$w}_location_id", "INT DEFAULT NULL");
            db_add_column($pdo, 'attendance', "clock_{$w}_lat", "DECIMAL(10,7) DEFAULT NULL");
            db_add_column($pdo, 'attendance', "clock_{$w}_lng", "DECIMAL(10,7) DEFAULT NULL");
            db_add_column($pdo, 'attendance', "clock_{$w}_accuracy", "INT DEFAULT NULL");
            db_add_column($pdo, 'attendance', "clock_{$w}_distance", "INT DEFAULT NULL");
            db_add_column($pdo, 'attendance', "clock_{$w}_face_score", "DECIMAL(5,3) DEFAULT NULL");
        }
        // ---- Face recognition reference (computed from the passport photo) ----
        db_add_column($pdo, 'staff', 'face_descriptor', "TEXT DEFAULT NULL");
        db_add_column($pdo, 'staff', 'face_descriptor_photo', "VARCHAR(255) DEFAULT NULL");
        db_add_column($pdo, 'staff', 'face_enrolled_by', "VARCHAR(20) DEFAULT NULL");
        db_add_column($pdo, 'staff', 'face_enrolled_at', "DATETIME DEFAULT NULL");

        if ((int)$pdo->query("SELECT COUNT(*) FROM `attendance_locations`")->fetchColumn() === 0) {
            $ins = $pdo->prepare("INSERT INTO `attendance_locations` (`name`,`type`,`code`,`city`,`latitude`,`longitude`,`radius_m`,`verified`,`notes`) VALUES (?,?,?,?,?,?,?,0,?)");
            $ins->execute(['UMZA Head Office (UYK Hexahub, Garki)', 'Head Office', 'HQ', 'Abuja', 9.0330000, 7.4890000, 200,
                'Approximate point - stand in the office and click "Use my current GPS" to set the exact spot.']);
            foreach (umza_default_airports() as $a) {
                $ins->execute([$a[0], 'Airport Station', $a[1], $a[2], $a[3], $a[4], 2000, 'Approximate airport position - check on the map and adjust.']);
            }
        }

        // ---- v9: face captured at registration, work station, MD approvals ----
        db_add_column($pdo, 'staff', 'face_source', "VARCHAR(20) DEFAULT NULL");
        db_add_column($pdo, 'staff', 'face_photo', "VARCHAR(255) DEFAULT NULL");
        $pdo->exec("UPDATE `staff` SET `face_source` = 'passport' WHERE `face_descriptor` IS NOT NULL AND `face_source` IS NULL");

        if (db_table_exists($pdo, 'staff_letters')) {
            $pdo->exec("ALTER TABLE `staff_letters` MODIFY COLUMN `letter_type` VARCHAR(60) NOT NULL");
            db_add_column($pdo, 'staff_letters', 'status', "VARCHAR(20) NOT NULL DEFAULT 'Approved'");
            db_add_column($pdo, 'staff_letters', 'requires_md', "TINYINT(1) NOT NULL DEFAULT 0");
            db_add_column($pdo, 'staff_letters', 'recipient_name', "VARCHAR(160) DEFAULT NULL");
            db_add_column($pdo, 'staff_letters', 'recipient_details', "VARCHAR(255) DEFAULT NULL");
            db_add_column($pdo, 'staff_letters', 'submitted_at', "DATETIME DEFAULT NULL");
            db_add_column($pdo, 'staff_letters', 'md_id', "INT DEFAULT NULL");
            db_add_column($pdo, 'staff_letters', 'md_decision_at', "DATETIME DEFAULT NULL");
            db_add_column($pdo, 'staff_letters', 'md_comment', "TEXT DEFAULT NULL");
            db_add_column($pdo, 'staff_letters', 'updated_at', "TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP");
        }
        db_add_column($pdo, 'memos', 'status', "VARCHAR(20) NOT NULL DEFAULT 'Published'");
        db_add_column($pdo, 'memos', 'md_id', "INT DEFAULT NULL");
        db_add_column($pdo, 'memos', 'md_decision_at', "DATETIME DEFAULT NULL");
        db_add_column($pdo, 'memos', 'md_comment', "TEXT DEFAULT NULL");

        // v10: stricter default face matching (only if the old default is still set)
        $pdo->exec("UPDATE `settings` SET `setting_value` = '0.45' WHERE `setting_key` = 'face_match_threshold' AND `setting_value` = '0.55'");

        // ---- Seed shifts and trainings if empty ----
        if ((int)$pdo->query("SELECT COUNT(*) FROM `shifts`")->fetchColumn() === 0) {
            $pdo->exec("INSERT INTO `shifts` (`name`,`start_time`,`end_time`,`description`) VALUES
                ('Flight Operations Shift A','06:00:00','14:00:00','Early morning flight deck and dispatch shift.'),
                ('Flight Operations Shift B','14:00:00','22:00:00','Afternoon/Evening flight operations.'),
                ('Flight Operations Shift C (Night)','22:00:00','06:00:00','Overnight flight and OCC monitoring.'),
                ('Ground Ramp Shift Morning','05:00:00','13:00:00','Ramp turnaround, passenger boarding services.'),
                ('Ground Ramp Shift Afternoon','13:00:00','21:00:00','Ground services, check-in, ramp operations.'),
                ('Standard Admin Day Shift','08:00:00','17:00:00','Corporate, finance and HR office hours.')");
        }
        if ((int)$pdo->query("SELECT COUNT(*) FROM `training_programs`")->fetchColumn() === 0) {
            $pdo->exec("INSERT INTO `training_programs` (`name`,`description`,`category`,`validity_months`) VALUES
                ('Aviation Safety Management System (SMS)','Induction in airline SMS, reporting and hazard identification.','Safety',24),
                ('Cabin Crew Firefighting & Smoke Training','Practical drill for cabin crew on onboard fire safety.','Cabin Crew',12),
                ('Dangerous Goods Regulations (DGR) Cat 6','Regulatory course for ground handlers and cargo officers.','Ground Staff',24),
                ('First Aid & Aviation Medicine','Basic medical emergency training for inflight emergencies.','General',12)");
        }

        // ---- Settings (only added when missing; existing values are kept) ----
        $defaults = [
            ['mail_driver', 'smtp', 'Email delivery: smtp (with automatic server mail fallback), mail (server sendmail only) or log (testing)'],
            ['mail_from_name', '', 'Name shown as the email sender (blank = company name)'],
            ['mail_reply_to', '', 'Optional reply-to address for portal emails'],
            ['require_attendance_photo', '1', 'Require a live face photo when clocking in/out (1 = yes, 0 = no)'],
            ['allowed_email_domain', '', 'Restrict self-registration to this email domain (blank = any)'],
            ['require_gps', '1', 'Staff must be inside an attendance location (GPS) to clock in/out'],
            ['gps_max_accuracy', '1000', 'Reject GPS readings less precise than this many metres'],
            ['require_face_match', '1', 'Live face must match the passport photo to clock in/out'],
            ['face_match_threshold', '0.45', 'Face match strictness (lower = stricter, 0.4-0.55)'],
            ['allow_self_face_enrol', '1', 'Let staff browsers build their face reference from the passport photo automatically'],
            ['letters_require_md', '1', 'HR letters must be approved by the Managing Director before staff can see them'],
            ['md_name', '', 'Managing Director name printed on approved letters'],
            ['md_title', 'Managing Director / CEO', 'Managing Director title printed on approved letters'],
            ['md_signature_image', '', 'Managing Director signature image'],
            ['require_station_at_registration', '1', 'New staff must choose their work station when registering'],
            ['auto_clock_after_match', '1', 'Clock in/out automatically once location and face are confirmed'],
        ];
        foreach (umza_feature_list() as $key => $f) {
            $defaults[] = ['feature_' . $key, '1', 'Feature switch: ' . $f['label']];
        }
        $ins = $pdo->prepare("INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES (?, ?, ?)");
        foreach ($defaults as $d) {
            $ins->execute($d);
        }

        // ---- Company contact details from the official letterhead (only if still the old defaults) ----
        $pdo->prepare("UPDATE `settings` SET `setting_value` = ? WHERE `setting_key` = 'company_address' AND `setting_value` = ?")
            ->execute(['Suite D1 UYK HEXAHUB, Plot 1077A Balanga Crescent, Off Uke Street, Area 11, Garki, Abuja',
                       'Suite D1, UYK HEXAHUB Building, Plot 1077A Balanga Cres, off Uke Street, Garki, AMAC 900110, Federal Capital Territory']);
        $pdo->prepare("UPDATE `settings` SET `setting_value` = ? WHERE `setting_key` = 'company_phone' AND `setting_value` = ?")
            ->execute(['+234 803 3475 657', '0704 700 0673']);

        // ---- Fill display names ----
        $pdo->exec("UPDATE `staff` SET `display_name` = TRIM(CONCAT(`first_name`, ' ', `last_name`)) WHERE `display_name` IS NULL OR `display_name` = ''");

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $pdo->prepare("INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES ('schema_version', ?, 'Database upgrade level (do not edit)')
                       ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)")->execute([UMZA_SCHEMA_VERSION]);
    } catch (PDOException $e) {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        error_log('UMZA migration failed: ' . $e->getMessage());
        throw $e;
    } finally {
        $pdo->query("SELECT RELEASE_LOCK('umza_migrate')");
    }
}


/** Main Nigerian airports used as default attendance stations (approximate coordinates). */
function umza_default_airports() {
    return [
        // name, IATA, city, latitude, longitude
        ['Nnamdi Azikiwe International Airport', 'ABV', 'Abuja', 9.0068000, 7.2632000],
        ['Murtala Muhammed International Airport', 'LOS', 'Lagos', 6.5774000, 3.3212000],
        ['Port Harcourt International Airport', 'PHC', 'Port Harcourt', 5.0155000, 6.9496000],
        ['Mallam Aminu Kano International Airport', 'KAN', 'Kano', 12.0476000, 8.5246000],
        ['Akanu Ibiam International Airport', 'ENU', 'Enugu', 6.4743000, 7.5620000],
        ['Kaduna International Airport', 'KAD', 'Kaduna', 10.6960000, 7.3201000],
        ['Sadiq Abubakar III International Airport', 'SKO', 'Sokoto', 12.9163000, 5.2072000],
        ['Maiduguri International Airport', 'MIU', 'Maiduguri', 11.8553000, 13.0809000],
        ['Yola Airport', 'YOL', 'Yola', 9.2576000, 12.4304000],
        ['Benin Airport', 'BNI', 'Benin City', 6.3170000, 5.5995000],
        ['Margaret Ekpo International Airport', 'CBQ', 'Calabar', 4.9760000, 8.3472000],
        ['Sam Mbakwe International Cargo Airport', 'QOW', 'Owerri', 5.4271000, 7.2060000],
        ['Ilorin International Airport', 'ILR', 'Ilorin', 8.4402000, 4.4939000],
        ['Yakubu Gowon Airport', 'JOS', 'Jos', 9.6398000, 8.8691000],
        ['Victor Attah International Airport', 'QUO', 'Uyo', 4.8725000, 8.0930000],
        ['Asaba International Airport', 'ABB', 'Asaba', 6.2042000, 6.6653000],
        ['Osubi Airport', 'QRW', 'Warri', 5.5961000, 5.8178000],
        ['Akure Airport', 'AKR', 'Akure', 7.2467000, 5.3010000],
        ['Ibadan Airport', 'IBA', 'Ibadan', 7.3624000, 3.9783000],
        ['Minna Airport', 'MXJ', 'Minna', 9.6522000, 6.4623000],
        ['Sir Abubakar Tafawa Balewa Airport', 'BCU', 'Bauchi', 10.4829000, 9.7440000],
        ['Gombe Lawanti International Airport', 'GMO', 'Gombe', 10.2983000, 10.8964000],
        ['Umaru Musa Yar\'adua Airport', 'DKA', 'Katsina', 13.0078000, 7.6604000],
    ];
}
