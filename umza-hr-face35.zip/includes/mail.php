<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Email sending service (PHPMailer) with automatic fallback.
 *
 * Delivery order (setting `mail_driver`):
 *   smtp  -> try SMTP with the saved credentials, then fall back to the
 *            server's own mail() / sendmail if SMTP fails (default)
 *   mail  -> use the server's mail() / sendmail only (works on most cPanel hosts
 *            without any username or password)
 *   log   -> do not send, only write to the mail log (testing)
 *
 * Every attempt is written to logs/mail_log.txt so failures are visible in
 * Admin > System Settings > Email Log.
 */

require_once __DIR__ . '/db.php';

$GLOBALS['phpmailer_available'] = false;
$__pm_dir = BASE_PATH . '/libs/phpmailer/src/';
if (file_exists($__pm_dir . 'Exception.php') && file_exists($__pm_dir . 'PHPMailer.php') && file_exists($__pm_dir . 'SMTP.php')) {
    require_once $__pm_dir . 'Exception.php';
    require_once $__pm_dir . 'PHPMailer.php';
    require_once $__pm_dir . 'SMTP.php';
    $GLOBALS['phpmailer_available'] = true;
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

/** Last error message from a failed send (for showing to admins). */
$GLOBALS['mail_last_error'] = '';

function mail_last_error() {
    return $GLOBALS['mail_last_error'] ?? '';
}

/** Read all mail settings in one place. */
function mail_config() {
    $cfg = [
        'driver'    => strtolower(trim(get_setting('mail_driver', 'smtp'))) ?: 'smtp',
        'host'      => trim(get_setting('smtp_host', '')),
        'port'      => intval(get_setting('smtp_port', '465')) ?: 465,
        'user'      => trim(get_setting('smtp_user', '')),
        'pass'      => get_setting('smtp_pass', ''),
        'secure'    => strtolower(trim(get_setting('smtp_secure', 'ssl'))),
        'from'      => trim(get_setting('system_email', '')),
        'from_name' => trim(get_setting('mail_from_name', '')) ?: get_setting('company_name', 'UMZA Aviation Services Ltd'),
        'reply_to'  => trim(get_setting('mail_reply_to', '')),
    ];
    // Most hosts reject mail whose From address differs from the SMTP login.
    if ($cfg['from'] === '' || !filter_var($cfg['from'], FILTER_VALIDATE_EMAIL)) {
        $cfg['from'] = filter_var($cfg['user'], FILTER_VALIDATE_EMAIL) ? $cfg['user'] : 'no-reply@' . preg_replace('/^www\./', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    }
    return $cfg;
}

/** Path of the private mail log (not inside the public uploads folder). */
function mail_log_path() {
    $dir = BASE_PATH . DIRECTORY_SEPARATOR . 'logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (!file_exists($dir . '/.htaccess')) {
        @file_put_contents($dir . '/.htaccess', "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n");
    }
    if (!file_exists($dir . '/index.html')) {
        @file_put_contents($dir . '/index.html', '');
    }
    return $dir . DIRECTORY_SEPARATOR . 'mail_log.txt';
}

function mail_log($line, $body = null) {
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $line . "\n";
    if ($body !== null) {
        $entry .= "BODY:\n" . trim(strip_tags(str_replace(['<br>', '</p>', '</li>'], "\n", $body))) . "\n";
    }
    $entry .= str_repeat('-', 80) . "\n";
    $file = mail_log_path();
    // Keep the log from growing forever (~2 MB)
    if (file_exists($file) && filesize($file) > 2 * 1024 * 1024) {
        @rename($file, $file . '.old');
    }
    @file_put_contents($file, $entry, FILE_APPEND);
}

/**
 * Build a PHPMailer instance for the given transport.
 * @param string $transport 'smtp' or 'mail'
 */
function build_mailer($cfg, $transport, &$debug_lines = null) {
    $mail = new PHPMailer(true);
    $mail->CharSet = 'UTF-8';
    $mail->Timeout = 20;

    if ($transport === 'smtp') {
        $mail->isSMTP();
        $mail->Host     = $cfg['host'];
        $mail->Port     = $cfg['port'];
        $mail->SMTPAuth = ($cfg['user'] !== '');
        $mail->Username = $cfg['user'];
        $mail->Password = $cfg['pass'];
        if ($cfg['secure'] === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($cfg['secure'] === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $mail->SMTPSecure  = '';
            $mail->SMTPAutoTLS = false;
        }
        // cPanel shared hosts often use a certificate for the server name, not mail.yourdomain
        $mail->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        if (is_array($debug_lines)) {
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;
            $mail->Debugoutput = function ($str) use (&$debug_lines) {
                // Never show the (base64) username/password in the debug output
                $line = rtrim($str);
                if (stripos($line, 'CLIENT -> SERVER:') === 0 &&
                    !preg_match('/CLIENT -> SERVER:\s*(EHLO|HELO|AUTH|MAIL|RCPT|DATA|QUIT|STARTTLS|RSET|NOOP)/i', $line)) {
                    $line = 'CLIENT -> SERVER: [hidden credentials/data]';
                }
                if (stripos($line, 'CLIENT -> SERVER: [hidden') === 0 && end($debug_lines) === $line) {
                    return;
                }
                $debug_lines[] = $line;
            };
        }
    } else {
        $mail->isMail();
    }

    $mail->setFrom($cfg['from'], $cfg['from_name']);
    $mail->Sender = $cfg['from'];
    if ($cfg['reply_to'] !== '' && filter_var($cfg['reply_to'], FILTER_VALIDATE_EMAIL)) {
        $mail->addReplyTo($cfg['reply_to']);
    }
    return $mail;
}

/**
 * Core delivery routine used by every send function.
 * @param array $to   list of [email, name]
 * @param array $bcc  list of emails
 */
function deliver_mail(array $to, array $bcc, $subject, $html, $alt, &$debug_lines = null) {
    $GLOBALS['mail_last_error'] = '';
    $cfg = mail_config();
    $recipients_label = implode(', ', array_map(fn($r) => $r[0], $to)) . (count($bcc) ? ' + ' . count($bcc) . ' BCC' : '');

    if ($cfg['driver'] === 'log') {
        mail_log("LOGGED ONLY (mail_driver=log) TO: $recipients_label | SUBJECT: $subject", $html);
        return true;
    }

    if (!$GLOBALS['phpmailer_available']) {
        // Bare mail() as last resort
        $headers = "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\nFrom: {$cfg['from_name']} <{$cfg['from']}>\r\n";
        if ($bcc) $headers .= 'Bcc: ' . implode(', ', $bcc) . "\r\n";
        $ok = @mail(implode(', ', array_map(fn($r) => $r[0], $to)), $subject, $html, $headers, '-f' . $cfg['from']);
        mail_log(($ok ? 'SENT via mail()' : 'FAILED via mail()') . " (PHPMailer missing) TO: $recipients_label | SUBJECT: $subject");
        if (!$ok) $GLOBALS['mail_last_error'] = 'PHP mail() failed and PHPMailer library is missing.';
        return $ok;
    }

    $transports = [];
    if ($cfg['driver'] === 'smtp' && $cfg['host'] !== '') {
        $transports[] = 'smtp';
    }
    $transports[] = 'mail'; // server sendmail fallback
    $errors = [];

    foreach ($transports as $transport) {
        try {
            $mail = build_mailer($cfg, $transport, $debug_lines);
            foreach ($to as $r) {
                $mail->addAddress($r[0], $r[1] ?? '');
            }
            foreach ($bcc as $b) {
                $mail->addBCC($b);
            }
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $html;
            $mail->AltBody = $alt;
            $mail->send();
            $note = $errors ? ' (after SMTP failed: ' . $errors[0] . ')' : '';
            mail_log('SENT via ' . strtoupper($transport) . "$note TO: $recipients_label | SUBJECT: $subject");
            return true;
        } catch (\Throwable $e) {
            $msg = (isset($mail) && $mail->ErrorInfo) ? $mail->ErrorInfo : $e->getMessage();
            $errors[] = strtoupper($transport) . ': ' . $msg;
            error_log("Mail $transport error: $msg");
        }
    }

    $GLOBALS['mail_last_error'] = implode(' | ', $errors);
    mail_log("FAILED TO: $recipients_label | SUBJECT: $subject | ERRORS: " . $GLOBALS['mail_last_error']);
    return false;
}

/**
 * Send an HTML email notification to one person.
 * @return bool true when the server accepted the message
 */
function send_email($to_email, $to_name, $subject, $body_html) {
    $to_email = trim((string)$to_email);
    if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
        $GLOBALS['mail_last_error'] = "Invalid recipient address: $to_email";
        mail_log("SKIPPED invalid address '$to_email' | SUBJECT: $subject");
        return false;
    }
    $full = get_email_template($to_name, $subject, $body_html);
    return deliver_mail([[$to_email, $to_name]], [], $subject, $full, html_to_text($body_html));
}

/**
 * Send one message to many people. Recipients are hidden from each other (BCC)
 * and sent in batches so hosts with recipient limits do not reject the email.
 * @return bool true when every batch was accepted
 */
function send_mass_email($bcc_emails, $subject, $body_html, $greeting_name = 'UMZA Staff') {
    $list = array_values(array_unique(array_filter(array_map('trim', (array)$bcc_emails), fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL))));
    if (empty($list)) {
        return true;
    }
    $cfg = mail_config();
    $full = get_email_template($greeting_name, $subject, $body_html);
    $alt = html_to_text($body_html);
    $all_ok = true;
    foreach (array_chunk($list, 40) as $chunk) {
        $ok = deliver_mail([[$cfg['from'], $greeting_name]], $chunk, $subject, $full, $alt);
        $all_ok = $all_ok && $ok;
    }
    return $all_ok;
}

/** Send a test message and return [ok, log lines]. Used by System Settings. */
function send_test_email($to_email) {
    $debug = [];
    $subject = 'Test Email - ' . get_setting('company_name', 'UMZA Aviation Services Ltd') . ' HR Portal';
    $body = '<p>This is a test email from the HR Portal.</p><p>If you received this, email delivery is working. Sent ' . date('M d, Y h:i A') . '.</p>';
    $full = get_email_template('Administrator', $subject, $body);
    $ok = deliver_mail([[$to_email, 'Administrator']], [], $subject, $full, html_to_text($body), $debug);
    return [$ok, $debug, mail_last_error()];
}

function html_to_text($html) {
    $text = preg_replace('/<a [^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/i', '$2 ($1)', $html);
    $text = str_replace(['<br>', '<br/>', '<br />', '</p>', '</li>', '<hr>'], "\n", $text);
    return trim(html_entity_decode(strip_tags($text), ENT_QUOTES, 'UTF-8'));
}

/**
 * Returns a styled HTML email template matching the company theme.
 * Styles are inline because Gmail/Outlook strip <style> blocks.
 */
function get_email_template($name, $title, $content) {
    $company_name = get_setting('company_name', 'UMZA Aviation Services Ltd');
    $custom_header = get_setting('letterhead_header_image', '');
    $header_rel = (!empty($custom_header) && is_file(BASE_PATH . '/' . $custom_header)) ? $custom_header : 'assets/images/letterhead-header.png';
    $header_img = (function_exists('get_base_url') ? get_base_url() : '') . '/' . $header_rel;
    $btn = 'display:inline-block;padding:10px 20px;background-color:#2d6a4f;color:#ffffff !important;text-decoration:none;border-radius:6px;font-weight:bold;margin-top:10px;';
    $content = preg_replace("/class=(['\"])btn\\1/", 'style="' . $btn . '"', $content);
    return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title></head>
<body style="font-family:Arial,sans-serif;background-color:#f4f7f6;color:#2d3748;margin:0;padding:20px;">
  <div style="max-width:600px;margin:0 auto;background-color:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;">
    <div style="background:#ffffff;text-align:center;">
      <img src="' . htmlspecialchars($header_img) . '" alt="' . htmlspecialchars($company_name) . '" width="600" style="width:100%;max-width:600px;display:block;border:0;">
    </div>
    <div style="background:#1b2b5e;padding:8px 20px;text-align:center;color:#ffffff;font-size:11px;text-transform:uppercase;letter-spacing:2px;">Human Resources - Official Communication</div>
    <div style="padding:26px 20px;line-height:1.6;font-size:14px;">
      <p style="margin:0 0 15px 0;">Hello <strong>' . htmlspecialchars($name) . '</strong>,</p>
      ' . $content . '
    </div>
    <div style="background-color:#6b2f1a;padding:16px;text-align:center;font-size:11px;color:#f3e3d3;">
      <p style="margin:0 0 6px 0;">' . htmlspecialchars(get_setting('company_address', 'Suite D1 UYK HEXAHUB, Plot 1077A Balanga Crescent, Off Uke Street, Area 11, Garki, Abuja')) . ' &middot; ' . htmlspecialchars(get_setting('company_phone', '')) . '</p>
      <p style="margin:0 0 6px 0;">This is an official notification from the ' . htmlspecialchars($company_name) . ' HR Portal.</p>
      <p style="margin:0;">&copy; ' . date('Y') . ' ' . htmlspecialchars($company_name) . '. All rights reserved.</p>
    </div>
  </div>
</body></html>';
}

/**
 * Send (or re-send) the email-verification link to a newly registered staff member.
 */
function send_verification_email($email, $name, $token) {
    global $pdo;
    $company = get_setting('company_name', 'UMZA Aviation Services Ltd');
    $verify_link = get_base_url() . "/verify-email.php?token=" . urlencode($token);
    $subject = "Verify Your Email - $company";
    $body = "
        <p>Thank you for registering on the " . htmlspecialchars($company) . " HR Portal.</p>
        <p>Please verify your email address by clicking the button below:</p>
        <p><a href='$verify_link' class='btn'>Verify Email Address</a></p>
        <p>If the button does not work, copy and paste this link into your browser:<br>$verify_link</p>
        <p>After verification, your account will be reviewed by HR. You will receive another email when it is approved.</p>";
    $ok = send_email($email, $name, $subject, $body);
    try {
        $pdo->prepare("UPDATE `staff` SET `verification_sent_at` = NOW() WHERE `email` = ?")->execute([$email]);
    } catch (PDOException $e) {
    }
    return $ok;
}
