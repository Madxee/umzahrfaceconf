<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Shared Layout Header & Sidebar Navigation
 */

require_once __DIR__ . '/auth.php';

// Force authentication
require_login();

// Handle name updates globally for any logged-in user or admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_my_name') {
    $current_url = strtok($_SERVER["REQUEST_URI"], '?');
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        header("Location: " . $current_url . "?error=CSRF+validation+failed.");
        exit;
    }
    $first_name = trim($_POST['first_name'] ?? '');
    $other_name = trim($_POST['other_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $format = $_POST['name_display_format'] ?? 'first_last';
    if (!array_key_exists($format, name_display_formats())) $format = 'first_last';

    if ($first_name === '' || $last_name === '') {
        header("Location: " . $current_url . "?error=First+and+last+name+cannot+be+empty.");
        exit;
    }
    try {
        $stmt = $pdo->prepare("UPDATE `staff` SET `first_name` = ?, `other_name` = ?, `last_name` = ?, `name_display_format` = ? WHERE `id` = ?");
        $stmt->execute([$first_name, $other_name !== '' ? $other_name : null, $last_name, $format, $_SESSION['user_id']]);
        $_SESSION['name'] = refresh_display_name($_SESSION['user_id']);
        log_activity($_SESSION['user_id'], 'NAME_UPDATED', "User updated their name to " . $_SESSION['name']);
        header("Location: " . $current_url . "?success=Name+updated+successfully.");
    } catch (PDOException $e) {
        header("Location: " . $current_url . "?error=Database+error+updating+name.");
    }
    exit;
}

// Real-time status enforcement check (if suspended/pending, terminate session)
$stmt = $pdo->prepare("SELECT `status`, `role`, `first_name`, `other_name`, `last_name`, `name_display_format`, `display_name`, `passport_photo`, `staff_id`, `department_id` FROM `staff` WHERE `id` = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_db_state = $stmt->fetch();

if (!$user_db_state || $user_db_state['status'] !== 'Active') {
    session_destroy();
    header("Location: " . get_base_url() . "/index.php?error=access_denied");
    exit;
}

// Update session values
$_SESSION['role'] = $user_db_state['role'];
$_SESSION['name'] = display_name($user_db_state);
$_SESSION['passport'] = $user_db_state['passport_photo'];
$_SESSION['staff_code'] = $user_db_state['staff_id'];
$_SESSION['department_id'] = (int)$user_db_state['department_id'];

$current_role = $_SESSION['role'];
$page_name = basename($_SERVER['PHP_SELF']);
$in_admin = strpos($_SERVER['PHP_SELF'], '/admin/') !== false;
$in_staff = strpos($_SERVER['PHP_SELF'], '/staff/') !== false;

/** Render one sidebar link. $feature = feature key or null; $pages = file names that mark it active. */
function nav_link($href, $icon, $label, $pages, $area, $feature = null) {
    global $page_name, $in_admin, $in_staff;
    if ($feature !== null && !feature_enabled($feature)) return;
    $active = in_array($page_name, (array)$pages, true) && (($area === 'admin' && $in_admin) || ($area === 'staff' && $in_staff));
    echo '<li class="' . ($active ? 'active' : '') . '"><a href="' . get_base_url() . $href . '"><i class="' . $icon . '"></i> ' . htmlspecialchars($label) . '</a></li>' . "\n";
}

// Items waiting for the Managing Director
$md_pending = 0;
if (is_hr_role($current_role) || $current_role === 'Managing Director') {
    try {
        $md_pending = (int)$pdo->query("SELECT (SELECT COUNT(*) FROM `staff_letters` WHERE `status` = 'Pending MD') + (SELECT COUNT(*) FROM `memos` WHERE `status` = 'Pending MD')")->fetchColumn();
    } catch (PDOException $e) {
    }
}

// Admin-defined shortcut links and active announcements
$custom_links = [];
$top_announcements = [];
try {
    $audience = is_hr_role($current_role) ? ['All', 'Admins'] : ['All', 'Staff'];
    if ($current_role === 'Department Head') $audience[] = 'Department Heads';
    $in = implode(',', array_fill(0, count($audience), '?'));
    $cl = $pdo->prepare("SELECT * FROM `custom_links` WHERE `is_active` = 1 AND `audience` IN ($in) ORDER BY `sort_order`, `id`");
    $cl->execute($audience);
    $custom_links = $cl->fetchAll();
    $top_announcements = $pdo->query("SELECT * FROM `announcements` WHERE `is_active` = 1 AND (`expires_on` IS NULL OR `expires_on` >= CURDATE()) ORDER BY `id` DESC")->fetchAll();
} catch (PDOException $e) {
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - HR Portal</title>
    
    <!-- Meta tags for PWA and Mobile Friendly -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="theme-color" content="#1b4332">
    
    <!-- CDNs: Bootstrap 5, FontAwesome, Google Fonts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
    
    <!-- PWA Manifest Link -->
    <link rel="manifest" href="<?php echo get_base_url(); ?>/manifest.json">
    
    <!-- Chart.js for analytics -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar Navigation -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <div class="mx-auto mb-2 text-center" style="width: 60px; height: 60px; background: white; border-radius: 50%; padding: 4px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                    <img src="<?php echo get_base_url(); ?>/assets/images/logo.jpg" alt="UAS Logo" style="max-width: 100%; max-height: 100%; border-radius: 50%;">
                </div>
                <h3 class="fw-bold tracking-wide" style="font-size: 1.05rem;">UMZA AVIATION</h3>
                <span class="badge bg-success" style="font-size: 0.75rem;"><?php echo htmlspecialchars($current_role); ?></span>
            </div>

            <ul class="list-unstyled components">
                <?php if (is_hr_role($current_role)): ?>
                    <?php
                    nav_link('/admin/dashboard.php', 'fa-solid fa-chart-pie', 'Admin Dashboard', 'dashboard.php', 'admin');
                    nav_link('/admin/staff.php', 'fa-solid fa-users', 'Staff Directory', ['staff.php', 'staff-profile.php', 'add-staff.php'], 'admin');
                    nav_link('/admin/departments.php', 'fa-solid fa-sitemap', 'Departments & Positions', 'departments.php', 'admin');
                    nav_link('/admin/attendance.php', 'fa-solid fa-user-clock', 'Attendance Hub', 'attendance.php', 'admin', 'attendance');
                    nav_link('/admin/locations.php', 'fa-solid fa-location-dot', 'GPS Locations', 'locations.php', 'admin', 'attendance');
                    nav_link('/admin/leave.php', 'fa-solid fa-calendar-check', 'Leave Management', 'leave.php', 'admin', 'leave');
                    nav_link('/admin/recruitment.php', 'fa-solid fa-user-plus', 'Recruitment', 'recruitment.php', 'admin', 'recruitment');
                    nav_link('/admin/training.php', 'fa-solid fa-graduation-cap', 'Training Records', 'training.php', 'admin', 'training');
                    nav_link('/admin/aviation.php', 'fa-solid fa-plane-up', 'Aviation Hub', 'aviation.php', 'admin', 'aviation');
                    nav_link('/admin/letters.php', 'fa-solid fa-file-signature', 'HR Letters Center', 'letters.php', 'admin', 'letters');
                    nav_link('/admin/complaints.php', 'fa-solid fa-triangle-exclamation', 'Staff Complaints', 'complaints.php', 'admin', 'complaints');
                    nav_link('/admin/queries.php', 'fa-solid fa-scale-balanced', 'Disciplinary Queries', 'queries.php', 'admin', 'queries');
                    nav_link('/admin/performance.php', 'fa-solid fa-award', 'Appraisals & KPIs', 'performance.php', 'admin', 'performance');
                    nav_link('/admin/memos.php', 'fa-solid fa-bullhorn', 'Memos & Broadcasts', 'memos.php', 'admin', 'memos');
                    nav_link('/admin/approvals.php', 'fa-solid fa-stamp', 'MD Approvals' . ($md_pending ? " ($md_pending)" : ''), 'approvals.php', 'admin');
                    if (in_array($current_role, ['Super Admin', 'HR Director', 'HR Manager'], true)) {
                        nav_link('/admin/features.php', 'fa-solid fa-toggle-on', 'Features & Shortcuts', 'features.php', 'admin');
                        nav_link('/admin/settings.php', 'fa-solid fa-gears', 'System Settings', 'settings.php', 'admin');
                    }
                    ?>
                <?php endif; ?>

                <?php if ($current_role === 'Managing Director'): ?>
                    <?php
                    nav_link('/admin/approvals.php', 'fa-solid fa-stamp', 'MD Approvals' . ($md_pending ? " ($md_pending)" : ''), 'approvals.php', 'admin');
                    nav_link('/admin/dashboard.php', 'fa-solid fa-chart-pie', 'Company Dashboard', 'dashboard.php', 'admin');
                    nav_link('/admin/staff.php', 'fa-solid fa-users', 'Staff Directory', 'staff.php', 'admin');
                    nav_link('/admin/attendance.php', 'fa-solid fa-user-clock', 'Attendance', 'attendance.php', 'admin', 'attendance');
                    nav_link('/admin/leave.php', 'fa-solid fa-calendar-check', 'Leave', 'leave.php', 'admin', 'leave');
                    nav_link('/admin/letters.php', 'fa-solid fa-file-signature', 'Official Letters', 'letters.php', 'admin', 'letters');
                    nav_link('/admin/memos.php', 'fa-solid fa-bullhorn', 'Memos & Broadcasts', 'memos.php', 'admin', 'memos');
                    ?>
                <?php endif; ?>

                <?php if ($current_role === 'Finance Officer'): ?>
                    <?php
                    nav_link('/admin/dashboard.php', 'fa-solid fa-chart-pie', 'Finance Dashboard', 'dashboard.php', 'admin');
                    nav_link('/admin/staff.php', 'fa-solid fa-users', 'Staff Directory', ['staff.php', 'staff-profile.php'], 'admin');
                    nav_link('/admin/attendance.php', 'fa-solid fa-user-clock', 'Daily Attendance', 'attendance.php', 'admin', 'attendance');
                    nav_link('/admin/leave.php', 'fa-solid fa-calendar-check', 'Leave Tracking', 'leave.php', 'admin', 'leave');
                    nav_link('/admin/letters.php', 'fa-solid fa-file-signature', 'Salary Letters', 'letters.php', 'admin', 'letters');
                    ?>
                <?php endif; ?>

                <?php if ($current_role === 'Department Head'): ?>
                    <?php
                    nav_link('/admin/dashboard.php', 'fa-solid fa-gauge', 'Dept Dashboard', 'dashboard.php', 'admin');
                    nav_link('/admin/staff.php', 'fa-solid fa-users', 'Department Staff', 'staff.php', 'admin');
                    nav_link('/admin/attendance.php', 'fa-solid fa-user-clock', 'Dept Attendance', 'attendance.php', 'admin', 'attendance');
                    nav_link('/admin/leave.php', 'fa-solid fa-calendar-check', 'Leave Reviews', 'leave.php', 'admin', 'leave');
                    nav_link('/admin/memos.php', 'fa-solid fa-bullhorn', 'Department Memos', 'memos.php', 'admin', 'memos');
                    ?>
                <?php endif; ?>

                <!-- Staff General Navigation -->
                <li class="header-divider text-center py-2 text-uppercase text-secondary font-weight-bold" style="font-size: 0.75rem; letter-spacing: 1px;">
                    Staff Menu (ESS)
                </li>
                <?php
                nav_link('/staff/dashboard.php', 'fa-solid fa-table-columns', 'My Dashboard', 'dashboard.php', 'staff');
                nav_link('/staff/profile.php', 'fa-solid fa-user-tie', 'My Profile File', 'profile.php', 'staff');
                nav_link('/staff/id-card.php', 'fa-solid fa-id-card', 'My ID Card', 'id-card.php', 'staff', 'id_card');
                nav_link('/staff/attendance.php', 'fa-solid fa-clock', 'Clock In / Out', 'attendance.php', 'staff', 'attendance');
                nav_link('/staff/leave.php', 'fa-solid fa-calendar-days', 'Leave Requests', 'leave.php', 'staff', 'leave');
                nav_link('/staff/aviation.php', 'fa-solid fa-plane-arrival', 'Crew Operations', 'aviation.php', 'staff', 'aviation');
                nav_link('/staff/letters.php', 'fa-solid fa-folder-open', 'HR Letters', 'letters.php', 'staff', 'letters');
                nav_link('/staff/performance.php', 'fa-solid fa-award', 'My Appraisals', 'performance.php', 'staff', 'performance');
                nav_link('/staff/complaints.php', 'fa-solid fa-circle-question', 'Submit Complaint', 'complaints.php', 'staff', 'complaints');
                nav_link('/staff/queries.php', 'fa-solid fa-envelope-open-text', 'Queries & Warnings', 'queries.php', 'staff', 'queries');
                nav_link('/staff/memos.php', 'fa-solid fa-envelope', 'Memos & Notices', 'memos.php', 'staff', 'memos');
                ?>

                <?php if (!empty($custom_links)): ?>
                    <li class="header-divider text-center py-2 text-uppercase text-secondary font-weight-bold" style="font-size: 0.75rem; letter-spacing: 1px;">
                        Shortcuts
                    </li>
                    <?php foreach ($custom_links as $link):
                        $is_external = preg_match('#^https?://#i', $link['url']);
                        $href = $is_external ? $link['url'] : get_base_url() . '/' . ltrim($link['url'], '/'); ?>
                        <li><a href="<?php echo htmlspecialchars($href); ?>" <?php echo $is_external ? 'target="_blank" rel="noopener"' : ''; ?>>
                            <i class="<?php echo htmlspecialchars($link['icon'] ?: 'fa-solid fa-link'); ?>"></i> <?php echo htmlspecialchars($link['title']); ?>
                        </a></li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>

            <div class="p-3 text-center">
                <a href="<?php echo get_base_url(); ?>/index.php?action=logout" class="btn btn-outline-light w-100 btn-sm">
                    <i class="fa-solid fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </nav>

        <!-- Main Content Area -->
        <div id="content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-custom navbar-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-aviation">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle profile-dropdown d-flex align-items-center" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="<?php echo photo_url($_SESSION['passport'] ?? ''); ?>" class="rounded-circle me-2" alt="Passport" style="object-fit: cover;">
                                <span class="d-none d-md-inline fw-semibold text-dark"><?php echo htmlspecialchars($_SESSION['name']); ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0" aria-labelledby="dropdownMenuLink">
                                <li><a class="dropdown-menu-item dropdown-item" href="<?php echo get_base_url(); ?>/staff/profile.php"><i class="fa-solid fa-id-card me-2"></i> Profile</a></li>
                                <li><a class="dropdown-menu-item dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editNameModal"><i class="fa-solid fa-user-pen me-2"></i> Edit Name</a></li>
                                <li><a class="dropdown-menu-item dropdown-item" href="<?php echo get_base_url(); ?>/index.php?action=logout"><i class="fa-solid fa-right-from-bracket me-2"></i> Sign Out</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <div class="container-fluid p-4">
                <!-- Admin announcements (Features & Shortcuts > Announcements) -->
                <?php foreach ($top_announcements as $ann): ?>
                    <div class="alert alert-<?php echo htmlspecialchars($ann['style']); ?> border-0 shadow-sm d-flex align-items-center mb-3" role="alert">
                        <i class="fa-solid fa-bullhorn me-2"></i>
                        <div><?php echo nl2br(htmlspecialchars($ann['message'])); ?></div>
                    </div>
                <?php endforeach; ?>
                <!-- Notifications container -->
                <?php if (isset($_GET['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 border-start border-success border-4" role="alert">
                        <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($_GET['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 border-start border-danger border-4" role="alert">
                        <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($_GET['error']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
