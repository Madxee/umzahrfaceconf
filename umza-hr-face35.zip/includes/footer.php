            </div> <!-- Close container-fluid -->
        </div> <!-- Close content -->
    </div> <!-- Close wrapper -->

    <!-- Footer Copyright -->
    <footer class="text-center py-3 text-secondary border-top bg-white" style="font-size: 0.85rem;">
        <div class="container-fluid">
            &copy; <?php echo date('Y'); ?> <strong><?php echo htmlspecialchars(get_setting('company_name', 'UMZA Aviation Services Ltd')); ?></strong>. All Rights Reserved. 
            | Designed for Professional Aviation HR Management.
        </div>
    </footer>

    <!-- Edit Name Modal -->
    <div class="modal fade" id="editNameModal" tabindex="-1" aria-labelledby="editNameModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-aviation text-white">
                    <h5 class="modal-title fw-bold" id="editNameModalLabel"><i class="fa-solid fa-user-pen me-2"></i>Edit My Name</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="update_my_name">
                    <div class="modal-body">
                        <?php
                        global $pdo;
                        $stmt = $pdo->prepare("SELECT `first_name`, `other_name`, `last_name`, `name_display_format` FROM `staff` WHERE `id` = ?");
                        $stmt->execute([$_SESSION['user_id']]);
                        $curr_name = $stmt->fetch() ?: ['first_name' => '', 'other_name' => '', 'last_name' => '', 'name_display_format' => 'first_last'];
                        ?>
                        <div class="mb-3">
                            <label for="modal_first_name" class="form-label fw-bold">First Name *</label>
                            <input type="text" class="form-control" id="modal_first_name" name="first_name" value="<?php echo htmlspecialchars($curr_name['first_name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="modal_other_name" class="form-label fw-bold">Other Name</label>
                            <input type="text" class="form-control" id="modal_other_name" name="other_name" value="<?php echo htmlspecialchars($curr_name['other_name'] ?? ''); ?>" placeholder="Middle name (optional)">
                        </div>
                        <div class="mb-3">
                            <label for="modal_last_name" class="form-label fw-bold">Last Name *</label>
                            <input type="text" class="form-control" id="modal_last_name" name="last_name" value="<?php echo htmlspecialchars($curr_name['last_name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="modal_name_display_format" class="form-label fw-bold">Name to display</label>
                            <select class="form-select" id="modal_name_display_format" name="name_display_format">
                                <?php echo name_format_options($curr_name['first_name'], $curr_name['other_name'] ?? '', $curr_name['last_name'], $curr_name['name_display_format'] ?? 'first_last'); ?>
                            </select>
                            <div class="form-text">This is the name shown on the portal, emails and your ID card.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-aviation">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo get_base_url(); ?>/assets/js/name-format.js?v=<?php echo get_asset_version('assets/js/name-format.js'); ?>"></script>
    <script src="<?php echo get_base_url(); ?>/assets/js/main.js?v=<?php echo get_asset_version('assets/js/main.js'); ?>"></script>
</body>
</html>
