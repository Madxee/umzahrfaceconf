<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Official company letterhead for every printed document
 * (HR letters, promotions, leave approvals, memos, department memos...).
 *
 * The header and footer images repeat on every printed page.
 * Replace them in Admin > System Settings > Official Letterhead.
 */

function letterhead_image($which) {
    $custom = get_setting('letterhead_' . $which . '_image', '');
    if (!empty($custom) && is_file(BASE_PATH . '/' . $custom)) {
        return photo_url($custom);
    }
    $file = 'assets/images/letterhead-' . $which . '.png';
    return get_base_url() . '/' . $file . '?v=' . (is_file(BASE_PATH . '/' . $file) ? filemtime(BASE_PATH . '/' . $file) : 1);
}

/** <head> styles for letterhead pages. */
function letterhead_styles() {
    ?>
    <style>
        @page { size: A4; margin: 0; }
        body.lh-body { background: #e9ecef; margin: 0; font-family: 'Times New Roman', Times, serif; color: #222; }
        .lh-toolbar { text-align: center; padding: 14px; }
        .lh-sheet {
            width: 210mm; min-height: 297mm; margin: 0 auto 24px auto; background: #fff; position: relative;
            box-shadow: 0 4px 18px rgba(0,0,0,0.12); display: flex; flex-direction: column;
        }
        .lh-header img, .lh-footer img { width: 100%; display: block; }
        .lh-content { flex: 1; padding: 6mm 20mm 10mm 20mm; font-size: 12pt; line-height: 1.6; }
        .lh-footer { margin-top: auto; }
        .lh-ref { display: flex; justify-content: space-between; font-size: 11pt; margin-bottom: 6mm; }
        .lh-title { text-align: center; font-weight: bold; text-transform: uppercase; text-decoration: underline; letter-spacing: .3px; margin: 6mm 0; font-size: 13pt; }
        .lh-memo-table { width: 100%; border-collapse: collapse; margin-bottom: 4mm; font-size: 12pt; }
        .lh-memo-table td { padding: 1.5mm 0; vertical-align: top; }
        .lh-memo-table td:first-child { width: 28mm; font-weight: bold; }
        .lh-rule { border: 0; border-top: 2px solid #1d2b5e; margin: 2mm 0 5mm 0; }
        .lh-text { white-space: pre-line; text-align: justify; }
        .lh-sign { margin-top: 14mm; }
        .lh-sign img { max-height: 16mm; max-width: 55mm; object-fit: contain; display: block; margin-bottom: 1mm; }
        .lh-sign .line { border-top: 1px solid #555; width: 65mm; padding-top: 1mm; }
        .lh-sign-row { display: flex; justify-content: space-between; gap: 10mm; }
        .lh-stamp { font-size: 9pt; color: #666; margin-top: 6mm; }
        @media print {
            body.lh-body { background: #fff; }
            .lh-toolbar { display: none !important; }
            .lh-sheet { box-shadow: none; margin: 0; min-height: auto; display: block; }
            /* Header and footer repeat on every printed page */
            .lh-header { position: fixed; top: 0; left: 0; width: 210mm; }
            .lh-footer { position: fixed; bottom: 0; left: 0; width: 210mm; }
            .lh-print-space { display: table; width: 100%; }
            .lh-content { padding: 0 20mm; }
            thead.lh-pad-top td { height: 44mm; }
            tfoot.lh-pad-bottom td { height: 36mm; }
        }
        @media screen {
            thead.lh-pad-top, tfoot.lh-pad-bottom { display: none; }
            .lh-sheet { max-width: 100%; }
        }
        @media screen and (max-width: 820px) {
            .lh-content { padding: 4mm 7mm 8mm 7mm; font-size: 11pt; }
            .lh-sign-row { flex-direction: column; gap: 6mm; }
        }
    </style>
    <?php
}

/** Opens the sheet: toolbar, header image and the content area. */
function letterhead_open($toolbar = true) {
    if ($toolbar): ?>
        <div class="lh-toolbar">
            <button onclick="window.print();" class="btn btn-success me-2 px-4"><i class="fa-solid fa-print me-1"></i>Print / Save as PDF</button>
            <button onclick="window.close();" class="btn btn-outline-secondary px-4">Close</button>
        </div>
    <?php endif; ?>
    <div class="lh-sheet">
        <div class="lh-header"><img src="<?php echo letterhead_image('header'); ?>" alt="UMZA Aviation Services Ltd letterhead"></div>
        <!-- The table reserves room for the fixed header/footer on every printed page -->
        <table class="lh-print-space" style="width:100%;border-collapse:collapse;">
            <thead class="lh-pad-top"><tr><td></td></tr></thead>
            <tfoot class="lh-pad-bottom"><tr><td></td></tr></tfoot>
            <tbody><tr><td style="padding:0;">
        <div class="lh-content">
    <?php
}

/** Closes the sheet with the footer image. */
function letterhead_close() {
    ?>
        </div>
            </td></tr></tbody>
        </table>
        <div class="lh-footer"><img src="<?php echo letterhead_image('footer'); ?>" alt="UMZA Aviation Services Ltd address"></div>
    </div>
    <?php
}

/** Official reference number, e.g. UAS/HR/MEMO/2026/0012 */
function official_reference($unit, $kind, $id, $date = null) {
    $unit = strtoupper(preg_replace('/[^A-Za-z]/', '', $unit)) ?: 'HR';
    $unit = substr($unit, 0, 6);
    return 'UAS/' . $unit . '/' . strtoupper($kind) . '/' . date('Y', strtotime($date ?? 'now')) . '/' . str_pad((string)$id, 4, '0', STR_PAD_LEFT);
}

/** Short unit code from a department name ("Flight Operations" -> "FO", "IT" -> "IT"). */
function department_code($name) {
    $name = trim((string)$name);
    if ($name === '') return 'HR';
    if (preg_match('/\(([A-Za-z]{2,6})\)/', $name, $m)) return strtoupper($m[1]);
    if (preg_match('/^[A-Z&\/ ]{2,6}$/', $name)) return preg_replace('/[^A-Z]/', '', $name);
    $words = preg_split('/[^A-Za-z]+/', $name, -1, PREG_SPLIT_NO_EMPTY);
    $words = array_filter($words, fn($w) => !in_array(strtolower($w), ['and', 'of', 'the', 'dept', 'department'], true));
    $words = array_values($words);
    if (count($words) === 1) return strtoupper(substr($words[0], 0, 5));
    $code = implode('', array_map(fn($w) => strtoupper($w[0]), $words));
    return $code ?: 'HR';
}
