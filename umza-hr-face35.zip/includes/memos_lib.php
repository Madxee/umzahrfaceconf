<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Shared memo helpers (distribution by email + in-app notification)
 */

require_once __DIR__ . '/mail.php';

/** Active staff who should receive a memo. */
function memo_recipients($audience, $dept_id) {
    global $pdo;
    if ($audience === 'Department') {
        $stmt = $pdo->prepare("SELECT `id`, `first_name`, `last_name`, `display_name`, `email` FROM `staff` WHERE `status` = 'Active' AND `department_id` = ?");
        $stmt->execute([$dept_id]);
    } else {
        $stmt = $pdo->query("SELECT `id`, `first_name`, `last_name`, `display_name`, `email` FROM `staff` WHERE `status` = 'Active'");
    }
    return $stmt->fetchAll();
}

/** Email + in-app notification for a memo. Returns number of addresses emailed. */
function distribute_memo($memo, $sender_name) {
    global $pdo;
    $recipients = memo_recipients($memo['audience'], $memo['department_id']);
    $dept_label = $memo['audience'] === 'Department' ? dept_title($memo['department_id']) : 'All Staff';
    $subject = ($memo['audience'] === 'Department' ? "[$dept_label] " : '') . "New {$memo['type']}: {$memo['title']}";
    $content = $memo['content'];
    $excerpt = mb_strlen($content) > 600 ? mb_substr($content, 0, 600) . '...' : $content;
    $body = "
        <p>A new communication has been published on the HR Portal:</p>
        <table style='width:100%;border-collapse:collapse;font-size:14px;'>
            <tr><td style='padding:4px 0;width:110px;color:#718096;'>Subject</td><td style='padding:4px 0;'><strong>" . htmlspecialchars($memo['title']) . "</strong></td></tr>
            <tr><td style='padding:4px 0;color:#718096;'>Category</td><td style='padding:4px 0;'>" . htmlspecialchars($memo['type']) . "</td></tr>
            <tr><td style='padding:4px 0;color:#718096;'>To</td><td style='padding:4px 0;'>" . htmlspecialchars($dept_label) . "</td></tr>
            <tr><td style='padding:4px 0;color:#718096;'>From</td><td style='padding:4px 0;'>" . htmlspecialchars($sender_name) . "</td></tr>
            <tr><td style='padding:4px 0;color:#718096;'>Date</td><td style='padding:4px 0;'>" . date('M d, Y h:i A') . "</td></tr>
        </table>
        <hr style='border:none;border-top:1px solid #e2e8f0;margin:14px 0;'>
        <p>" . nl2br(htmlspecialchars($excerpt)) . "</p>
        " . (!empty($memo['file_path']) ? "<p><em>This memo has an attachment. Open the portal to view or download it.</em></p>" : "") . "
        <p><a href='" . get_base_url() . "/staff/memos.php' class='btn'>Read Memo on Portal</a>
           &nbsp; <a href='" . get_base_url() . "/staff/print-memo.php?id=" . (int)$memo['id'] . "'>Official copy (letterhead)</a></p>";

    $emails = array_column($recipients, 'email');
    send_mass_email($emails, $subject, $body, $memo['audience'] === 'Department' ? "$dept_label Team" : 'UMZA Staff');
    foreach ($recipients as $st) {
        add_notification($st['id'], "New {$memo['type']}", "\"{$memo['title']}\" was published by $sender_name.");
    }
    $pdo->prepare("UPDATE `memos` SET `emails_sent` = ? WHERE `id` = ?")->execute([count($emails), $memo['id']]);
    return count($emails);
}

function get_department_label($id) {
    global $pdo;
    static $names = null;
    if ($names === null) {
        $names = array_column($pdo->query("SELECT `id`, `name` FROM `departments`")->fetchAll(), 'name', 'id');
    }
    return $names[$id] ?? 'Department';
}

/** "IT Department", but "Legal Department" stays as it is. */
function dept_title($id) {
    $name = get_department_label($id);
    return preg_match('/\b(department|dept\.?)$/i', $name) ? $name : "$name Department";
}
