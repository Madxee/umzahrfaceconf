<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Shared helpers: feature switches, display names, image uploads, roles.
 */

/* ------------------------------------------------------------------ *
 * Roles
 * ------------------------------------------------------------------ */

const HR_ROLES = ['Super Admin', 'HR Director', 'HR Manager', 'HR Officer'];

function is_md($role = null) {
    return ($role ?? ($_SESSION['role'] ?? '')) === 'Managing Director';
}

function is_hr_role($role = null) {
    $role = $role ?? ($_SESSION['role'] ?? '');
    return in_array($role, HR_ROLES, true);
}

/** Department id of a staff member (defaults to the logged-in user). */
function get_user_department_id($staff_pk = null) {
    global $pdo;
    $staff_pk = $staff_pk ?? ($_SESSION['user_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT `department_id` FROM `staff` WHERE `id` = ?");
    $stmt->execute([$staff_pk]);
    return (int)$stmt->fetchColumn();
}

/* ------------------------------------------------------------------ *
 * Feature switches (Admin > Features)
 * ------------------------------------------------------------------ */

function umza_feature_list() {
    return [
        'attendance'   => ['label' => 'Attendance (Clock In / Out)', 'icon' => 'fa-solid fa-user-clock', 'desc' => 'Daily clock in/out with face capture.'],
        'leave'        => ['label' => 'Leave Management', 'icon' => 'fa-solid fa-calendar-check', 'desc' => 'Leave requests, approvals and quotas.'],
        'memos'        => ['label' => 'Memos & Broadcasts', 'icon' => 'fa-solid fa-bullhorn', 'desc' => 'Company and department memos with email alerts.'],
        'complaints'   => ['label' => 'Staff Complaints', 'icon' => 'fa-solid fa-triangle-exclamation', 'desc' => 'Grievance submission and HR responses.'],
        'queries'      => ['label' => 'Disciplinary Queries', 'icon' => 'fa-solid fa-scale-balanced', 'desc' => 'Formal queries and staff replies.'],
        'letters'      => ['label' => 'HR Letters', 'icon' => 'fa-solid fa-file-signature', 'desc' => 'Generate and issue official letters.'],
        'performance'  => ['label' => 'Appraisals & KPIs', 'icon' => 'fa-solid fa-award', 'desc' => 'Performance reports and ratings.'],
        'recruitment'  => ['label' => 'Recruitment', 'icon' => 'fa-solid fa-user-plus', 'desc' => 'Vacancies, applicants and interviews.'],
        'training'     => ['label' => 'Training Records', 'icon' => 'fa-solid fa-graduation-cap', 'desc' => 'Training programmes and certificates.'],
        'aviation'     => ['label' => 'Aviation Hub / Crew Operations', 'icon' => 'fa-solid fa-plane-up', 'desc' => 'Licences, medicals, flight schedules, uniforms.'],
        'id_card'      => ['label' => 'Digital ID Card', 'icon' => 'fa-solid fa-id-card', 'desc' => 'Staff ID badge with QR verification.'],
        'registration' => ['label' => 'Staff Self-Registration', 'icon' => 'fa-solid fa-user-pen', 'desc' => 'Allow new staff to register from the login page.'],
    ];
}

function feature_enabled($key) {
    static $cache = [];
    if (!array_key_exists($key, $cache)) {
        $cache[$key] = get_setting('feature_' . $key, '1') !== '0';
    }
    return $cache[$key];
}

/** Stop a page when its feature has been switched off by the admin. */
function require_feature($key) {
    if (!feature_enabled($key)) {
        $label = umza_feature_list()[$key]['label'] ?? $key;
        header("Location: " . get_base_url() . (is_logged_in() ? "/staff/dashboard.php" : "/index.php") . "?error=" . urlencode("$label has been turned off by the administrator."));
        exit;
    }
}

/* ------------------------------------------------------------------ *
 * Names: first, other (middle) and last, with a chosen display format
 * ------------------------------------------------------------------ */

function name_display_formats() {
    return [
        'first_last'       => 'First Last',
        'first_other_last' => 'First Other Last',
        'last_first'       => 'Last First',
        'last_first_other' => 'Last First Other',
        'other_last'       => 'Other Last',
        'first_other'      => 'First Other',
        'other_first_last' => 'Other First Last',
    ];
}

/** Build the display name from name parts and a format key. */
function compose_display_name($first, $other, $last, $format = 'first_last') {
    $parts = ['first' => trim((string)$first), 'other' => trim((string)$other), 'last' => trim((string)$last)];
    $format = array_key_exists($format, name_display_formats()) ? $format : 'first_last';
    $out = [];
    foreach (explode('_', $format) as $p) {
        if ($parts[$p] !== '') $out[] = $parts[$p];
    }
    $name = trim(implode(' ', $out));
    return $name !== '' ? $name : trim($parts['first'] . ' ' . $parts['last']);
}

/** Name to show for a staff row (uses the saved display name when present). */
function display_name($row) {
    if (!is_array($row)) return '';
    if (!empty($row['display_name'])) return $row['display_name'];
    if (isset($row['name_display_format'])) {
        return compose_display_name($row['first_name'] ?? '', $row['other_name'] ?? '', $row['last_name'] ?? '', $row['name_display_format']);
    }
    return trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
}

/** Recalculate and store the display name for one staff member. */
function refresh_display_name($staff_pk) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT `first_name`, `other_name`, `last_name`, `name_display_format` FROM `staff` WHERE `id` = ?");
    $stmt->execute([$staff_pk]);
    $r = $stmt->fetch();
    if (!$r) return '';
    $name = compose_display_name($r['first_name'], $r['other_name'], $r['last_name'], $r['name_display_format']);
    $pdo->prepare("UPDATE `staff` SET `display_name` = ? WHERE `id` = ?")->execute([$name, $staff_pk]);
    return $name;
}

/** <select> options for the display-name format, previewing the real name. */
function name_format_options($first, $other, $last, $selected = 'first_last') {
    $html = '';
    foreach (name_display_formats() as $key => $label) {
        $preview = compose_display_name($first ?: 'First', $other ?: 'Other', $last ?: 'Last', $key);
        $sel = $key === $selected ? ' selected' : '';
        $html .= '<option value="' . $key . '"' . $sel . ' data-format="' . $key . '">' . htmlspecialchars($preview) . ' (' . $label . ')</option>';
    }
    return $html;
}

/* ------------------------------------------------------------------ *
 * Image uploads (passport photos, signatures, attendance face capture)
 * ------------------------------------------------------------------ */

function ensure_upload_dir($subdir) {
    $dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . $subdir;
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (!is_writable($dir)) {
        @chmod($dir, 0775);
    }
    if (!file_exists($dir . DIRECTORY_SEPARATOR . 'index.html')) {
        @file_put_contents($dir . DIRECTORY_SEPARATOR . 'index.html', '');
    }
    return $dir;
}

/** Human message for PHP upload error codes. */
function upload_error_message($code) {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE: return 'The image is too large. Please upload an image smaller than ' . round(UPLOAD_MAX_SIZE / 1048576) . 'MB.';
        case UPLOAD_ERR_PARTIAL:   return 'The image was only partly uploaded. Please try again.';
        case UPLOAD_ERR_NO_FILE:   return 'Please choose an image to upload.';
        case UPLOAD_ERR_NO_TMP_DIR:
        case UPLOAD_ERR_CANT_WRITE: return 'The server could not store the upload (temporary folder not writable). Please contact the administrator.';
        default: return 'Upload failed (error code ' . intval($code) . ').';
    }
}

/**
 * Write an image to disk as a resized JPEG (or PNG when transparency matters).
 * Re-encoding strips anything hidden inside the file, fixes phone rotation and
 * guarantees every browser can display it.
 *
 * @param string $source_path path of the raw image file
 * @return array [relative_path|null, error|null]
 */
function store_image_file($source_path, $subdir, $prefix, $max_px = 800, $keep_png = false) {
    $info = @getimagesize($source_path);
    if ($info === false) {
        return [null, 'The file is not a valid image. Please upload a JPG, PNG or WebP photo.'];
    }
    $dir = ensure_upload_dir($subdir);
    if (!is_writable($dir)) {
        return [null, 'The uploads/' . $subdir . ' folder is not writable on the server. Set its permission to 755 or 775.'];
    }

    $mime = $info['mime'];
    $name = $prefix . '_' . bin2hex(random_bytes(8));

    // Without GD we can only keep the original bytes for safe image types
    if (!function_exists('imagecreatetruecolor')) {
        $ext_map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
        if (!isset($ext_map[$mime])) {
            return [null, 'Unsupported image type. Please upload JPG, PNG or WebP.'];
        }
        $file = $name . '.' . $ext_map[$mime];
        if (!@copy($source_path, $dir . DIRECTORY_SEPARATOR . $file)) {
            return [null, 'Could not save the image to the server.'];
        }
        return ['uploads/' . $subdir . '/' . $file, null];
    }

    switch ($mime) {
        case 'image/jpeg': $img = @imagecreatefromjpeg($source_path); break;
        case 'image/png':  $img = @imagecreatefrompng($source_path); break;
        case 'image/gif':  $img = @imagecreatefromgif($source_path); break;
        case 'image/webp': $img = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($source_path) : false; break;
        case 'image/bmp':
        case 'image/x-ms-bmp': $img = function_exists('imagecreatefrombmp') ? @imagecreatefrombmp($source_path) : false; break;
        default: $img = false;
    }
    if (!$img) {
        return [null, 'This image format (' . htmlspecialchars($mime) . ') is not supported. Please upload a JPG or PNG photo. (iPhone HEIC photos: change Camera > Formats to "Most Compatible" or take a screenshot.)'];
    }

    // Fix sideways phone photos using EXIF orientation
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $exif = @exif_read_data($source_path);
        $orientation = $exif['Orientation'] ?? 1;
        if ($orientation == 3) $img = imagerotate($img, 180, 0);
        elseif ($orientation == 6) $img = imagerotate($img, -90, 0);
        elseif ($orientation == 8) $img = imagerotate($img, 90, 0);
    }

    $w = imagesx($img);
    $h = imagesy($img);
    $scale = min(1, $max_px / max($w, $h));
    $nw = max(1, (int)round($w * $scale));
    $nh = max(1, (int)round($h * $scale));
    $out = imagecreatetruecolor($nw, $nh);

    $as_png = $keep_png && in_array($mime, ['image/png', 'image/webp', 'image/gif'], true);
    if ($as_png) {
        imagealphablending($out, false);
        imagesavealpha($out, true);
        imagefill($out, 0, 0, imagecolorallocatealpha($out, 0, 0, 0, 127));
    } else {
        imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));
    }
    imagecopyresampled($out, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);

    $file = $name . ($as_png ? '.png' : '.jpg');
    $dest = $dir . DIRECTORY_SEPARATOR . $file;
    $ok = $as_png ? imagepng($out, $dest, 6) : imagejpeg($out, $dest, 85);
    imagedestroy($img);
    imagedestroy($out);
    if (!$ok) {
        return [null, 'Could not save the image to the server (uploads/' . $subdir . ').'];
    }
    @chmod($dest, 0644);
    return ['uploads/' . $subdir . '/' . $file, null];
}

/**
 * Validate and save an uploaded image from $_FILES.
 * @return array [relative_path|null, error|null]  (both null when no file was chosen)
 */
function save_uploaded_image($field, $subdir, $prefix, $required = false, $max_px = 800, $keep_png = false) {
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return [null, $required ? 'Please upload a passport photograph.' : null];
    }
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        return [null, upload_error_message($f['error'])];
    }
    if ($f['size'] > UPLOAD_MAX_SIZE) {
        return [null, upload_error_message(UPLOAD_ERR_INI_SIZE)];
    }
    if (!is_uploaded_file($f['tmp_name'])) {
        return [null, 'Invalid upload.'];
    }
    return store_image_file($f['tmp_name'], $subdir, $prefix, $max_px, $keep_png);
}

/**
 * Save a base64 data URL (from the webcam) as a JPEG.
 * @return array [relative_path|null, error|null]
 */
function save_data_url_image($data_url, $subdir, $prefix, $max_px = 640) {
    if (!preg_match('#^data:image/(jpeg|jpg|png|webp);base64,(.+)$#', (string)$data_url, $m)) {
        return [null, 'No face photo was captured. Please allow camera access and take your photo.'];
    }
    $raw = base64_decode($m[2], true);
    if ($raw === false || strlen($raw) < 1000 || strlen($raw) > UPLOAD_MAX_SIZE) {
        return [null, 'The captured photo is invalid. Please retake it.'];
    }
    $tmp = tempnam(sys_get_temp_dir(), 'cap');
    file_put_contents($tmp, $raw);
    $result = store_image_file($tmp, $subdir, $prefix, $max_px);
    @unlink($tmp);
    return $result;
}

/** Delete a previously stored upload (only inside the uploads folder). */
function delete_upload($relative_path) {
    if (empty($relative_path) || !str_starts_with($relative_path, 'uploads/') || str_contains($relative_path, '..')) {
        return;
    }
    $full = BASE_PATH . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative_path);
    if (is_file($full)) {
        @unlink($full);
    }
}

/** Public URL of an upload, or the placeholder when missing. */
function photo_url($relative_path) {
    if (!empty($relative_path) && is_file(BASE_PATH . '/' . $relative_path)) {
        return get_base_url() . '/' . $relative_path . '?v=' . filemtime(BASE_PATH . '/' . $relative_path);
    }
    return get_base_url() . '/assets/images/logo-placeholder.png';
}

/* ------------------------------------------------------------------ *
 * GPS attendance geofencing
 * ------------------------------------------------------------------ */

/** Distance in metres between two GPS points (haversine). */
function gps_distance_m($lat1, $lng1, $lat2, $lng2) {
    $r = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    return 2 * $r * asin(min(1, sqrt($a)));
}

/** Active locations a staff member may clock in at (assigned ones, or all when none assigned). */
function staff_allowed_locations($staff_pk) {
    global $pdo;
    $st = $pdo->prepare("SELECT l.* FROM `attendance_locations` l JOIN `staff_locations` sl ON sl.location_id = l.id
                         WHERE sl.staff_id = ? AND l.is_active = 1 ORDER BY l.name");
    $st->execute([$staff_pk]);
    $rows = $st->fetchAll();
    if (!$rows) {
        $assigned = $pdo->prepare("SELECT COUNT(*) FROM `staff_locations` WHERE `staff_id` = ?");
        $assigned->execute([$staff_pk]);
        if ((int)$assigned->fetchColumn() === 0) {
            $rows = $pdo->query("SELECT * FROM `attendance_locations` WHERE `is_active` = 1 ORDER BY `name`")->fetchAll();
        }
    }
    return $rows;
}

/**
 * Check a GPS reading against the allowed locations.
 * @return array ['ok'=>bool, 'location'=>row|null, 'distance'=>int|null, 'error'=>string|null]
 */
function check_gps_position($staff_pk, $lat, $lng, $accuracy) {
    $locs = staff_allowed_locations($staff_pk);
    if (!$locs) {
        return ['ok' => false, 'location' => null, 'distance' => null, 'error' => 'No attendance location is set up for you. Please contact HR.'];
    }
    if (!is_numeric($lat) || !is_numeric($lng) || abs($lat) > 90 || abs($lng) > 180 || ((float)$lat == 0.0 && (float)$lng == 0.0)) {
        return ['ok' => false, 'location' => null, 'distance' => null, 'error' => 'Your GPS location was not received. Turn on Location for this browser and try again.'];
    }
    $max_acc = max(50, intval(get_setting('gps_max_accuracy', '1000')));
    if ($accuracy > $max_acc) {
        return ['ok' => false, 'location' => null, 'distance' => null, 'error' => "Your GPS signal is too weak (about " . round($accuracy) . " m). Turn on precise location / GPS, move near a window or outside, and try again."];
    }
    $best = null;
    $best_d = PHP_INT_MAX;
    foreach ($locs as $l) {
        $d = gps_distance_m((float)$lat, (float)$lng, (float)$l['latitude'], (float)$l['longitude']);
        // Allow for normal GPS error (up to 100 m) at the edge of the area
        $effective = $d - min((float)$accuracy, 100);
        if ($effective <= $l['radius_m'] && $d < $best_d) {
            $best = $l;
            $best_d = $d;
        }
    }
    if ($best) {
        return ['ok' => true, 'location' => $best, 'distance' => (int)round($best_d), 'error' => null];
    }
    // Nearest location for the error message
    $near = null; $near_d = PHP_INT_MAX;
    foreach ($locs as $l) {
        $d = gps_distance_m((float)$lat, (float)$lng, (float)$l['latitude'], (float)$l['longitude']);
        if ($d < $near_d) { $near = $l; $near_d = $d; }
    }
    $dist_txt = $near_d >= 1000 ? round($near_d / 1000, 1) . ' km' : round($near_d) . ' m';
    return ['ok' => false, 'location' => null, 'distance' => (int)round($near_d),
        'error' => "You are not at an approved work location. Nearest: {$near['name']} ($dist_txt away, allowed {$near['radius_m']} m)."];
}

/* ------------------------------------------------------------------ *
 * Face recognition (128-number face descriptors from face-api.js)
 * ------------------------------------------------------------------ */

/** Parse a JSON face descriptor; returns array of 128 floats or null. */
function parse_face_descriptor($json) {
    $arr = json_decode((string)$json, true);
    if (!is_array($arr) || count($arr) !== 128) return null;
    $out = [];
    foreach ($arr as $v) {
        if (!is_numeric($v) || abs($v) > 5) return null;
        $out[] = (float)$v;
    }
    return $out;
}

/** Max distance between a live face and the passport photo when registering a face (photo vs camera). */
const FACE_PASSPORT_MAX = 0.5;

/** Euclidean distance between two descriptors (0 = identical; < ~0.55 = same person). */
function face_distance(array $a, array $b) {
    $sum = 0.0;
    for ($i = 0; $i < 128; $i++) {
        $d = $a[$i] - $b[$i];
        $sum += $d * $d;
    }
    return sqrt($sum);
}

/* ------------------------------------------------------------------ *
 * Managing Director approvals
 * ------------------------------------------------------------------ */

/** Active Managing Director accounts (for approval emails). */
function md_accounts() {
    global $pdo;
    return $pdo->query("SELECT `id`, `email`, `first_name`, `last_name`, `display_name` FROM `staff` WHERE `role` = 'Managing Director' AND `status` = 'Active'")->fetchAll();
}

/** Tell every MD that something is waiting for approval. */
function notify_md_pending($what, $title, $from_name) {
    if (!function_exists('send_email')) require_once __DIR__ . '/mail.php';
    $link = get_base_url() . '/admin/approvals.php';
    foreach (md_accounts() as $md) {
        add_notification($md['id'], "Approval needed: $what", "\"$title\" from $from_name is waiting for your approval.");
        send_email($md['email'], display_name($md), "Approval Needed: $what - $title",
            "<p><strong>" . htmlspecialchars($from_name) . "</strong> has sent a <strong>" . htmlspecialchars($what) . "</strong> for your approval:</p>
             <p style='font-size:16px;'><strong>" . htmlspecialchars($title) . "</strong></p>
             <p>Open the approvals page to read it on the company letterhead and approve or return it with comments.</p>
             <p><a href='$link' class='btn'>Review &amp; Approve</a></p>");
    }
    return count(md_accounts());
}
