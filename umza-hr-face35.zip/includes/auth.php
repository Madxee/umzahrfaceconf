<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Authentication, Session Safety & RBAC
 */

require_once __DIR__ . '/db.php';
secure_session_start();

/**
 * Check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Require user to be logged in, otherwise redirect to login
 */
function require_login() {
    if (!is_logged_in()) {
        header("Location: " . get_base_url() . "/index.php");
        exit;
    }
}

/**
 * Check if the user has one of the allowed roles
 * @param array $allowed_roles
 */
function require_role($allowed_roles) {
    require_login();
    if (!in_array($_SESSION['role'], $allowed_roles)) {
        // Log unauthorized access attempt
        log_activity($_SESSION['user_id'], 'UNAUTHORIZED_ACCESS_ATTEMPT', 'Attempted to access page requiring roles: ' . implode(', ', $allowed_roles));
        header("Location: " . get_base_url() . "/index.php?error=unauthorized");
        exit;
    }
}

/**
 * Get Base URL dynamically
 */
function get_base_url() {
    $protocol = "http";
    if (
        (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on' || $_SERVER['HTTPS'] === 1)) ||
        (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') ||
        (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on') ||
        (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ||
        (isset($_SERVER['REQUEST_SCHEME']) && strtolower($_SERVER['REQUEST_SCHEME']) === 'https') ||
        (isset($_SERVER['HTTP_X_FORWARDED_PORT']) && $_SERVER['HTTP_X_FORWARDED_PORT'] == 443) ||
        (isset($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) === 'on') ||
        (isset($_SERVER['HTTP_CF_VISITOR']) && str_contains($_SERVER['HTTP_CF_VISITOR'], 'https'))
    ) {
        $protocol = "https";
    }
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    
    // Use SCRIPT_NAME to dynamically determine the subfolder path relative to Document Root
    $script_name = $_SERVER['SCRIPT_NAME'] ?? '';
    $relative_path = '';
    
    if (!empty($script_name)) {
        $dir = dirname($script_name);
        $dir = str_replace('\\', '/', $dir);
        
        // Remove admin or staff subfolders to get the project base path
        if (str_ends_with($dir, '/admin')) {
            $dir = substr($dir, 0, -6);
        } elseif (str_ends_with($dir, '/staff')) {
            $dir = substr($dir, 0, -6);
        }
        
        $relative_path = rtrim($dir, '/');
    }
    
    return $protocol . "://" . $host . $relative_path;
}

/**
 * Site path without scheme/host (e.g. "" or "/umza-hr"). Use this in JavaScript fetches so
 * files always load from the same address as the page (avoids http/https "mixed content" blocks).
 */
function base_path() {
    $path = parse_url(get_base_url(), PHP_URL_PATH) ?? '';
    return rtrim($path, '/');
}

/** Same-site path of an uploaded file (for JavaScript). */
function upload_path_url($relative_path) {
    if (empty($relative_path) || !is_file(BASE_PATH . '/' . $relative_path)) return '';
    return base_path() . '/' . $relative_path . '?v=' . filemtime(BASE_PATH . '/' . $relative_path);
}

/**
 * Generate CSRF Token for Forms
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF Token from Form Submissions
 */
function verify_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Input sanitization helper (Anti-XSS)
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Output data safely (Alias for sanitize)
 */
function e($data) {
    echo sanitize($data);
}

/**
 * Formats a date nicely
 */
function format_date($date_str, $format = 'M d, Y') {
    if (empty($date_str)) return 'N/A';
    return date($format, strtotime($date_str));
}

/**
 * Formats a date time nicely
 */
function format_datetime($datetime_str, $format = 'M d, Y h:i A') {
    if (empty($datetime_str)) return 'N/A';
    return date($format, strtotime($datetime_str));
}

/**
 * Safely get MIME type of an uploaded file without crashing if fileinfo is disabled
 */
function get_file_mime($file_tmp, $fallback_mime = '') {
    $file_mime = '';
    
    // Safely check for finfo and FILEINFO_MIME_TYPE constant existence
    if (class_exists('finfo') && defined('FILEINFO_MIME_TYPE')) {
        try {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $file_mime = $finfo->file($file_tmp);
        } catch (Exception $e) {
            // Fail silently
        }
    }
    
    // Fallback to mime_content_type if available
    if (empty($file_mime) && function_exists('mime_content_type')) {
        $file_mime = @mime_content_type($file_tmp);
    }
    
    // If still empty, use the provided fallback
    if (empty($file_mime)) {
        $file_mime = $fallback_mime;
    }
    
    return $file_mime;
}
