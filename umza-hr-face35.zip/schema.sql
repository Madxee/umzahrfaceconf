-- UMZA Aviation Services Ltd - HR Management Portal Database Schema
-- For XAMPP / cPanel Shared Hosting (MySQL 8+ / MariaDB)

-- Database schema tables are imported directly into the selected cPanel database.

-- 1. DEPARTMENTS
CREATE TABLE IF NOT EXISTS `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. POSITIONS
CREATE TABLE IF NOT EXISTS `positions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(100) NOT NULL,
  `department_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. STAFF
CREATE TABLE IF NOT EXISTS `staff` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` VARCHAR(50) NOT NULL UNIQUE,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `gender` ENUM('Male', 'Female', 'Other') NOT NULL,
  `dob` DATE NOT NULL,
  `passport_photo` VARCHAR(255) DEFAULT NULL,
  `department_id` INT DEFAULT NULL,
  `position_id` INT DEFAULT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `phone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  `employment_date` DATE NOT NULL,
  `emergency_contact` TEXT NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('Super Admin', 'HR Manager', 'HR Officer', 'Department Head', 'Staff') DEFAULT 'Staff',
  `status` ENUM('Pending', 'Active', 'Suspended') DEFAULT 'Pending',
  `email_verified` TINYINT(1) DEFAULT 0,
  `verification_token` VARCHAR(100) DEFAULT NULL,
  `reset_token` VARCHAR(100) DEFAULT NULL,
  `reset_expires` DATETIME DEFAULT NULL,
  `blood_group` VARCHAR(10) DEFAULT NULL,
  `allergies` VARCHAR(255) DEFAULT 'N/A',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. LEAVE REQUESTS
CREATE TABLE IF NOT EXISTS `leave_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL,
  `leave_type` ENUM('Annual Leave', 'Sick Leave', 'Casual Leave', 'Maternity Leave', 'Paternity Leave', 'Emergency Leave') NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `duration` INT NOT NULL,
  `reason` TEXT NOT NULL,
  `status` ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
  `hr_remarks` TEXT DEFAULT NULL,
  `approved_by` INT DEFAULT NULL,
  `attachment_path` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`approved_by`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. LEAVE QUOTAS
CREATE TABLE IF NOT EXISTS `leave_quotas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL,
  `year` INT NOT NULL,
  `allocated` INT NOT NULL DEFAULT 30,
  `used` INT NOT NULL DEFAULT 0,
  `remaining` INT NOT NULL DEFAULT 30,
  UNIQUE KEY `staff_year` (`staff_id`, `year`),
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. COMPLAINTS
CREATE TABLE IF NOT EXISTS `complaints` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `tracking_number` VARCHAR(50) NOT NULL UNIQUE,
  `staff_id` INT NOT NULL,
  `type` ENUM('HR Complaint', 'Management Complaint', 'Payroll Complaint', 'Workplace Complaint', 'Other Complaint') NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `status` ENUM('Pending', 'Under Review', 'Resolved', 'Closed') DEFAULT 'Pending',
  `hr_response` TEXT DEFAULT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. COMPLAINT FILES
CREATE TABLE IF NOT EXISTS `complaint_files` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `complaint_id` INT NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_type` VARCHAR(100) NOT NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`complaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. MEMOS
CREATE TABLE IF NOT EXISTS `memos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `type` ENUM('Internal Memo', 'Circular', 'Announcement', 'Policy Update', 'Company News') NOT NULL,
  `content` TEXT NOT NULL,
  `file_path` VARCHAR(255) DEFAULT NULL,
  `created_by` INT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. QUERIES
CREATE TABLE IF NOT EXISTS `queries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `reason` TEXT NOT NULL,
  `description` TEXT NOT NULL,
  `deadline` DATE NOT NULL,
  `status` ENUM('Issued', 'Replied', 'Resolved', 'Escalated') DEFAULT 'Issued',
  `issued_by` INT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`issued_by`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. QUERY REPLIES
CREATE TABLE IF NOT EXISTS `query_replies` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `query_id` INT NOT NULL,
  `reply_text` TEXT NOT NULL,
  `file_path` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`query_id`) REFERENCES `queries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. STAFF IDS (FOR PRINTING AND QR VERIFICATION)
CREATE TABLE IF NOT EXISTS `staff_ids` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL UNIQUE,
  `verification_token` VARCHAR(255) NOT NULL UNIQUE,
  `issue_date` DATE NOT NULL,
  `expiry_date` DATE NOT NULL,
  `status` ENUM('Active', 'Suspended', 'Expired') DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. NOTIFICATIONS (IN-APP)
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. DOCUMENTS (CV, CERTIFICATES, CONTRACTS)
CREATE TABLE IF NOT EXISTS `documents` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `type` ENUM('CV', 'Certificate', 'Employment Document', 'Other') NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `status` ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. PERFORMANCE REPORTS (APPRAISALS, APPRAISAL RATINGS, PROMOTIONS)
CREATE TABLE IF NOT EXISTS `performance_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `staff_id` INT NOT NULL,
  `type` ENUM('Performance Report', 'Appraisal', 'Rating', 'Promotion', 'Commendation') NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `rating` INT DEFAULT NULL, -- 1 to 5 stars
  `details` TEXT NOT NULL,
  `effective_date` DATE DEFAULT NULL,
  `created_by` INT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. ACTIVITY LOGS (AUDIT TRAIL)
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `action` VARCHAR(255) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. SETTINGS
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(50) NOT NULL UNIQUE,
  `setting_value` TEXT DEFAULT NULL,
  `description` VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ==========================================
-- DEFAULT DATA SEEDING
-- ==========================================

-- Seeding Departments
INSERT INTO `departments` (`id`, `name`) VALUES
(1, 'Admin/HR'),
(2, 'Finance / Account'),
(3, 'Flight Operations'),
(4, 'ENGR / Maintenance'),
(5, 'Operations Control Centre (OCC)'),
(6, 'Cabin Services Dept'),
(7, 'Commercial'),
(8, 'IT'),
(9, 'Ground Operations'),
(10, 'Aviation Security'),
(11, 'Quality & Safety');

-- Seeding Positions for Departments
INSERT INTO `positions` (`title`, `department_id`) VALUES
-- Admin/HR
('Head of Admin', 1),
('Admin Officer', 1),
('Office Assistant', 1),
('Flight Operation Admin', 1),
('Drivers', 1),
('Cleaners', 1),
-- Finance / Account
('Head of Account', 2),
('Auditor', 2),
('Account Officer', 2),
('Reconciliation Officer', 2),
('Store and Inventory Officer', 2),
-- Flight Operations
('Director of Flight Operations', 3),
('Chief Pilot', 3),
('Pilot / Captain', 3),
('Pilot / Senior First Officer', 3),
('Pilot / First Officer', 3),
-- ENGR / Maintenance
('Director of Maintenance / DCA', 4),
('Line Maintenance Manager', 4),
('Station Engineer', 4),
('Engineers', 4),
('Technician', 4),
('Asst Technicians', 4),
('Technical Record Officer', 4),
-- Operations Control Centre (OCC)
('OCC Manager', 5),
('OCC Supervisor', 5),
('Crew Scheduler', 5),
('Senior Dispatcher', 5),
('Flight Dispatcher', 5),
('Junior Flight Dispatcher', 5),
-- Cabin Services Dept
('Cabin Services Manager', 6),
('Assistant Cabin Services Manager', 6),
('Inflight Crew', 6),
('Purser', 6),
('Senior Cabin Crew', 6),
('Cabin Crew', 6),
-- Commercial
('Head of Commercial', 7),
('Customer Service Manager', 7),
('Customer Service Agent', 7),
-- IT
('Head of IT', 8),
('System Admin / Officer', 8),
('IT Officer', 8),
-- Ground Operations
('Head of Ground Operations', 9),
('Station Manager', 9),
('Deputy Station Managers', 9),
('Ticketing Supervisors', 9),
('Ticketing and Reservation Officer', 9),
-- Aviation Security
('Head of Security', 10),
('Station Security Supervisor', 10),
('Aviation Security Officer', 10),
-- Quality & Safety
('Head of Quality', 11),
('Safety Inspector', 11),
('Document Control', 11),
('Librarian', 11),
('Health and Safety Environment Officer', 11);

-- Seeding Initial Settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('company_name', 'UMZA Aviation Services Ltd', 'Name of the company'),
('system_email', 'info@madzeedigitalservices.name.ng', 'System email address'),
('smtp_host', 'mail.madzeedigitalservices.name.ng', 'SMTP Host name'),
('smtp_port', '465', 'SMTP Port (e.g. 587, 465, 25)'),
('smtp_user', 'info@madzeedigitalservices.name.ng', 'SMTP username'),
('smtp_pass', 'Madzee44225@', 'SMTP password'),
('smtp_secure', 'ssl', 'SMTP security protocols: tls, ssl, or none'),
('default_annual_leave_quota', '30', 'Default allocated annual leave days per year'),
('id_card_validity_years', '3', 'Number of years a staff ID card is valid for'),
('id_card_signature_image', '', 'Path to the uploaded signature image file'),
('id_card_signature_name', 'Abubakar M. Natiti', 'Name printed below signature on ID cards'),
('id_card_signature_title', 'HEAD HUMAN RESOURCES', 'Title printed below signature on ID cards'),
('company_address', 'Suite D1 UYK HEXAHUB, Plot 1077A Balanga Crescent, Off Uke Street, Area 11, Garki, Abuja', 'Official company head office address'),
('company_phone', '+234 803 3475 657', 'Official company contact telephone number');

-- Seeding Admin Accounts
-- Super Admin: Password is 'AdminPass123!' -> Hashed using PASSWORD_DEFAULT
-- HR Manager (Assistant): Password is 'AssistantPass123!' -> Hashed using PASSWORD_DEFAULT
INSERT INTO `staff` (
  `staff_id`, `first_name`, `last_name`, `gender`, `dob`, `department_id`, `position_id`,
  `email`, `phone`, `address`, `employment_date`, `emergency_contact`,
  `password_hash`, `role`, `status`, `email_verified`
) VALUES (
  'UMZA001', 'System', 'Administrator', 'Male', '1985-01-01', 1, 1,
  'admin@umzaair.com', '+2348000000000', 'UMZA Aviation Headquarters, Lagos, Nigeria', '2020-01-01', 'Emergency Contact: HR Dept',
  '$2y$10$XA3l1apRGWzoDgHCxKkSFu..6sAo6IFj0b3y4dtMFInh5byG4HIXC', 'Super Admin', 'Active', 1
), (
  'UMZA002', 'Assistant', 'Administrator', 'Female', '1990-01-01', 1, 2,
  'assistant@umzaair.com', '+2348000000001', 'UMZA Aviation Headquarters, Lagos, Nigeria', '2021-01-01', 'Emergency Contact: HR Dept',
  '$2y$10$wbjjdC78B6YMID3JblmnGuawvcQfHltSc0gaPWMDptIZdHI0utkby', 'HR Manager', 'Active', 1
);
