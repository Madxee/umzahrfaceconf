<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Password Reset Completion Page
 */

require_once 'includes/auth.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: staff/dashboard.php");
    exit;
}

$error = '';
$success = '';
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$user_id = null;

if (empty($token)) {
    $error = "No reset token provided. Please use the link sent to your email.";
} else {
    try {
        // Validate token and expiration
        $stmt = $pdo->prepare("SELECT `id` FROM `staff` WHERE `reset_token` = ? AND `reset_expires` > NOW()");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if (!$user) {
            $error = "The password reset token is invalid or has expired. Please request a new link.";
        } else {
            $user_id = $user['id'];
        }
    } catch (PDOException $e) {
        $error = "A database error occurred. Please try again later.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error && $user_id) {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF Token validation failed.";
    } elseif (empty($password) || empty($confirm_password)) {
        $error = "Please fill in all fields.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        try {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Update password and clear token
            $update = $pdo->prepare("UPDATE `staff` SET `password_hash` = ?, `reset_token` = NULL, `reset_expires` = NULL WHERE `id` = ?");
            $update->execute([$password_hash, $user_id]);
            
            // Log activity
            log_activity($user_id, 'PASSWORD_RESET_COMPLETED', 'Password reset completed successfully using email token.');
            
            header("Location: index.php?success=" . urlencode("Password updated successfully."));
            exit;
        } catch (PDOException $e) {
            $error = "A database error occurred. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
</head>
<body class="auth-wrapper">

    <div class="auth-card">
        <div class="auth-header">
            <div class="id-card-logo-placeholder mx-auto">
                <i class="fa-solid fa-plane-departure"></i>
            </div>
            <h2 class="mt-2 fw-bold text-aviation">UMZA Aviation</h2>
            <p class="text-muted">Reset Password</p>
        </div>
        
        <div class="auth-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                </div>
                <a href="forgot-password.php" class="btn btn-aviation w-100 py-2">Request New Link</a>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
                </div>
                <a href="index.php" class="btn btn-aviation w-100 py-2">Go to Login</a>
            <?php endif; ?>

            <?php if (empty($error) && empty($success) && $user_id): ?>
                <form action="reset-password.php" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    
                    <div class="form-floating mb-3">
                        <input type="password" class="form-control" id="password" name="password" minlength="8" placeholder="New Password" required>
                        <label for="password"><i class="fa-solid fa-lock me-2 text-muted"></i>New Password</label>
                        <div class="form-text" style="font-size: 0.75rem;">Minimum 8 characters</div>
                    </div>
                    
                    <div class="form-floating mb-4">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="8" placeholder="Confirm Password" required>
                        <label for="confirm_password"><i class="fa-solid fa-circle-check me-2 text-muted"></i>Confirm Password</label>
                    </div>
                    
                    <button type="submit" class="btn btn-aviation w-100 py-3 mb-3">
                        <i class="fa-solid fa-key me-2"></i>Update Password
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
