<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Forgot Password Request Page
 */

require_once 'includes/auth.php';
require_once 'includes/mail.php';

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: staff/dashboard.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $email = trim(strtolower($_POST['email']));
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF Token validation failed.";
    } elseif (empty($email)) {
        $error = "Please enter your email address.";
    } else {
        try {
            // Find staff member
            $stmt = $pdo->prepare("SELECT `id`, `first_name`, `last_name`, `display_name` FROM `staff` WHERE `email` = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            // To prevent username enumeration, we can show a success message regardless of whether the email exists.
            // But since this is a private company directory, showing explicit error helps the staff who might have made a typo.
            if ($user) {
                $reset_token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                $update = $pdo->prepare("UPDATE `staff` SET `reset_token` = ?, `reset_expires` = ? WHERE `id` = ?");
                $update->execute([$reset_token, $expires, $user['id']]);
                
                // Log activity
                log_activity($user['id'], 'PASSWORD_RESET_REQUESTED', 'Requested a password reset link.');
                
                // Send Email
                $reset_link = get_base_url() . "/reset-password.php?token=" . $reset_token;
                $subject = "Password Reset Link - UMZA Aviation Services Ltd";
                $email_body = "
                    <p>You are receiving this email because a password reset request was submitted for your account on the UMZA Aviation Services Ltd HR Portal.</p>
                    <p>Click the link below to set a new password. This link is valid for 1 hour:</p>
                    <p><a href='$reset_link' class='btn'>Reset Password</a></p>
                    <p>If you did not request this, you can safely ignore this email.</p>";
                
                try {
                    send_email($email, display_name($user), $subject, $email_body);
                } catch (Exception $mail_err) {
                    error_log("Failed to send password recovery email: " . $mail_err->getMessage());
                }
            }
            
            header("Location: index.php?success=" . urlencode("If the email exists, a password reset link has been dispatched."));
            exit;
        } catch (PDOException $e) {
            $error = "A database error occurred. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
</head>
<body class="auth-wrapper">

    <div class="auth-card">
        <div class="auth-header">
            <div class="id-card-logo-placeholder mx-auto">
                <i class="fa-solid fa-plane-departure"></i>
            </div>
            <h2 class="mt-2 fw-bold text-aviation">UMZA Aviation</h2>
            <p class="text-muted">Password Recovery</p>
        </div>
        
        <div class="auth-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-check me-2"></i> <?php echo $success; ?>
                </div>
                <a href="index.php" class="btn btn-aviation w-100 py-2">Back to Login</a>
            <?php else: ?>

            <p class="text-muted text-center mb-4" style="font-size: 0.9rem;">
                Enter your official registered email address, and we will send you a secure link to reset your password.
            </p>

            <form action="forgot-password.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="form-floating mb-4">
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                    <label for="email"><i class="fa-solid fa-envelope me-2 text-muted"></i>Company Email Address</label>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-3 mb-3">
                    <i class="fa-solid fa-paper-plane me-2"></i>Send Reset Link
                </button>
                
                <div class="text-center mt-3">
                    <a href="index.php" class="text-aviation fw-semibold text-decoration-none" style="font-size: 0.85rem;">
                        <i class="fa-solid fa-arrow-left me-1"></i>Back to Login
                    </a>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
