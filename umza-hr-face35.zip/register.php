<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Registration Form
 */

require_once 'includes/auth.php';
require_once 'includes/mail.php';

if (!feature_enabled('registration')) {
    header("Location: index.php?error=" . urlencode("Self-registration is currently closed. Please contact the HR department."));
    exit;
}

// Redirect if already logged in
if (is_logged_in()) {
    header("Location: staff/dashboard.php");
    exit;
}

$error = '';
$success = '';

// Load departments for select dropdown
try {
    $departments = $pdo->query("SELECT * FROM `departments` ORDER BY `name` ASC")->fetchAll();
    
    // Fetch all positions mapped by department for dynamic JS dropdown
    $raw_positions = $pdo->query("SELECT * FROM `positions` WHERE `is_active` = 1 ORDER BY `title` ASC")->fetchAll();
    $positions_map = [];
    foreach ($raw_positions as $pos) {
        $positions_map[$pos['department_id']][] = [
            'id' => $pos['id'],
            'title' => $pos['title']
        ];
    }
    // Work stations (GPS attendance locations set by HR)
    $stations = $pdo->query("SELECT `id`, `name`, `type`, `code`, `city` FROM `attendance_locations` WHERE `is_active` = 1 ORDER BY (`type` = 'Head Office') DESC, `type`, `name`")->fetchAll();
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
$require_station = get_setting('require_station_at_registration', '1') === '1' && count($stations) > 0;
$require_face_reg = get_setting('require_face_match', '1') === '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    // Main variables sanitization
    $staff_id = trim($_POST['staff_id'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $other_name = trim($_POST['other_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $name_format = $_POST['name_display_format'] ?? 'first_last';
    if (!array_key_exists($name_format, name_display_formats())) $name_format = 'first_last';
    $gender = $_POST['gender'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $email = trim(strtolower($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $employment_date = $_POST['employment_date'] ?? '';
    $emergency_contact = trim($_POST['emergency_contact'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $blood_group = $_POST['blood_group'] ?? '';

    $department_id = intval($_POST['department'] ?? 0);
    $position_id = intval($_POST['position'] ?? 0);
    $allowed_domain = strtolower(trim(get_setting('allowed_email_domain', ''), " @"));

    // Validations
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF Token validation failed. Please refresh the page.";
    } elseif (empty($staff_id) || empty($first_name) || empty($last_name) || empty($email) || empty($password) || empty($confirm_password) || empty($department_id) || empty($position_id)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($allowed_domain !== '' && !str_ends_with($email, '@' . $allowed_domain)) {
        $error = "Please register with your official @$allowed_domain email address.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        try {
            // Check if email or staff ID already exists
            $stmt = $pdo->prepare("SELECT `id` FROM `staff` WHERE `email` = ? OR `staff_id` = ?");
            $stmt->execute([$email, $staff_id]);
            if ($stmt->fetch()) {
                $error = "A staff member with this Email or Staff ID already exists.";
            } else {
                // Work station
                $station_id = intval($_POST['station_id'] ?? 0);
                $valid_station = in_array($station_id, array_map('intval', array_column($stations, 'id')), true);
                if ($require_station && !$valid_station) {
                    $error = "Please choose the station / office where you work.";
                }

                // Face registration (live camera) - used for attendance face recognition
                $face_desc = parse_face_descriptor($_POST['face_descriptor'] ?? '');
                $passport_desc = parse_face_descriptor($_POST['passport_descriptor'] ?? '');
                $has_face_photo = str_starts_with($_POST['face_photo'] ?? '', 'data:image/');
                if (!$error && $require_face_reg && !$face_desc && !$has_face_photo) {
                    $error = "Please capture your face: look at the camera and press Capture.";
                } elseif (!$error && $face_desc && $passport_desc && face_distance($face_desc, $passport_desc) > FACE_PASSPORT_MAX) {
                    $error = "Your live face does not match the passport photograph you uploaded. Please upload your own clear passport photo.";
                }

                // Passport photograph (uploaded image, re-saved as a clean JPEG) - used for the ID card
                $passport_photo_path = null;
                if (!$error) {
                    [$passport_photo_path, $upload_err] = save_uploaded_image('passport_photo', 'passports', 'photo', true);
                    if ($upload_err) {
                        $error = $upload_err;
                    }
                }
                $face_photo_path = null;
                if (!$error && $has_face_photo) {
                    [$face_photo_path, $face_err] = save_data_url_image($_POST['face_photo'], 'faces', 'face');
                    if ($face_err) {
                        $face_photo_path = null;
                    }
                }

                if (empty($error)) {
                    // Hash Password
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Generate verification token
                    $verification_token = bin2hex(random_bytes(32));
                    
                    // Save Staff Member as Pending and Email Unverified
                    $stmt = $pdo->prepare("INSERT INTO `staff` 
                        (`staff_id`, `first_name`, `other_name`, `last_name`, `name_display_format`, `display_name`, `gender`, `dob`, `passport_photo`, `department_id`, `position_id`, `email`, `phone`, `address`, `employment_date`, `emergency_contact`, `password_hash`, `role`, `status`, `email_verified`, `verification_token`, `verification_sent_at`, `blood_group`)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Staff', 'Pending', 0, ?, NOW(), ?)");
                    
                    $stmt->execute([
                        $staff_id, $first_name, ($other_name !== '' ? $other_name : null), $last_name, $name_format,
                        compose_display_name($first_name, $other_name, $last_name, $name_format),
                        $gender, $dob, $passport_photo_path,
                        $department_id, $position_id, $email, $phone, $address, $employment_date,
                        $emergency_contact, $password_hash, $verification_token, $blood_group
                    ]);
                    
                    $new_user_id = $pdo->lastInsertId();

                    // Face reference from the registration capture + chosen work station
                    if ($face_desc) {
                        $pdo->prepare("UPDATE `staff` SET `face_descriptor` = ?, `face_source` = 'registration', `face_photo` = ?, `face_descriptor_photo` = NULL, `face_enrolled_by` = 'self', `face_enrolled_at` = NOW() WHERE `id` = ?")
                            ->execute([json_encode($face_desc), $face_photo_path, $new_user_id]);
                    } elseif ($face_photo_path) {
                        // Photo kept; the face pattern is created at the first clock-in (checked against this photo and the passport)
                        $pdo->prepare("UPDATE `staff` SET `face_photo` = ? WHERE `id` = ?")->execute([$face_photo_path, $new_user_id]);
                    }
                    if ($valid_station) {
                        $pdo->prepare("INSERT IGNORE INTO `staff_locations` (`staff_id`, `location_id`) VALUES (?, ?)")->execute([$new_user_id, $station_id]);
                    }
                    
                    // Create Default Leave Quotas for Current Year
                    $current_year = intval(date('Y'));
                    $default_quota = intval(get_setting('default_annual_leave_quota', 30));
                    $quota_stmt = $pdo->prepare("INSERT INTO `leave_quotas` (`staff_id`, `year`, `allocated`, `used`, `remaining`) VALUES (?, ?, ?, 0, ?)");
                    $quota_stmt->execute([$new_user_id, $current_year, $default_quota, $default_quota]);
                    
                    // Audit log
                    log_activity($new_user_id, 'STAFF_REGISTRATION_SUBMITTED', 'Registration submitted under Pending status. Email verification generated.');
                    
                    // Send Email Verification
                    $display = compose_display_name($first_name, $other_name, $last_name, $name_format);
                    $verify_sent = send_verification_email($email, $display, $verification_token);

                    try {
                        // Notify HR Admins
                        $hr_stmt = $pdo->query("SELECT `email`, `first_name` FROM `staff` WHERE `role` IN ('Super Admin', 'HR Director', 'HR Manager') AND `status` = 'Active'");
                        $hr_admins = $hr_stmt->fetchAll();
                        
                        foreach ($hr_admins as $admin) {
                            $hr_subject = "New Registration Alert - $display";
                            $hr_body = "
                                <p>A new staff registration has been submitted:</p>
                                <ul>
                                    <li><strong>Name:</strong> " . htmlspecialchars($display) . "</li>
                                    <li><strong>Staff ID:</strong> " . htmlspecialchars($staff_id) . "</li>
                                    <li><strong>Email:</strong> " . htmlspecialchars($email) . "</li>
                                    <li><strong>Department:</strong> " . get_department_name($department_id) . "</li>
                                </ul>
                                <p>Please log in to the HR Portal Admin Panel to review and approve/reject this profile.</p>
                                <p><a href='" . get_base_url() . "/admin/staff.php' class='btn'>Go to Staff Directory</a></p>";
                            send_email($admin['email'], $admin['first_name'], $hr_subject, $hr_body);
                        }
                    } catch (Exception $mail_err) {
                        error_log("Failed to send HR registration notification: " . $mail_err->getMessage());
                    }

                    if ($verify_sent) {
                        $msg = "Account created successfully. A verification link has been sent to $email. Please check your inbox (and Spam folder), verify your email, then wait for HR approval.";
                        header("Location: index.php?success=" . urlencode($msg));
                    } else {
                        $msg = "Account created, but the verification email could not be sent right now. Use \"Resend verification email\" below, or ask HR to verify your account.";
                        header("Location: index.php?error=" . urlencode($msg) . "&resend=" . urlencode($email));
                    }
                    exit;
                }
            }
        } catch (PDOException $e) {
            $error = "A database error occurred: " . $e->getMessage();
        }
    }
}

// Helper function for department name lookup
function get_department_name($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT `name` FROM `departments` WHERE `id` = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ? $row['name'] : 'Unknown';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - Staff Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
</head>
<body class="auth-wrapper">

    <div class="auth-card auth-register-card">
        <div class="auth-header">
            <div class="id-card-logo-placeholder mx-auto">
                <i class="fa-solid fa-plane-departure"></i>
            </div>
            <h2 class="mt-2 fw-bold text-aviation">UMZA Aviation</h2>
            <p class="text-muted">Staff Portal Self-Registration</p>
        </div>
        
        <div class="auth-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-check me-2"></i> <?php echo $success; ?>
                    <div class="mt-3">
                        <a href="index.php" class="btn btn-aviation btn-sm">Return to Login</a>
                    </div>
                </div>
            <?php else: ?>

            <form action="register.php" method="POST" enctype="multipart/form-data" id="registerForm">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="row">
                    <!-- Column 1 -->
                    <div class="col-md-6">
                        <h5 class="mb-3 text-aviation border-bottom pb-2"><i class="fa-solid fa-user me-2"></i>Personal Information</h5>
                        
                        <div class="mb-3">
                            <label class="form-label" for="staff_id">Staff ID / Number *</label>
                            <input type="text" class="form-control" id="staff_id" name="staff_id" placeholder="e.g. UMZA002" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="first_name">First Name *</label>
                                <input type="text" class="form-control name-part" id="first_name" name="first_name" value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="other_name">Other Name</label>
                                <input type="text" class="form-control name-part" id="other_name" name="other_name" value="<?php echo htmlspecialchars($_POST['other_name'] ?? ''); ?>" placeholder="Middle name">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label" for="last_name">Last Name *</label>
                                <input type="text" class="form-control name-part" id="last_name" name="last_name" value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="name_display_format">Name to display on portal &amp; ID card *</label>
                            <select class="form-select" id="name_display_format" name="name_display_format">
                                <?php echo name_format_options($_POST['first_name'] ?? '', $_POST['other_name'] ?? '', $_POST['last_name'] ?? '', $_POST['name_display_format'] ?? 'first_last'); ?>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="gender">Gender *</label>
                                <select class="form-select" id="gender" name="gender" required>
                                    <option value="">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="dob">Date of Birth *</label>
                                <input type="date" class="form-control" id="dob" name="dob" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="blood_group">Blood Group *</label>
                                <select class="form-select" id="blood_group" name="blood_group" required>
                                    <option value="">Select Blood Group</option>
                                    <option value="A+">A+</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B-">B-</option>
                                    <option value="AB+">AB+</option>
                                    <option value="AB-">AB-</option>
                                    <option value="O+">O+</option>
                                    <option value="O-">O-</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="passport_photo">Passport Photograph (JPG, PNG - Max 5MB) *</label>
                                <input type="file" class="form-control" id="passport_photo" name="passport_photo" accept="image/jpeg,image/png,image/webp" required>
                                <img id="passportPreview" class="mt-2 rounded border d-none" style="width:90px;height:110px;object-fit:cover;" alt="Preview">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="address">Residential Address *</label>
                            <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                        </div>
                    </div>

                    <!-- Column 2 -->
                    <div class="col-md-6">
                        <h5 class="mb-3 text-aviation border-bottom pb-2"><i class="fa-solid fa-briefcase me-2"></i>Employment & Contact</h5>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="department">Department *</label>
                                <select class="form-select" id="department" name="department" required>
                                    <option value="">Select Department</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="position">Position *</label>
                                <select class="form-select" id="position" name="position" required disabled>
                                    <option value="">Select Department First</option>
                                </select>
                            </div>
                        </div>

                        <?php if ($stations): ?>
                        <div class="mb-3">
                            <label class="form-label" for="station_id">Work Station / Office <?php echo $require_station ? '*' : ''; ?></label>
                            <select class="form-select" id="station_id" name="station_id" <?php echo $require_station ? 'required' : ''; ?>>
                                <option value="">Select where you work</option>
                                <?php $grp = null; foreach ($stations as $st):
                                    if ($st['type'] !== $grp) { if ($grp !== null) echo '</optgroup>'; echo '<optgroup label="' . htmlspecialchars($st['type']) . '">'; $grp = $st['type']; } ?>
                                    <option value="<?php echo $st['id']; ?>" <?php echo (int)($_POST['station_id'] ?? 0) === (int)$st['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($st['name'] . ($st['code'] ? ' (' . $st['code'] . ')' : '') . ($st['city'] ? ' - ' . $st['city'] : '')); ?></option>
                                <?php endforeach; if ($grp !== null) echo '</optgroup>'; ?>
                            </select>
                            <div class="form-text" style="font-size:0.75rem;">You will clock in for attendance at this location (GPS).</div>
                        </div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label" for="email">Official Company Email Address *</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="username@example.com" required>
                            <div class="form-text text-muted" style="font-size: 0.75rem;"><i class="fa-solid fa-info-circle me-1"></i>Please enter your official company email.</div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="phone">Phone Number *</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="employment_date">Employment Date *</label>
                                <input type="date" class="form-control" id="employment_date" name="employment_date" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="emergency_contact">Emergency Contact Information *</label>
                            <textarea class="form-control" id="emergency_contact" name="emergency_contact" rows="2" placeholder="Name, Relationship & Phone Number" required></textarea>
                        </div>

                        <h5 class="mb-3 text-aviation border-bottom pb-2 mt-4"><i class="fa-solid fa-key me-2"></i>Security credentials</h5>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="password">Password *</label>
                                <input type="password" class="form-control" id="password" name="password" minlength="8" placeholder="Min 8 chars" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label" for="confirm_password">Confirm Password *</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="8" required>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Face registration for attendance -->
                <div class="mt-3 pt-3 border-top">
                    <h5 class="mb-2 text-aviation"><i class="fa-solid fa-face-smile me-2"></i>Face Registration for Attendance <?php echo $require_face_reg ? '*' : ''; ?></h5>
                    <p class="small text-muted mb-2">Look straight at the camera and press <strong>Capture</strong>. This photo is used to recognise you when you clock in. (Your passport photograph above is used for your ID card.)</p>
                    <div class="row g-3 align-items-center">
                        <div class="col-md-5">
                            <div class="position-relative rounded overflow-hidden bg-dark" style="aspect-ratio:4/3;">
                                <video id="regVideo" autoplay playsinline muted style="width:100%;height:100%;object-fit:cover;transform:scaleX(-1);"></video>
                                <img id="regShot" class="d-none" style="width:100%;height:100%;object-fit:cover;transform:scaleX(-1);" alt="Your face">
                                <div id="regMsg" class="position-absolute top-50 start-50 translate-middle text-white small text-center px-3">Starting camera...</div>
                            </div>
                            <canvas id="regCanvas" class="d-none"></canvas>
                        </div>
                        <div class="col-md-7">
                            <div id="regStatus" class="alert alert-secondary small mb-2">Starting camera...</div>
                            <button type="button" class="btn btn-aviation" id="regCapture" disabled><i class="fa-solid fa-camera me-1"></i>Capture</button>
                            <button type="button" class="btn btn-outline-secondary d-none" id="regRetake"><i class="fa-solid fa-rotate me-1"></i>Retake</button>
                        </div>
                    </div>
                    <input type="hidden" name="face_descriptor" id="faceDescriptor">
                    <input type="hidden" name="passport_descriptor" id="passportDescriptor">
                    <input type="hidden" name="face_photo" id="facePhoto">
                </div>

                <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center">
                    <a href="index.php" class="text-aviation text-decoration-none fw-semibold"><i class="fa-solid fa-arrow-left me-1"></i>Back to Login</a>
                    <button type="submit" class="btn btn-aviation py-2 px-5">
                        <i class="fa-solid fa-user-plus me-1"></i>Submit Registration
                    </button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Inject dynamic positions map in JS -->
    <script src="<?php echo base_path(); ?>/libs/face-api/face-api.js"></script>
    <script src="<?php echo base_path(); ?>/assets/js/face-detect.js?v=<?php echo get_asset_version('assets/js/face-detect.js'); ?>"></script>
    <script>
    (function () {
        const BASE = <?php echo json_encode(base_path()); ?>;
        const REQUIRED = <?php echo $require_face_reg ? 'true' : 'false'; ?>;
        const $ = (id) => document.getElementById(id);
        const video = $('regVideo'), shot = $('regShot'), canvas = $('regCanvas');
        let stream = null, passportDesc = null, captured = false;
        const status = (t, c) => { const e = $('regStatus'); e.className = 'alert small mb-2 ' + (c || 'alert-secondary'); e.innerHTML = t; };

        function startCamera() {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                $('regMsg').textContent = location.protocol !== 'https:' ? 'The camera needs a secure (https://) connection.' : 'This browser cannot use the camera.';
                return;
            }
            navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: false })
                .then(s => { stream = s; video.srcObject = s; $('regMsg').textContent = ''; $('regCapture').disabled = false;
                             status('Look straight at the camera, then press <strong>Capture</strong>.', 'alert-info'); })
                .catch(() => { $('regMsg').textContent = 'Camera blocked. Allow camera access and reload.'; status('Camera access is needed to register your face.', 'alert-danger'); });
        }

        // Face recognition loads in the background; Capture works even while it is loading
        const modelsReady = umzaFace.init(BASE + '/libs/face-api/model');
        modelsReady.catch(() => {});

        async function readPassport(file) {
            passportDesc = null; $('passportDescriptor').value = '';
            if (!file) return;
            try {
                await modelsReady;
                const img = await faceapi.bufferToImage(file);
                const det = await umzaFace.detect(img);
                if (det) { passportDesc = det.descriptor; $('passportDescriptor').value = JSON.stringify(Array.from(det.descriptor)); }
            } catch (e) {}
            checkMatch();
        }

        function checkMatch() {
            if (!captured || !passportDesc || !$('faceDescriptor').value) return;
            const live = new Float32Array(JSON.parse($('faceDescriptor').value));
            const d = faceapi.euclideanDistance(live, passportDesc);
            if (d > 0.5) status('<i class="fa-solid fa-triangle-exclamation me-1"></i>Your captured face does not look like the passport photograph you chose. Retake, or upload your own clear passport photo.', 'alert-warning');
            else status('<i class="fa-solid fa-circle-check me-1"></i>Face captured and it matches your passport photo.', 'alert-success');
        }

        // Capture one still photo, then find the face in it
        $('regCapture').addEventListener('click', async function () {
            if (!stream || video.readyState < 2) { status('Camera is not ready yet. Allow camera access, wait a second and try again.', 'alert-warning'); return; }
            const btn = this; btn.disabled = true;
            umzaFace.grab(video, canvas);
            if (umzaFace.brightness(canvas) < 25) {
                status('<i class="fa-solid fa-triangle-exclamation me-1"></i>The picture is too dark (or the camera is not ready). Turn on a light or face a window and press Capture again.', 'alert-warning');
                btn.disabled = false; return;
            }
            $('facePhoto').value = canvas.toDataURL('image/jpeg', 0.85);
            $('faceDescriptor').value = '';
            shot.src = $('facePhoto').value; shot.classList.remove('d-none'); video.classList.add('d-none');
            $('regCapture').classList.add('d-none'); $('regRetake').classList.remove('d-none');
            captured = true;
            status('<i class="fa-solid fa-spinner fa-spin me-1"></i>Photo taken. Checking your face...', 'alert-info');
            try {
                await modelsReady;
                const det = await umzaFace.detect(canvas);
                if (det) {
                    $('faceDescriptor').value = JSON.stringify(Array.from(det.descriptor));
                    status('<i class="fa-solid fa-circle-check me-1"></i>Face captured successfully.', 'alert-success');
                    checkMatch();
                } else {
                    status('<i class="fa-solid fa-triangle-exclamation me-1"></i>No face found in this photo. Press <strong>Retake</strong>, move closer and face a light (not a window behind you).', 'alert-warning');
                }
            } catch (e) {
                // Recognition could not start: keep the photo, the face is set up at the first clock-in
                status('<i class="fa-solid fa-circle-info me-1"></i>Photo saved. ' + umzaFace.lastError + ' You can still submit; your face will be set up at your first clock-in.', 'alert-warning');
            }
            btn.disabled = false;
        });

        $('regRetake').addEventListener('click', function () {
            captured = false; $('faceDescriptor').value = ''; $('facePhoto').value = '';
            shot.classList.add('d-none'); video.classList.remove('d-none'); this.classList.add('d-none');
            $('regCapture').classList.remove('d-none');
            status('Look straight at the camera, then press <strong>Capture</strong>.', 'alert-info');
        });
        $('passport_photo').addEventListener('change', function () { readPassport(this.files && this.files[0]); });
        $('registerForm').addEventListener('submit', function (e) {
            if (REQUIRED && !$('facePhoto').value) {
                e.preventDefault(); e.stopImmediatePropagation();
                alert('Please capture your face: look at the camera and press Capture.');
                $('regStatus').scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else if (REQUIRED && umzaFace.loaded && !$('faceDescriptor').value) {
                e.preventDefault(); e.stopImmediatePropagation();
                alert('No face was found in your photo. Press Retake and capture again.');
            }
        }, true);

        startCamera();
    })();
    </script>
    <script src="<?php echo get_base_url(); ?>/assets/js/name-format.js?v=<?php echo get_asset_version('assets/js/name-format.js'); ?>"></script>
    <script>
        document.getElementById('passport_photo').addEventListener('change', function () {
            const img = document.getElementById('passportPreview');
            if (this.files && this.files[0]) { img.src = URL.createObjectURL(this.files[0]); img.classList.remove('d-none'); }
        });
        const positionsMap = <?php echo json_encode($positions_map); ?>;
        
        document.getElementById('department').addEventListener('change', function() {
            const deptId = this.value;
            const positionSelect = document.getElementById('position');
            
            positionSelect.innerHTML = '';
            
            if (deptId && positionsMap[deptId]) {
                positionSelect.disabled = false;
                
                // Add default select option
                const defaultOpt = document.createElement('option');
                defaultOpt.value = '';
                defaultOpt.textContent = 'Select Position';
                positionSelect.appendChild(defaultOpt);
                
                positionsMap[deptId].forEach(pos => {
                    const opt = document.createElement('option');
                    opt.value = pos.id;
                    opt.textContent = pos.title;
                    positionSelect.appendChild(opt);
                });
            } else {
                positionSelect.disabled = true;
                const defaultOpt = document.createElement('option');
                defaultOpt.value = '';
                defaultOpt.textContent = 'Select Department First';
                positionSelect.appendChild(defaultOpt);
            }
        });
    </script>
</body>
</html>
