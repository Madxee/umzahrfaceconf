<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Portal Login & Entrypoint
 */

require_once 'includes/auth.php';

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    if (is_logged_in()) {
        log_activity($_SESSION['user_id'], 'USER_LOGOUT', 'User logged out successfully');
    }
    session_destroy();
    header("Location: index.php?success=You+have+logged+out+successfully.");
    exit;
}

// Redirect if already logged in (keep any message, e.g. "no permission")
if (is_logged_in()) {
    $carry = '';
    if (!empty($_GET['error'])) {
        $map = ['unauthorized' => 'You do not have permission to open that page.', 'access_denied' => 'Access denied.'];
        $carry = '?error=' . urlencode($map[$_GET['error']] ?? $_GET['error']);
    }
    if (in_array($_SESSION['role'], ['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Department Head', 'Finance Officer'])) {
        header("Location: admin/dashboard.php" . $carry);
    } else {
        header("Location: staff/dashboard.php" . $carry);
    }
    exit;
}

$error = '';
$success = $_GET['success'] ?? '';
$error_messages = [
    'unauthorized'  => 'You do not have permission to open that page.',
    'access_denied' => 'Your session has ended or your account is not active.',
];
if (!empty($_GET['error'])) {
    $error = $error_messages[$_GET['error']] ?? $_GET['error'];
}
$resend_email = filter_var($_GET['resend'] ?? '', FILTER_VALIDATE_EMAIL) ?: '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim(strtolower($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';

    // Validate CSRF
    if (!verify_csrf_token($csrf_token)) {
        $error = "Security validation failed. Please refresh and try again.";
    } elseif (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM `staff` WHERE `email` = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                // Check verification
                if ($user['email_verified'] == 0) {
                    $error = "Your email address has not been verified yet. Please check your inbox (and Spam folder) for the verification link.";
                    $resend_email = $user['email'];
                } 
                // Check approval status
                elseif ($user['status'] === 'Pending') {
                    $error = "Your registration has not been approved by HR yet. You will be notified via email once approved.";
                } 
                // Check suspension
                elseif ($user['status'] === 'Suspended') {
                    $error = "Your account is suspended. Please contact the HR department for assistance.";
                } 
                // All checks passed
                else {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['name'] = display_name($user);
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['passport'] = $user['passport_photo'];
                    $_SESSION['staff_code'] = $user['staff_id'];

                    // Regenerate session ID for security
                    session_regenerate_id(true);

                    // Log activity
                    log_activity($user['id'], 'USER_LOGIN', 'User logged in successfully');

                    // Role redirect
                    if (in_array($user['role'], ['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Department Head', 'Finance Officer'])) {
                        header("Location: admin/dashboard.php");
                    } else {
                        header("Location: staff/dashboard.php");
                    }
                    exit;
                }
            } else {
                $error = "Invalid email address or password.";
                // Log failed attempt if user exists
                if ($user) {
                    log_activity($user['id'], 'USER_LOGIN_FAILED', 'Failed login attempt due to incorrect password');
                }
            }
        } catch (PDOException $e) {
            $error = "A database error occurred. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - HR Portal Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
</head>
<body class="auth-wrapper">

    <div class="auth-card">
        <div class="auth-header">
            <div class="id-card-logo-placeholder mx-auto">
                <i class="fa-solid fa-plane-departure"></i>
            </div>
            <h2 class="mt-2 fw-bold text-aviation">UMZA Aviation</h2>
            <p class="text-muted">Human Resources Portal</p>
        </div>
        
        <div class="auth-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($resend_email)): ?>
                <form action="resend-verification.php" method="POST" class="alert alert-warning border-0 shadow-sm mb-3 d-flex align-items-center justify-content-between gap-2">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="email" value="<?php echo htmlspecialchars($resend_email); ?>">
                    <span style="font-size:0.85rem;">Didn't get the email?</span>
                    <button type="submit" class="btn btn-sm btn-aviation"><i class="fa-solid fa-paper-plane me-1"></i>Resend verification email</button>
                </form>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-3">
                    <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@umzaair.com" value="<?php echo htmlspecialchars($_POST['email'] ?? $resend_email); ?>" required>
                    <label for="email"><i class="fa-solid fa-envelope me-2 text-muted"></i>Company Email Address</label>
                </div>
                
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    <label for="password"><i class="fa-solid fa-lock me-2 text-muted"></i>Password</label>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="remember" style="accent-color: var(--secondary-color);">
                        <label class="form-check-label text-muted" for="remember" style="font-size: 0.85rem;">Remember me</label>
                    </div>
                    <a href="forgot-password.php" class="text-aviation text-decoration-none" style="font-size: 0.85rem;">Forgot Password?</a>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-3 mb-3">
                    <i class="fa-solid fa-right-to-bracket me-2"></i>Sign In
                </button>
                
                <?php if (feature_enabled('registration')): ?>
                <div class="text-center mt-3">
                    <p class="text-muted mb-0" style="font-size: 0.85rem;">
                        New staff member? <a href="register.php" class="text-aviation fw-semibold text-decoration-none">Create Account</a>
                    </p>
                </div>
                <?php endif; ?>
                <div class="text-center mt-2">
                    <a href="resend-verification.php" class="text-muted text-decoration-none" style="font-size: 0.8rem;">Resend verification email</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
