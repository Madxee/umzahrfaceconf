# UMZA Aviation Services Ltd - HR Management Portal
### Professional Aviation HR Management System (Vanilla PHP 8+ / MySQL / Bootstrap 5)

This portal is a complete, framework-free Human Resources Management System designed specifically to run directly on **XAMPP** (Localhost) or standard **cPanel shared hosting** environments. It requires no Composer, Node.js, Laravel, Docker, or command-line package installations.

---

## Features Integrated

1. **Staff Registration Module**: Optional email-domain restriction (System Settings). Supports email verification, HR review queue, and secure passport photo upload.
2. **HR Admin Panel**: Approve/reject/suspend staff, modify department/position, view career history, audit logs, and export staff records to CSV.
3. **Staff Dashboard**: View profile dossier, digital ID card badge, annual leave statistics, internal memos, and formal queries.
4. **Complaint Management**: Staff submit grievances with PDF/image attachments. Tracked by custom tracking number. HR posts responses and updates status.
5. **Leave Management System**: Staff request leaves; HR sets quotas, views statistics, and approves requests. Approvals automatically update the staff's remaining days and generate printable leave approval letters.
6. **Memo Management**: HR creates categories of broadcasts. Active staff receive in-app and email broadcasts.
7. **Staff Query ManagementCenter**: HR issues formal disciplinary queries with response deadlines. Staff reply with explanations and file attachments. HR resolves or escalates.
8. **Digital Staff ID Card System**: HR generates and prints credit-card-sized ID badges with custom photo, details, and dynamic QR Code verification link.
9. **Public ID Verification Gateway**: Public gate checks staff status (Active, Suspended, Expired) and displays passport photo/dossier when scanned.
10. **Activity Log & Audit Trail**: Full-system audit trail captures logins, changes, IPs, and user agents.
11. **Security Engineering**: Full PDO prepared statements, CSRF protection, secure HTTPOnly session configurations, and file upload MIME-type validations.

---

## Installation & Setup Guide

### 1. Localhost Deployment (XAMPP)

1. **Move Project Files**:
   Copy the `umza-hr` folder from your scratch workspace and paste it inside your XAMPP htdocs directory:
   `C:\xampp\htdocs\umza-hr`

2. **Database Import**:
   - Open your browser and navigate to `http://localhost/phpmyadmin`.
   - Create a new database named `umza_hr`.
   - Go to the **Import** tab, select the `schema.sql` file located in the root of the project, and click **Go/Import**.

3. **Run Application**:
   Navigate to `http://localhost/umza-hr` in your web browser.

---

### 2. cPanel Shared Hosting Deployment

1. **Upload Files**:
   Compress the `umza-hr` folder into a `.zip` file and upload it to your cPanel File Manager under your target subdomain or `public_html` folder. Extract it.

2. **Setup MySQL Database**:
   - In cPanel, open the **MySQL Database Wizard**.
   - Create a database and database user, generate a secure password, and grant **All Privileges** to the user.
   - Open **phpMyAdmin** in cPanel, select your database, and import the `schema.sql` file.

3. **Configure Database Connection**:
   Open `includes/config.php` and update the database credentials:
   ```php
   define('DB_HOST', 'localhost'); // Often localhost on cPanel
   define('DB_USER', 'your_cpanel_db_username');
   define('DB_PASS', 'your_cpanel_db_password');
   define('DB_NAME', 'your_cpanel_db_name');
   ```

4. **Verify Folder Permissions**:
   Ensure the `/uploads/` folder and its subfolders (`/passports`, `/cvs`, `/certificates`, `/complaints`) have write permissions configured (usually `0755` or `0775` on cPanel).

---

## Default Access Credentials

For initial setup testing, use the pre-seeded Super Admin account:

- **Login Email**: `admin@umzaair.com`
- **Password**: `AdminPass123!`
- **Aviation Rank/Role**: Super Admin

---

## Email Configuration & Testing

Go to **Admin > System Settings > Email Delivery**.

1. In cPanel open **Email Accounts**, create (or reset the password of) the mailbox the portal will send from, e.g. `hr@umzaair.com`.
2. In System Settings enter: host `mail.yourdomain.com`, port `465`, security `SSL`, username = the **full** email address, password = that mailbox's password. Set "System Email" to the same address. Save.
3. Use **Send a Test Email**. If it fails, the exact server reply is shown with a plain explanation
   (e.g. *Could not authenticate* = wrong username/password).
4. Sending method:
   - **SMTP** (default): if SMTP fails, the portal automatically retries through the server's own mail function, so verification emails still go out.
   - **Server mail only**: uses cPanel sendmail, no password needed.
   - **Log only**: for testing; nothing is sent.

Every email attempt is listed in **System Settings > Email Log** (stored privately in `/logs`, not in the public uploads folder).

Staff who did not get their verification email can click **Resend verification email** on the login page.
HR can also resend it or mark the email as verified from the Staff Directory.

---

## Upgrading an existing installation

Upload the new files over the old ones (keep your `uploads/` folder). The first page load upgrades the database
automatically: it only adds new tables/columns and never deletes data. No phpMyAdmin import is needed.
A brand-new empty database is also set up automatically on first visit.

## New in this version

- **Email fixed**: clear SMTP errors, automatic fallback to server mail, test button, email log, resend verification.
- **Face recognition attendance**: the live camera face is matched against the staff member's passport photo (face-api.js, bundled in `libs/face-api`); the match is re-checked on the server. HR sees the photo, match % and passport side by side.
- **GPS attendance locations**: Admin > GPS Locations. Head office plus the main Nigerian airports are pre-loaded (approximate points, marked "Check position"); add route offices, pick the point on the map or with "Use my current GPS", and set a radius. Staff can be limited to specific locations.
- Camera and GPS only work when the site runs on **https://** (enable SSL in cPanel).
- **Face registration at sign-up**: new staff register their face live with the camera when they register (checked against the passport photo they upload). That face is what attendance recognises. Existing staff register at their first clock-in.
- **Work station at sign-up**: staff choose their station (head office, airport...). HR sets each station's GPS point and radius in GPS Locations, and can change a staff member's station in their profile.
- **Automatic clock-in**: the camera recognises the face by itself; when the location is also confirmed, attendance is recorded automatically (switch in Features).
- **Managing Director approval**: give the MD an account with role "Managing Director". HR writes a letter (or a memo with "Send to MD"), the MD gets an email, reads it on the letterhead in "MD Approvals" and clicks Approve or Return for Correction. HR can correct the name and details at any time before approval. Approved letters carry the HR and MD signatures (upload the MD signature in System Settings).
- **Official letterhead**: HR letters, promotions, leave approvals and all memos (including Head of Department memos) print on the company letterhead with a reference number; emails carry the letterhead header. Replace it in System Settings > Official Letterhead.
- **Departments & Positions** page: add, rename, remove departments and positions; assign a Head of Department.
- **Other name + display name**: staff have First, Other and Last name and choose which name is shown on the portal, emails and ID card.
- **Features & Shortcuts** page: switch modules on/off, add or remove menu shortcuts, post or remove announcements at the top of every page.
- **Memos**: every memo is emailed (in batches) plus in-app notification; HR can target all staff or one department; each Head of Department can send memos to their own staff; memo emails can be re-sent.
- **Image saving fixed**: uploaded photos are checked, rotated, resized and saved as JPEG; WebP/PNG accepted; HR can change a staff photo; ID card can be saved as an image.

---

## Security Configuration (.htaccess)
To block malicious scripts from running inside the user-uploaded folders, an `.htaccess` script is placed inside the `/uploads/` directory, preventing PHP scripts from executing directly.
