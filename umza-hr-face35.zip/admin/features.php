<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Features & Shortcuts: switch modules on/off, add menu shortcuts and top-of-page announcements
 */

require_once '../includes/auth.php';
require_role(['Super Admin', 'HR Director', 'HR Manager']);

$user_id = $_SESSION['user_id'];
$features = umza_feature_list();

function go($ok, $msg, $tab = '') {
    header("Location: features.php?" . ($ok ? 'success=' : 'error=') . urlencode($msg) . ($tab ? "#$tab" : ''));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        go(false, 'Security validation failed.');
    }
    $action = $_POST['action'] ?? '';
    $upsert = $pdo->prepare("INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)");

    if ($action === 'save_features') {
        $on = (array)($_POST['features'] ?? []);
        $changes = [];
        foreach ($features as $key => $f) {
            $val = in_array($key, $on, true) ? '1' : '0';
            if (get_setting('feature_' . $key, '1') !== $val) $changes[] = $f['label'] . ($val === '1' ? ' ON' : ' OFF');
            $upsert->execute(['feature_' . $key, $val, 'Feature switch: ' . $f['label']]);
        }
        $upsert->execute(['require_attendance_photo', isset($_POST['require_attendance_photo']) ? '1' : '0', 'Require a live face photo when clocking in/out']);
        $upsert->execute(['require_gps', isset($_POST['require_gps']) ? '1' : '0', 'Staff must be inside an attendance location (GPS) to clock in/out']);
        $upsert->execute(['require_face_match', isset($_POST['require_face_match']) ? '1' : '0', 'Live face must match the passport photo to clock in/out']);
        $upsert->execute(['allow_self_face_enrol', isset($_POST['allow_self_face_enrol']) ? '1' : '0', 'Staff browsers may register their face from the passport photo']);
        $upsert->execute(['auto_clock_after_match', isset($_POST['auto_clock_after_match']) ? '1' : '0', 'Clock in/out automatically once location and face are confirmed']);
        $upsert->execute(['require_station_at_registration', isset($_POST['require_station_at_registration']) ? '1' : '0', 'New staff must choose their work station when registering']);
        $thr = min(0.7, max(0.35, (float)($_POST['face_match_threshold'] ?? 0.45)));
        $upsert->execute(['face_match_threshold', (string)$thr, 'Face match strictness (lower = stricter)']);
        $acc = min(5000, max(50, intval($_POST['gps_max_accuracy'] ?? 1000)));
        $upsert->execute(['gps_max_accuracy', (string)$acc, 'Reject GPS readings less precise than this many metres']);
        log_activity($user_id, 'FEATURES_UPDATED', $changes ? implode(', ', $changes) : 'No changes');
        go(true, 'Feature settings saved.', 'features');
    }

    if ($action === 'add_link') {
        $title = trim($_POST['title'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $icon = trim($_POST['icon'] ?? '') ?: 'fa-solid fa-link';
        $aud = in_array($_POST['audience'] ?? 'All', ['All', 'Staff', 'Admins', 'Department Heads'], true) ? $_POST['audience'] : 'All';
        if ($title === '' || $url === '') go(false, 'Title and link are required.', 'links');
        // Only web links or paths inside the portal (no javascript: etc.)
        if (!preg_match('#^(https?://|/?[a-z0-9_\-./?=&%]+$)#i', $url)) go(false, 'Enter a full web address (https://...) or a portal page like staff/memos.php.', 'links');
        if (!preg_match('/^[a-z0-9\- ]+$/i', $icon)) $icon = 'fa-solid fa-link';
        $pdo->prepare("INSERT INTO `custom_links` (`title`, `url`, `icon`, `audience`, `sort_order`) VALUES (?, ?, ?, ?, ?)")
            ->execute([$title, $url, $icon, $aud, intval($_POST['sort_order'] ?? 0)]);
        log_activity($user_id, 'SHORTCUT_ADDED', "Added menu shortcut: $title");
        go(true, "Shortcut \"$title\" added to the menu.", 'links');
    }
    if ($action === 'toggle_link') {
        $pdo->prepare("UPDATE `custom_links` SET `is_active` = 1 - `is_active` WHERE `id` = ?")->execute([intval($_POST['id'] ?? 0)]);
        go(true, 'Shortcut updated.', 'links');
    }
    if ($action === 'delete_link') {
        $pdo->prepare("DELETE FROM `custom_links` WHERE `id` = ?")->execute([intval($_POST['id'] ?? 0)]);
        log_activity($user_id, 'SHORTCUT_REMOVED', 'Removed a menu shortcut');
        go(true, 'Shortcut removed.', 'links');
    }

    if ($action === 'add_announcement') {
        $msg = trim($_POST['message'] ?? '');
        $style = in_array($_POST['style'] ?? 'info', ['info', 'success', 'warning', 'danger'], true) ? $_POST['style'] : 'info';
        $exp = $_POST['expires_on'] ?? '';
        if ($msg === '') go(false, 'Announcement text is required.', 'announcements');
        $pdo->prepare("INSERT INTO `announcements` (`message`, `style`, `expires_on`, `created_by`) VALUES (?, ?, ?, ?)")
            ->execute([mb_substr($msg, 0, 500), $style, $exp ?: null, $user_id]);
        log_activity($user_id, 'ANNOUNCEMENT_ADDED', mb_substr($msg, 0, 100));
        go(true, 'Announcement is now showing at the top of every page.', 'announcements');
    }
    if ($action === 'toggle_announcement') {
        $pdo->prepare("UPDATE `announcements` SET `is_active` = 1 - `is_active` WHERE `id` = ?")->execute([intval($_POST['id'] ?? 0)]);
        go(true, 'Announcement updated.', 'announcements');
    }
    if ($action === 'delete_announcement') {
        $pdo->prepare("DELETE FROM `announcements` WHERE `id` = ?")->execute([intval($_POST['id'] ?? 0)]);
        go(true, 'Announcement removed.', 'announcements');
    }
    go(false, 'Unknown action.');
}

$links = $pdo->query("SELECT * FROM `custom_links` ORDER BY `sort_order`, `id`")->fetchAll();
$announcements = $pdo->query("SELECT a.*, s.first_name, s.last_name, s.display_name FROM `announcements` a LEFT JOIN `staff` s ON s.id = a.created_by ORDER BY a.id DESC")->fetchAll();

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-toggle-on me-2"></i>Features &amp; Shortcuts</h2>
        <p class="text-muted mb-0">Turn portal modules on or off, add your own menu shortcuts, and post announcements at the top of every page.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Feature switches -->
    <div class="col-lg-6" id="features">
        <div class="card shadow-sm border-0 p-4 h-100" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-sliders me-2"></i>Modules</h5>
            <p class="small text-muted">Switched-off modules disappear from every menu and their pages are closed. Data is kept, so you can switch them back on at any time.</p>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="save_features">
                <?php foreach ($features as $key => $f): ?>
                    <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                        <input class="form-check-input mt-1" type="checkbox" role="switch" id="f_<?php echo $key; ?>" name="features[]" value="<?php echo $key; ?>" <?php echo feature_enabled($key) ? 'checked' : ''; ?>>
                        <label class="form-check-label flex-grow-1" for="f_<?php echo $key; ?>">
                            <i class="<?php echo $f['icon']; ?> text-aviation me-1"></i><strong><?php echo htmlspecialchars($f['label']); ?></strong>
                            <div class="small text-muted"><?php echo htmlspecialchars($f['desc']); ?></div>
                        </label>
                    </div>
                <?php endforeach; ?>
                <h6 class="fw-bold text-aviation mt-4 mb-2"><i class="fa-solid fa-user-clock me-1"></i>Attendance Security</h6>
                <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                    <input class="form-check-input mt-1" type="checkbox" role="switch" id="req_gps" name="require_gps" value="1" <?php echo get_setting('require_gps', '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="req_gps"><i class="fa-solid fa-location-dot text-aviation me-1"></i><strong>GPS location check</strong>
                        <div class="small text-muted">Staff can only clock in inside a <a href="locations.php">GPS location</a> (head office, airport stations...).</div></label>
                </div>
                <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                    <input class="form-check-input mt-1" type="checkbox" role="switch" id="req_face" name="require_face_match" value="1" <?php echo get_setting('require_face_match', '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="req_face"><i class="fa-solid fa-face-smile text-aviation me-1"></i><strong>Face recognition</strong>
                        <div class="small text-muted">The live camera face must match the staff member's passport photo.</div></label>
                </div>
                <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                    <input class="form-check-input mt-1" type="checkbox" role="switch" id="req_photo" name="require_attendance_photo" value="1" <?php echo get_setting('require_attendance_photo', '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="req_photo"><i class="fa-solid fa-camera text-aviation me-1"></i><strong>Save a face photo with every clock-in</strong>
                        <div class="small text-muted">Keeps the live photo so HR can review it.</div></label>
                </div>
                <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                    <input class="form-check-input mt-1" type="checkbox" role="switch" id="self_enrol" name="allow_self_face_enrol" value="1" <?php echo get_setting('allow_self_face_enrol', '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="self_enrol"><i class="fa-solid fa-id-badge text-aviation me-1"></i><strong>Automatic face registration</strong>
                        <div class="small text-muted">Staff who did not register their face at sign-up register it at their first clock-in (it must match their passport photo). Turn off to let only HR handle it.</div></label>
                </div>
                <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                    <input class="form-check-input mt-1" type="checkbox" role="switch" id="auto_clock" name="auto_clock_after_match" value="1" <?php echo get_setting('auto_clock_after_match', '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="auto_clock"><i class="fa-solid fa-bolt text-aviation me-1"></i><strong>Automatic clock-in</strong>
                        <div class="small text-muted">As soon as the location and face are confirmed, attendance is recorded by itself (3-second countdown).</div></label>
                </div>
                <div class="form-check form-switch d-flex align-items-start gap-2 py-2 border-bottom">
                    <input class="form-check-input mt-1" type="checkbox" role="switch" id="req_station" name="require_station_at_registration" value="1" <?php echo get_setting('require_station_at_registration', '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="req_station"><i class="fa-solid fa-plane-departure text-aviation me-1"></i><strong>Choose work station at registration</strong>
                        <div class="small text-muted">New staff must pick their station (head office, airport...) when they register.</div></label>
                </div>
                <div class="row g-2 py-2">
                    <div class="col-6">
                        <label class="form-label small fw-bold mb-1">Face match strictness</label>
                        <select class="form-select form-select-sm" name="face_match_threshold">
                            <?php $thr = (float)get_setting('face_match_threshold', '0.45');
                            foreach (['0.4' => 'Very strict', '0.45' => 'Normal (recommended)', '0.5' => 'Relaxed', '0.55' => 'Loose (not recommended)'] as $v => $lbl): ?>
                                <option value="<?php echo $v; ?>" <?php echo abs($thr - (float)$v) < 0.001 ? 'selected' : ''; ?>><?php echo $lbl; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-bold mb-1">Weakest GPS accepted (m)</label>
                        <input type="number" class="form-control form-control-sm" name="gps_max_accuracy" min="50" max="5000" value="<?php echo (int)get_setting('gps_max_accuracy', '1000'); ?>">
                    </div>
                </div>
                <button class="btn btn-aviation w-100 mt-3"><i class="fa-solid fa-floppy-disk me-1"></i>Save Modules</button>
            </form>
        </div>
    </div>

    <div class="col-lg-6">
        <!-- Shortcuts -->
        <div class="card shadow-sm border-0 p-4 mb-4" style="border-radius:12px;" id="links">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-link me-2"></i>Menu Shortcuts</h5>
            <form method="POST" class="row g-2 mb-3">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add_link">
                <div class="col-md-6"><input class="form-control form-control-sm" name="title" placeholder="Title, e.g. Staff Handbook" required></div>
                <div class="col-md-6"><input class="form-control form-control-sm" name="url" placeholder="https://... or staff/memos.php" required></div>
                <div class="col-md-5"><input class="form-control form-control-sm" name="icon" placeholder="Icon (optional) e.g. fa-solid fa-book"></div>
                <div class="col-md-4">
                    <select class="form-select form-select-sm" name="audience">
                        <option value="All">Everyone</option><option value="Staff">Staff only</option>
                        <option value="Admins">HR / Admins only</option><option value="Department Heads">Department Heads</option>
                    </select>
                </div>
                <div class="col-md-3"><button class="btn btn-sm btn-aviation w-100"><i class="fa-solid fa-plus me-1"></i>Add</button></div>
            </form>
            <?php if ($links): ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($links as $l): ?>
                        <li class="list-group-item px-0 d-flex align-items-center gap-2">
                            <i class="<?php echo htmlspecialchars($l['icon']); ?> text-aviation"></i>
                            <div class="flex-grow-1 <?php echo $l['is_active'] ? '' : 'text-muted text-decoration-line-through'; ?>">
                                <strong><?php echo htmlspecialchars($l['title']); ?></strong>
                                <div class="small text-muted text-truncate" style="max-width:260px;"><?php echo htmlspecialchars($l['url']); ?> &middot; <?php echo htmlspecialchars($l['audience']); ?></div>
                            </div>
                            <form method="POST"><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="toggle_link"><input type="hidden" name="id" value="<?php echo $l['id']; ?>">
                                <button class="btn btn-sm btn-outline-secondary"><?php echo $l['is_active'] ? 'Hide' : 'Show'; ?></button></form>
                            <form method="POST" onsubmit="return confirm('Remove this shortcut?');"><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="delete_link"><input type="hidden" name="id" value="<?php echo $l['id']; ?>">
                                <button class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash-can"></i></button></form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="small text-muted mb-0">No shortcuts yet. Added shortcuts appear under "Shortcuts" in the side menu.</p>
            <?php endif; ?>
        </div>

        <!-- Announcements -->
        <div class="card shadow-sm border-0 p-4" style="border-radius:12px;" id="announcements">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-bullhorn me-2"></i>Top-of-Page Announcements</h5>
            <form method="POST" class="mb-3">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add_announcement">
                <textarea class="form-control form-control-sm mb-2" name="message" rows="2" maxlength="500" placeholder="e.g. The portal will be offline on Saturday 10pm-11pm for maintenance." required></textarea>
                <div class="row g-2">
                    <div class="col-md-4">
                        <select class="form-select form-select-sm" name="style">
                            <option value="info">Blue (info)</option><option value="success">Green</option>
                            <option value="warning">Yellow (warning)</option><option value="danger">Red (urgent)</option>
                        </select>
                    </div>
                    <div class="col-md-5"><input type="date" class="form-control form-control-sm" name="expires_on" title="Hide automatically after this date (optional)"></div>
                    <div class="col-md-3"><button class="btn btn-sm btn-aviation w-100">Post</button></div>
                </div>
            </form>
            <?php foreach ($announcements as $a): ?>
                <div class="alert alert-<?php echo htmlspecialchars($a['style']); ?> py-2 px-3 d-flex align-items-start gap-2 mb-2 <?php echo $a['is_active'] ? '' : 'opacity-50'; ?>">
                    <div class="flex-grow-1 small">
                        <?php echo nl2br(htmlspecialchars($a['message'])); ?>
                        <div class="text-muted" style="font-size:0.7rem;">
                            <?php echo format_date($a['created_at']); ?> by <?php echo htmlspecialchars(display_name($a)); ?>
                            <?php echo $a['expires_on'] ? ' &middot; until ' . format_date($a['expires_on']) : ''; ?>
                            <?php echo $a['is_active'] ? '' : ' &middot; hidden'; ?>
                        </div>
                    </div>
                    <form method="POST"><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="toggle_announcement"><input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                        <button class="btn btn-sm btn-light"><?php echo $a['is_active'] ? 'Hide' : 'Show'; ?></button></form>
                    <form method="POST" onsubmit="return confirm('Delete this announcement?');"><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="delete_announcement"><input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                        <button class="btn btn-sm btn-light text-danger"><i class="fa-solid fa-trash-can"></i></button></form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
