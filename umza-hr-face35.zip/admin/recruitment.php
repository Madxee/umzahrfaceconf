<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Recruitment Management Desk
 */

require_once '../includes/auth.php';
require_feature('recruitment');
require_login();
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

// Handle actions (Create Vacancy, Update Applicant Status, Schedule Interview)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        // 1. Post Vacancy
        if ($action === 'create_vacancy') {
            $title = trim($_POST['title']);
            $dept_id = intval($_POST['department_id']);
            $desc = trim($_POST['description']);
            $req = trim($_POST['requirements'] ?? '');
            
            if (empty($title) || $dept_id <= 0 || empty($desc)) {
                $error = "Vacancy title, department, and description are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `vacancies` (`title`, `department_id`, `description`, `requirements`, `status`) VALUES (?, ?, ?, ?, 'Open')");
                    $stmt->execute([$title, $dept_id, $desc, $req]);
                    log_activity($_SESSION['user_id'], 'VACANCY_CREATED', "Created new vacancy: $title");
                    $success = "Job vacancy posted successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to create vacancy: " . $e->getMessage();
                }
            }
        }
        
        // 2. Update Application Status
        elseif ($action === 'update_applicant_status') {
            $app_id = intval($_POST['application_id']);
            $status = $_POST['status'];
            
            try {
                $stmt = $pdo->prepare("UPDATE `job_applications` SET `status` = ? WHERE `id` = ?");
                $stmt->execute([$status, $app_id]);
                log_activity($_SESSION['user_id'], 'APPLICANT_STATUS_UPDATED', "Updated applicant ID $app_id to status: $status");
                $success = "Applicant status updated successfully.";
            } catch (PDOException $e) {
                $error = "Failed to update status.";
            }
        }
        
        // 3. Schedule Interview
        elseif ($action === 'schedule_interview') {
            $app_id = intval($_POST['application_id']);
            $date = $_POST['interview_date'];
            $interviewer_id = intval($_POST['interviewer_id']);
            $mode = $_POST['mode'];
            $remarks = trim($_POST['remarks'] ?? '');
            
            if ($app_id <= 0 || empty($date) || $interviewer_id <= 0) {
                $error = "Applicant, interview date/time, and interviewer are required.";
            } else {
                try {
                    $pdo->beginTransaction();
                    
                    // Insert interview
                    $stmt = $pdo->prepare("INSERT INTO `interviews` (`application_id`, `interview_date`, `interviewer_id`, `mode`, `remarks`, `status`) VALUES (?, ?, ?, ?, ?, 'Scheduled')");
                    $stmt->execute([$app_id, $date, $interviewer_id, $mode, $remarks]);
                    
                    // Automatically update applicant status to 'Interviewing'
                    $upd = $pdo->prepare("UPDATE `job_applications` SET `status` = 'Interviewing' WHERE `id` = ?");
                    $upd->execute([$app_id]);
                    
                    $pdo->commit();
                    log_activity($_SESSION['user_id'], 'INTERVIEW_SCHEDULED', "Scheduled interview for applicant ID $app_id on $date");
                    $success = "Interview scheduled successfully and applicant status updated to Interviewing.";
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $error = "Failed to schedule interview: " . $e->getMessage();
                }
            }
        }
    }
    
    $redir_url = "recruitment.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch all vacancies
try {
    $vacancies = $pdo->query("SELECT v.*, d.name as department_name, 
                                     (SELECT COUNT(*) FROM `job_applications` WHERE `vacancy_id` = v.id) as applicant_count 
                              FROM `vacancies` v 
                              JOIN `departments` d ON v.department_id = d.id 
                              ORDER BY v.status DESC, v.id DESC")->fetchAll();
} catch (PDOException $e) {
    $vacancies = [];
}

// Fetch all applicants
try {
    $applicants = $pdo->query("SELECT a.*, v.title as vacancy_title, d.name as department_name 
                               FROM `job_applications` a 
                               JOIN `vacancies` v ON a.vacancy_id = v.id 
                               JOIN `departments` d ON v.department_id = d.id 
                               ORDER BY a.id DESC")->fetchAll();
} catch (PDOException $e) {
    $applicants = [];
}

// Fetch scheduled interviews
try {
    $interviews = $pdo->query("SELECT i.*, a.full_name as applicant_name, v.title as vacancy_title, s.first_name, s.last_name, s.display_name 
                               FROM `interviews` i 
                               JOIN `job_applications` a ON i.application_id = a.id 
                               JOIN `vacancies` v ON a.vacancy_id = v.id 
                               LEFT JOIN `staff` s ON i.interviewer_id = s.id 
                               ORDER BY i.interview_date ASC")->fetchAll();
} catch (PDOException $e) {
    $interviews = [];
}

// Load departments for forms
$departments = $pdo->query("SELECT * FROM `departments` ORDER BY `name` ASC")->fetchAll();

// Load staff list for interviewer dropdown
$staff_members = $pdo->query("SELECT id, first_name, last_name, display_name, staff_id FROM `staff` WHERE `status` = 'Active' ORDER BY `first_name` ASC")->fetchAll();

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-user-plus me-2"></i>Recruitment Center</h2>
        <p class="text-muted">Manage job openings, track candidate applications, and schedule hiring interviews.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Vacancies & Application list -->
    <div class="col-lg-8 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                <h5 class="fw-bold text-aviation mb-0"><i class="fa-solid fa-briefcase me-2"></i>Active Vacancies</h5>
                <button type="button" class="btn btn-sm btn-aviation" data-bs-toggle="modal" data-bs-target="#newVacancyModal">
                    <i class="fa-solid fa-plus me-1"></i>Post New Job
                </button>
            </div>
            
            <?php if (count($vacancies) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Job Title</th>
                                <th>Department</th>
                                <th>Candidates</th>
                                <th>Status</th>
                                <th>Date Posted</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vacancies as $v): ?>
                                <tr>
                                    <td><strong class="text-dark"><?php echo htmlspecialchars($v['title']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($v['department_name']); ?></td>
                                    <td><span class="badge bg-light text-dark border"><?php echo $v['applicant_count']; ?> Applied</span></td>
                                    <td>
                                        <span class="badge bg-<?php echo $v['status'] === 'Open' ? 'success' : 'secondary'; ?>">
                                            <?php echo $v['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo format_date($v['created_at']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No active vacancies posted. Click Post New Job to create one.</p>
            <?php endif; ?>
        </div>

        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-users-rectangle me-2"></i>Candidate Applications</h5>
            
            <?php if (count($applicants) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Applicant</th>
                                <th>Job Position</th>
                                <th>Resume</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($applicants as $app): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($app['full_name']); ?></strong>
                                        <br><small class="text-secondary"><?php echo htmlspecialchars($app['email']); ?> | <?php echo htmlspecialchars($app['phone']); ?></small>
                                    </td>
                                    <td>
                                        <strong class="text-aviation"><?php echo htmlspecialchars($app['vacancy_title']); ?></strong>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($app['department_name']); ?></small>
                                    </td>
                                    <td>
                                        <!-- Real file viewing or mock -->
                                        <a href="<?php echo get_base_url() . '/' . $app['resume_path']; ?>" target="_blank" class="btn btn-sm btn-light border py-1">
                                            <i class="fa-solid fa-file-pdf text-danger me-1"></i>View CV
                                        </a>
                                    </td>
                                    <td>
                                        <?php 
                                        $badge_c = 'secondary';
                                        if ($app['status'] === 'Shortlisted') $badge_c = 'primary';
                                        if ($app['status'] === 'Interviewing') $badge_c = 'warning text-dark';
                                        if ($app['status'] === 'Offered') $badge_c = 'success';
                                        if ($app['status'] === 'Rejected') $badge_c = 'danger';
                                        ?>
                                        <span class="badge bg-<?php echo $badge_c; ?>"><?php echo $app['status']; ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <!-- Action: Update status -->
                                            <form method="POST" action="recruitment.php" class="d-inline">
                                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                <input type="hidden" name="action" value="update_applicant_status">
                                                <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                                <select name="status" class="form-select form-select-sm d-inline-block w-auto py-0 px-1" onchange="this.form.submit()" style="font-size:0.75rem;">
                                                    <option value="">Update Status</option>
                                                    <option value="Applied">Applied</option>
                                                    <option value="Shortlisted">Shortlisted</option>
                                                    <option value="Offered">Offered</option>
                                                    <option value="Rejected">Rejected</option>
                                                </select>
                                            </form>
                                            
                                            <!-- Action: Schedule Interview Modal Trigger -->
                                            <button type="button" class="btn btn-sm btn-aviation py-0 px-2" data-bs-toggle="modal" data-bs-target="#scheduleModal<?php echo $app['id']; ?>" style="font-size:0.75rem;">
                                                Schedule
                                            </button>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Schedule Interview Modal -->
                                <div class="modal fade" id="scheduleModal<?php echo $app['id']; ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST" action="recruitment.php">
                                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                <input type="hidden" name="action" value="schedule_interview">
                                                <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                                
                                                <div class="modal-header bg-aviation text-white">
                                                    <h5 class="modal-title fw-bold text-white"><i class="fa-solid fa-calendar-days me-2"></i>Schedule Interview</h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-start">
                                                    <p>Candidate Name: <strong><?php echo htmlspecialchars($app['full_name']); ?></strong></p>
                                                    
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Interview Date & Time *</label>
                                                        <input type="datetime-local" class="form-control" name="interview_date" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Interviewer / Panel *</label>
                                                        <select class="form-select" name="interviewer_id" required>
                                                            <option value="">Select Interviewer</option>
                                                            <?php foreach ($staff_members as $sm): ?>
                                                                <option value="<?php echo $sm['id']; ?>">
                                                                    <?php echo htmlspecialchars(display_name($sm)); ?> (<?php echo htmlspecialchars($sm['staff_id']); ?>)
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Interview Mode *</label>
                                                        <select class="form-select" name="mode">
                                                            <option value="Online">Online / Video Call</option>
                                                            <option value="In-Person">In-Person at UAS Headquarters</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Internal Remarks / Agenda</label>
                                                        <textarea class="form-control" name="remarks" rows="2" placeholder="e.g. Technical CRM checklist check..."></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-aviation">Confirm Schedule</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No job applications submitted yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Interviews list -->
    <div class="col-lg-4 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-stopwatch me-2"></i>Upcoming Interviews</h5>
            
            <?php if (count($interviews) > 0): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($interviews as $int): 
                        $status_badge = ($int['status'] === 'Scheduled') ? 'bg-primary' : (($int['status'] === 'Completed') ? 'bg-success' : 'bg-danger');
                    ?>
                        <div class="list-group-item px-0 py-3 text-start">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="fw-bold text-aviation mb-0"><?php echo htmlspecialchars($int['applicant_name']); ?></h6>
                                <span class="badge <?php echo $status_badge; ?>" style="font-size:0.65rem;"><?php echo $int['status']; ?></span>
                            </div>
                            <div class="small text-secondary mb-1">
                                <strong>Role:</strong> <?php echo htmlspecialchars($int['vacancy_title']); ?>
                            </div>
                            <div class="small text-secondary mb-1">
                                <i class="fa-solid fa-clock me-1 text-aviation"></i> <?php echo format_datetime($int['interview_date']); ?>
                            </div>
                            <div class="small text-secondary">
                                <i class="fa-solid fa-video me-1"></i> Mode: <strong><?php echo $int['mode']; ?></strong>
                            </div>
                            <div class="small text-muted mt-2 border-top pt-2">
                                <strong>Panel:</strong> <?php echo htmlspecialchars(display_name($int)); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No interviews scheduled yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal: Post New Job Vacancy -->
<div class="modal fade" id="newVacancyModal" tabindex="-1" aria-labelledby="newVacancyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="recruitment.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="create_vacancy">
                
                <div class="modal-header bg-aviation text-white">
                    <h5 class="modal-title fw-bold text-white" id="newVacancyModalLabel"><i class="fa-solid fa-briefcase me-2"></i>Post New Job Vacancy</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body text-start">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-bold">Vacancy Title *</label>
                            <input type="text" class="form-control" name="title" placeholder="e.g. Boeing 737 First Officer" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Department *</label>
                            <select class="form-select" name="department_id" required>
                                <option value="">Select Department</option>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Job Description *</label>
                        <textarea class="form-control" name="description" rows="4" placeholder="Describe the job duties, role expectations..." required></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Requirements / Qualifications</label>
                        <textarea class="form-control" name="requirements" rows="4" placeholder="Describe experience levels, licensing demands (e.g. ATPL with 1500 hrs)..."></textarea>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-aviation">Publish Job Vacancy</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
