<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * System Configurations & Settings Panel
 */

require_once '../includes/auth.php';
require_once '../includes/mail.php';
require_login();
require_role(['Super Admin', 'HR Director', 'HR Manager']);

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';
$test_result = null;

// Send a test email (shows the real SMTP conversation so problems are easy to see)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'test_email') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "CSRF verification failed.";
    } else {
        $to = trim($_POST['test_to'] ?? '');
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            $error = "Enter a valid email address to send the test to.";
        } else {
            [$ok, $debug, $err] = send_test_email($to);
            $test_result = ['ok' => $ok, 'to' => $to, 'debug' => $debug, 'error' => $err];
            log_activity($user_id, 'EMAIL_TEST', ($ok ? 'Test email sent to ' : 'Test email FAILED to ') . $to);
        }
    }
}

// Clear the email log
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'clear_mail_log') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        @file_put_contents(mail_log_path(), '');
        $message = "Email log cleared.";
    }
}

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_settings') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        $db_settings = [
            'company_name' => $_POST['company_name'] ?? '',
            'system_email' => $_POST['system_email'] ?? '',
            'company_address' => $_POST['company_address'] ?? '',
            'company_phone' => $_POST['company_phone'] ?? '',
            'smtp_host' => $_POST['smtp_host'] ?? '',
            'smtp_port' => $_POST['smtp_port'] ?? '',
            'smtp_user' => $_POST['smtp_user'] ?? '',
            'smtp_secure' => in_array($_POST['smtp_secure'] ?? '', ['ssl', 'tls', 'none'], true) ? $_POST['smtp_secure'] : 'ssl',
            'mail_driver' => in_array($_POST['mail_driver'] ?? '', ['smtp', 'mail', 'log'], true) ? $_POST['mail_driver'] : 'smtp',
            'mail_from_name' => $_POST['mail_from_name'] ?? '',
            'mail_reply_to' => $_POST['mail_reply_to'] ?? '',
            'allowed_email_domain' => strtolower(trim($_POST['allowed_email_domain'] ?? '', " @")),
            'id_card_signature_name' => $_POST['id_card_signature_name'] ?? '',
            'md_name' => $_POST['md_name'] ?? '',
            'md_title' => $_POST['md_title'] ?? 'Managing Director / CEO',
            'letters_require_md' => isset($_POST['letters_require_md']) ? '1' : '0',
            'id_card_signature_title' => $_POST['id_card_signature_title'] ?? ''
        ];
        
        try {
            $pdo->beginTransaction();
            
            // Leave the saved SMTP password unchanged when the field is left blank
            if (($_POST['smtp_pass'] ?? '') !== '') {
                $db_settings['smtp_pass'] = $_POST['smtp_pass'];
            }

            // Save Text Settings (insert the key if it does not exist yet)
            $update_stmt = $pdo->prepare("INSERT INTO `settings` (`setting_value`, `setting_key`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)");
            foreach ($db_settings as $key => $val) {
                $update_stmt->execute([$key === 'smtp_pass' ? $val : trim($val), $key]);
            }
            
            // Handle Signature Image Upload (transparent PNG kept as PNG)
            [$sig_db_path, $sig_err] = save_uploaded_image('signature_image', 'settings', 'signature', false, 600, true);
            if ($sig_err) {
                throw new Exception($sig_err);
            }
            if ($sig_db_path) {
                delete_upload(get_setting('id_card_signature_image'));
                $update_stmt->execute([$sig_db_path, 'id_card_signature_image']);
            }

            // Managing Director signature
            [$md_sig, $md_err] = save_uploaded_image('md_signature', 'settings', 'md_signature', false, 600, true);
            if ($md_err) throw new Exception("MD signature: " . $md_err);
            if ($md_sig) {
                delete_upload(get_setting('md_signature_image'));
                $update_stmt->execute([$md_sig, 'md_signature_image']);
            }

            // Official letterhead header / footer images
            foreach (['header', 'footer'] as $part) {
                [$lh_path, $lh_err] = save_uploaded_image("letterhead_$part", 'settings', "letterhead_$part", false, 2000, true);
                if ($lh_err) throw new Exception("Letterhead $part: " . $lh_err);
                if ($lh_path) {
                    delete_upload(get_setting("letterhead_{$part}_image"));
                    $update_stmt->execute([$lh_path, "letterhead_{$part}_image"]);
                }
                if (isset($_POST["reset_letterhead_$part"])) {
                    delete_upload(get_setting("letterhead_{$part}_image"));
                    $update_stmt->execute(['', "letterhead_{$part}_image"]);
                }
            }

            $pdo->commit();
            log_activity($user_id, 'SYSTEM_SETTINGS_UPDATED', 'Updated portal settings and configurations.');
            $message = "Settings updated successfully.";
            
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = "Failed to save settings: " . $e->getMessage();
        }
    }
}

// Fetch settings to display
$settings_map = [];
try {
    $stmt = $pdo->query("SELECT `setting_key`, `setting_value` FROM `settings`");
    while ($row = $stmt->fetch()) {
        $settings_map[$row['setting_key']] = $row['setting_value'];
    }
} catch (PDOException $e) {
    die("Database error fetching settings: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-gears me-2"></i>System Settings</h2>
        <p class="text-muted">Manage company details, SMTP email configurations, and ID card signatures.</p>
    </div>
</div>

<?php if (!empty($message)): ?>
    <div class="alert alert-success border-0 shadow-sm mb-4 alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger border-0 shadow-sm mb-4 alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<form method="POST" action="settings.php" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
    <input type="hidden" name="action" value="save_settings">

    <div class="row g-4">
        <!-- LEFT COLUMN -->
        <div class="col-lg-6 col-md-12">
            <!-- Company profile settings -->
            <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:12px;">
                <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-building me-2"></i>Company Details</h5>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="company_name">Company Name</label>
                    <input type="text" class="form-control" id="company_name" name="company_name" 
                           value="<?php echo htmlspecialchars($settings_map['company_name'] ?? 'UMZA Aviation Services Ltd'); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="system_email">System Email Address</label>
                    <input type="email" class="form-control" id="system_email" name="system_email" 
                           value="<?php echo htmlspecialchars($settings_map['system_email'] ?? 'info@madzeedigitalservices.name.ng'); ?>" required>
                    <div class="form-text" style="font-size:0.75rem;">Emails sent by the portal will display this address in the From header.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="company_address">Official Company Address</label>
                    <textarea class="form-control" id="company_address" name="company_address" rows="3" required><?php echo htmlspecialchars($settings_map['company_address'] ?? 'Suite D1, UYK HEXAHUB Building, Plot 1077A Balanga Cres, off Uke Street, Garki, AMAC 900110, Federal Capital Territory'); ?></textarea>
                    <div class="form-text" style="font-size:0.75rem;">This address will be printed at the top of all official HR letters.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="company_phone">Official Company Phone</label>
                    <input type="text" class="form-control" id="company_phone" name="company_phone" 
                           value="<?php echo htmlspecialchars($settings_map['company_phone'] ?? '0704 700 0673'); ?>" required>
                </div>
            </div>

            <!-- Official letterhead -->
            <?php require_once '../includes/letterhead.php'; ?>
            <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:12px;">
                <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-file-lines me-2"></i>Official Letterhead</h5>
                <p class="small text-muted">Used on every printed letter, promotion, leave approval and memo (including Head of Department memos), and at the top of portal emails.</p>
                <div class="mb-2 small fw-bold">Header (top of page)</div>
                <img src="<?php echo letterhead_image('header'); ?>" class="img-fluid border rounded mb-2" alt="Letterhead header">
                <input type="file" class="form-control form-control-sm mb-1" name="letterhead_header" accept="image/png,image/jpeg">
                <?php if (!empty($settings_map['letterhead_header_image'])): ?><div class="form-check small mb-2"><input class="form-check-input" type="checkbox" name="reset_letterhead_header" id="rh"><label class="form-check-label" for="rh">Go back to the default header</label></div><?php endif; ?>
                <div class="mb-2 mt-3 small fw-bold">Footer (bottom of page)</div>
                <img src="<?php echo letterhead_image('footer'); ?>" class="img-fluid border rounded mb-2" alt="Letterhead footer">
                <input type="file" class="form-control form-control-sm mb-1" name="letterhead_footer" accept="image/png,image/jpeg">
                <?php if (!empty($settings_map['letterhead_footer_image'])): ?><div class="form-check small"><input class="form-check-input" type="checkbox" name="reset_letterhead_footer" id="rf"><label class="form-check-label" for="rf">Go back to the default footer</label></div><?php endif; ?>
                <div class="form-text">Wide images, about 900 px across (PNG or JPG).</div>
            </div>

            <!-- Managing Director approvals -->
            <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:12px;">
                <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-stamp me-2"></i>Managing Director Approval</h5>
                <div class="form-check form-switch mb-3">
                    <input class="form-check-input" type="checkbox" name="letters_require_md" id="lrm" <?php echo ($settings_map['letters_require_md'] ?? '1') === '1' ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="lrm"><strong>Every HR letter needs MD approval</strong><div class="small text-muted">Staff only receive letters after the MD clicks Approve. Turn off to let HR issue letters directly.</div></label>
                </div>
                <div class="row g-2">
                    <div class="col-md-6"><label class="form-label fw-bold small">MD name on letters</label>
                        <input class="form-control" name="md_name" value="<?php echo htmlspecialchars($settings_map['md_name'] ?? ''); ?>" placeholder="Leave blank to use the MD's account name"></div>
                    <div class="col-md-6"><label class="form-label fw-bold small">MD title</label>
                        <input class="form-control" name="md_title" value="<?php echo htmlspecialchars($settings_map['md_title'] ?? 'Managing Director / CEO'); ?>"></div>
                </div>
                <label class="form-label fw-bold small mt-2">MD signature (transparent PNG)</label>
                <input type="file" class="form-control" name="md_signature" accept="image/png,image/jpeg">
                <?php if (!empty($settings_map['md_signature_image'])): ?><img src="<?php echo photo_url($settings_map['md_signature_image']); ?>" class="mt-2 border rounded p-1" style="max-height:50px;" alt="MD signature"><?php endif; ?>
                <div class="form-text">Give the MD an account with the role <strong>Managing Director</strong> (Staff Directory). They will get an email whenever something needs approval.</div>
            </div>

            <!-- ID Card Signature Settings -->
            <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
                <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-signature me-2"></i>ID Card Signature Manager</h5>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="id_card_signature_name">Signer Name</label>
                    <input type="text" class="form-control" id="id_card_signature_name" name="id_card_signature_name" 
                           value="<?php echo htmlspecialchars($settings_map['id_card_signature_name'] ?? 'Abubakar M. Natiti'); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="id_card_signature_title">Signer Title</label>
                    <input type="text" class="form-control" id="id_card_signature_title" name="id_card_signature_title" 
                           value="<?php echo htmlspecialchars($settings_map['id_card_signature_title'] ?? 'HEAD HUMAN RESOURCES'); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="signature_image">Upload Signature Image (Optional - transparent PNG recommended)</label>
                    <input type="file" class="form-control" id="signature_image" name="signature_image" accept=".png,.jpg,.jpeg,.webp">
                    <div class="form-text" style="font-size:0.75rem;">Overwrites the signature image file used on the back of all printed ID cards.</div>
                    
                    <?php if (!empty($settings_map['id_card_signature_image'])): ?>
                        <div class="mt-3 p-2 bg-light border rounded text-center">
                            <span class="d-block small text-secondary mb-1">Active Signature Image:</span>
                            <img src="<?php echo get_base_url() . '/' . $settings_map['id_card_signature_image'] . '?v=' . time(); ?>" 
                                 alt="Active Signature" style="max-height: 50px; object-fit: contain;">
                        </div>
                    <?php else: ?>
                        <div class="mt-3 p-2 bg-light border rounded text-center text-muted small">
                            Currently using standard cursives font placeholder (Great Vibes).
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- RIGHT COLUMN -->
        <div class="col-lg-6 col-md-12">
            <!-- SMTP Settings -->
            <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
                <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-envelope-open-text me-2"></i>Email Delivery</h5>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="mail_driver">Sending Method</label>
                    <select class="form-select" id="mail_driver" name="mail_driver">
                        <?php $drv = $settings_map['mail_driver'] ?? 'smtp'; ?>
                        <option value="smtp" <?php echo $drv === 'smtp' ? 'selected' : ''; ?>>SMTP (recommended) - falls back to server mail automatically</option>
                        <option value="mail" <?php echo $drv === 'mail' ? 'selected' : ''; ?>>Server mail only (cPanel sendmail, no password needed)</option>
                        <option value="log" <?php echo $drv === 'log' ? 'selected' : ''; ?>>Do not send - write to Email Log only (testing)</option>
                    </select>
                    <div class="form-text" style="font-size:0.75rem;">For cPanel: create the mailbox in <em>cPanel &gt; Email Accounts</em>, then use host <code>mail.yourdomain</code>, port 465 + SSL, the full email address as username, and that mailbox's password.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="smtp_host">SMTP Host</label>
                    <input type="text" class="form-control" id="smtp_host" name="smtp_host" 
                           value="<?php echo htmlspecialchars($settings_map['smtp_host'] ?? ''); ?>" placeholder="mail.yourdomain.com">
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="smtp_port">SMTP Port</label>
                        <input type="text" class="form-control" id="smtp_port" name="smtp_port" 
                               value="<?php echo htmlspecialchars($settings_map['smtp_port'] ?? '465'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="smtp_secure">Secure Protocol</label>
                        <select class="form-select" id="smtp_secure" name="smtp_secure" required>
                            <option value="ssl" <?php echo ($settings_map['smtp_secure'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                            <option value="tls" <?php echo ($settings_map['smtp_secure'] ?? '') === 'tls' ? 'selected' : ''; ?>>TLS</option>
                            <option value="none" <?php echo ($settings_map['smtp_secure'] ?? '') === 'none' ? 'selected' : ''; ?>>None</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="smtp_user">SMTP Username / Email</label>
                    <input type="text" class="form-control" id="smtp_user" name="smtp_user" 
                           value="<?php echo htmlspecialchars($settings_map['smtp_user'] ?? ''); ?>" placeholder="hr@yourdomain.com">
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold" for="smtp_pass">SMTP Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="smtp_pass" name="smtp_pass" autocomplete="new-password"
                               value="" placeholder="<?php echo !empty($settings_map['smtp_pass']) ? 'Saved - leave blank to keep' : 'Mailbox password'; ?>">
                        <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility()"><i class="fa-solid fa-eye" id="passToggleIcon"></i></button>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="mail_from_name">Sender Name</label>
                        <input type="text" class="form-control" id="mail_from_name" name="mail_from_name" value="<?php echo htmlspecialchars($settings_map['mail_from_name'] ?? ''); ?>" placeholder="UMZA Air HR">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="mail_reply_to">Reply-To Email</label>
                        <input type="email" class="form-control" id="mail_reply_to" name="mail_reply_to" value="<?php echo htmlspecialchars($settings_map['mail_reply_to'] ?? ''); ?>" placeholder="hr@umzaair.com">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold" for="allowed_email_domain">Registration Email Domain (optional)</label>
                    <input type="text" class="form-control" id="allowed_email_domain" name="allowed_email_domain" value="<?php echo htmlspecialchars($settings_map['allowed_email_domain'] ?? ''); ?>" placeholder="umzaair.com">
                    <div class="form-text" style="font-size:0.75rem;">When set, staff can only self-register with an address ending in @this-domain.</div>
                </div>

                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-circle-check me-1"></i>Save Configurations</button>
            </div>
        </div>
    </div>
</form>

<?php
$log_lines = [];
$log_file = mail_log_path();
if (is_file($log_file)) {
    $content = file_get_contents($log_file);
    $entries = array_filter(array_map('trim', explode(str_repeat('-', 80), $content)));
    $log_lines = array_slice(array_reverse($entries), 0, 40);
}
?>
<div class="row g-4 mt-1">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 bg-white p-4 h-100" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-paper-plane me-2"></i>Send a Test Email</h5>
            <p class="small text-muted">Save your settings first, then send a test to any inbox you can check.</p>
            <form method="POST" action="settings.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="test_email">
                <div class="input-group">
                    <input type="email" class="form-control" name="test_to" placeholder="you@example.com" value="<?php echo htmlspecialchars($test_result['to'] ?? ($_SESSION['email'] ?? '')); ?>" required>
                    <button class="btn btn-aviation" type="submit"><i class="fa-solid fa-paper-plane me-1"></i>Send Test</button>
                </div>
            </form>
            <?php if ($test_result): ?>
                <div class="alert <?php echo $test_result['ok'] ? 'alert-success' : 'alert-danger'; ?> mt-3 mb-2 small">
                    <?php if ($test_result['ok']): ?>
                        <i class="fa-solid fa-circle-check me-1"></i>Test email accepted for delivery to <strong><?php echo htmlspecialchars($test_result['to']); ?></strong>. Check the inbox and Spam folder.
                    <?php else: ?>
                        <i class="fa-solid fa-circle-exclamation me-1"></i><strong>Sending failed:</strong> <?php echo htmlspecialchars($test_result['error']); ?>
                        <?php if (stripos($test_result['error'], 'authenticate') !== false): ?>
                            <hr class="my-2"><strong>What this means:</strong> the mail server rejected the SMTP username or password. Re-type the mailbox password exactly (reset it in cPanel &gt; Email Accounts if unsure), make sure the username is the full email address, then save and test again. Or choose "Server mail only".
                        <?php elseif (stripos($test_result['error'], 'connect') !== false): ?>
                            <hr class="my-2"><strong>What this means:</strong> the portal could not reach the mail server. Check the host name, and try port 465 + SSL or 587 + TLS.
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if (!empty($test_result['debug'])): ?>
                    <details class="small"><summary class="text-muted">Show server conversation</summary>
                        <pre class="bg-light border rounded p-2 mt-2" style="max-height:220px;overflow:auto;font-size:0.7rem;"><?php echo htmlspecialchars(implode("\n", $test_result['debug'])); ?></pre>
                    </details>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card shadow-sm border-0 bg-white p-4 h-100" style="border-radius:12px;">
            <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                <h5 class="fw-bold text-aviation mb-0"><i class="fa-solid fa-list-check me-2"></i>Email Log (latest 40)</h5>
                <form method="POST" action="settings.php" onsubmit="return confirm('Clear the email log?');">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="clear_mail_log">
                    <button class="btn btn-sm btn-outline-secondary" type="submit">Clear</button>
                </form>
            </div>
            <?php if ($log_lines): ?>
                <div style="max-height:320px;overflow:auto;">
                    <?php foreach ($log_lines as $entry):
                        $first = strtok($entry, "\n");
                        $cls = str_contains($first, 'FAILED') ? 'text-danger' : (str_contains($first, 'SENT') ? 'text-success' : 'text-secondary'); ?>
                        <div class="small border-bottom py-1 <?php echo $cls; ?>" style="font-size:0.75rem;word-break:break-word;"><?php echo htmlspecialchars($first); ?></div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted small mb-0">No emails have been sent yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function togglePasswordVisibility() {
        const passInput = document.getElementById("smtp_pass");
        const toggleIcon = document.getElementById("passToggleIcon");
        if (passInput.type === "password") {
            passInput.type = "text";
            toggleIcon.classList.remove("fa-eye");
            toggleIcon.classList.add("fa-eye-slash");
        } else {
            passInput.type = "password";
            toggleIcon.classList.remove("fa-eye-slash");
            toggleIcon.classList.add("fa-eye");
        }
    }
</script>

<?php require_once '../includes/footer.php'; ?>
