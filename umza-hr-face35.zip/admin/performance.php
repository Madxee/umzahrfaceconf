<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Appraisals & Ratings Management
 */

require_once '../includes/auth.php';
require_feature('performance');
require_once '../includes/mail.php';

// Force HR Admin roles
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle performance report submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_report') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $staff_id_target = intval($_POST['staff_id'] ?? 0);
    $type = $_POST['type'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : null;
    $details = trim($_POST['details'] ?? '');
    $effective_date = $_POST['effective_date'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF validation failed.";
    } elseif ($staff_id_target <= 0 || empty($type) || empty($title) || empty($details)) {
        $error = "Please fill in all report details.";
    } else {
        try {
            // Check target staff
            $stmt = $pdo->prepare("SELECT * FROM `staff` WHERE `id` = ?");
            $stmt->execute([$staff_id_target]);
            $target_staff = $stmt->fetch();
            
            if (!$target_staff) {
                $error = "Employee not found.";
            } else {
                $staff_name = display_name($target_staff);
                
                // Insert Performance Report
                $insert = $pdo->prepare("INSERT INTO `performance_reports` (`staff_id`, `type`, `title`, `rating`, `details`, `effective_date`, `created_by`) 
                                         VALUES (?, ?, ?, ?, ?, ?, ?)");
                $insert->execute([$staff_id_target, $type, $title, $rating, $details, $effective_date, $user_id]);
                
                $report_id = $pdo->lastInsertId();
                
                // Add notification
                add_notification($staff_id_target, "New Performance Evaluation", "A new performance record has been added to your profile: $type ($title).");
                
                log_activity($user_id, 'PERFORMANCE_RECORD_ADDED', "Added $type ID $report_id for $staff_name");
                
                // If it is a Promotion and a new position was specified, we could update the position_id, but the appraisal record itself is the main document.
                
                // Send Email Notification
                $subject = "Performance Evaluation Published - $type";
                $body = "
                    <p>A new performance evaluation record has been added to your file by the HR department.</p>
                    <hr>
                    <p><strong>Evaluation Category:</strong> $type</p>
                    <p><strong>Title / Subject:</strong> " . htmlspecialchars($title) . "</p>
                    " . ($rating ? "<p><strong>Rating:</strong> " . str_repeat('★', $rating) . str_repeat('☆', 5 - $rating) . "</p>" : "") . "
                    <p><strong>Effective Date:</strong> " . ($effective_date ? format_date($effective_date) : 'Immediate') . "</p>
                    <hr>
                    <p><strong>HR Evaluator Comments:</strong><br>" . nl2br(htmlspecialchars($details)) . "</p>
                    <p>You can review your complete appraisal and career timeline history by logging in to the Staff Portal.</p>
                    <p><a href='" . get_base_url() . "/staff/performance.php' class='btn'>View My Appraisals</a></p>";
                
                send_email($target_staff['email'], $staff_name, $subject, $body);
                
                $message = "Performance record added successfully and email sent to $staff_name.";
            }
        } catch (PDOException $e) {
            $error = "Failed to record evaluation: " . $e->getMessage();
        }
    }
    
    // Redirect to clear resubmissions
    $redir_url = "performance.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch recent evaluations
try {
    $reports = $pdo->query("SELECT pr.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, d.name as department, hr.first_name as hr_first, hr.last_name as hr_last 
                            FROM `performance_reports` pr 
                            JOIN `staff` s ON pr.staff_id = s.id 
                            LEFT JOIN `departments` d ON s.department_id = d.id 
                            JOIN `staff` hr ON pr.created_by = hr.id 
                            ORDER BY pr.id DESC")->fetchAll();
    
    // Load staff list for dropdown
    $staff_list = $pdo->query("SELECT `id`, `first_name`, `last_name`, `display_name`, `staff_id` FROM `staff` WHERE `status` = 'Active' ORDER BY `first_name` ASC")->fetchAll();

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-award me-2"></i>Employee Performance & Appraisals</h2>
        <p class="text-muted">Record appraisals, issue commendations, log star ratings, and register staff promotions.</p>
    </div>
    <div class="col-md-6 text-md-end">
        <button class="btn btn-aviation" data-bs-toggle="modal" data-bs-target="#newReportModal">
            <i class="fa-solid fa-square-plus me-1"></i>Create Performance Entry
        </button>
    </div>
</div>

<!-- Modal for New Performance Entry -->
<div class="modal fade" id="newReportModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-aviation text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-award me-2"></i>Add Performance Evaluation Entry</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="performance.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add_report">
                <div class="modal-body text-start">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="staff_id">Select Employee *</label>
                            <select class="form-select" id="staff_id" name="staff_id" required>
                                <option value="">Choose Employee</option>
                                <?php foreach ($staff_list as $st): ?>
                                    <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars(display_name($st)) . " (" . htmlspecialchars($st['staff_id']) . ")"; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="type">Evaluation Category *</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="">Select Category</option>
                                <option value="Performance Report">Performance Report</option>
                                <option value="Appraisal">Appraisal</option>
                                <option value="Rating">Appraisal Rating</option>
                                <option value="Promotion">Promotion</option>
                                <option value="Commendation">Commendation</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="title">Subject / Title *</label>
                            <input type="text" class="form-control" id="title" name="title" placeholder="e.g. 2026 Mid-Year Appraisal / Commendation for Safety" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold" for="rating">Rating (1-5 Stars)</label>
                            <select class="form-select" id="rating" name="rating">
                                <option value="">No Star Rating</option>
                                <option value="5">5 Stars (Excellent)</option>
                                <option value="4">4 Stars (Good)</option>
                                <option value="3">3 Stars (Satisfactory)</option>
                                <option value="2">2 Stars (Needs Improvement)</option>
                                <option value="1">1 Star (Unsatisfactory)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold" for="effective_date">Effective Date</label>
                            <input type="date" class="form-control" id="effective_date" name="effective_date" value="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" for="details">Performance Details / Evaluation Remarks *</label>
                        <textarea class="form-control" id="details" name="details" rows="6" placeholder="Provide complete appraisal feedback, details of promotion, or commendation context..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-aviation btn-sm"><i class="fa-solid fa-save me-1"></i>Save Evaluation</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Evaluations Table -->
<div class="table-responsive-custom">
    <table class="table table-custom align-middle mb-0" style="font-size:0.85rem;">
        <thead>
            <tr>
                <th>Employee Name</th>
                <th>Category</th>
                <th>Subject & Details</th>
                <th>Rating</th>
                <th>Effective Date</th>
                <th>Evaluator</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($reports) > 0): ?>
                <?php foreach ($reports as $r): ?>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars(display_name($r)); ?></strong>
                            <br><small class="text-muted">ID: <?php echo htmlspecialchars($r['staff_code']); ?> | <?php echo htmlspecialchars($r['department']); ?></small>
                        </td>
                        <td>
                            <?php 
                            $badge_class = 'bg-secondary';
                            if ($r['type'] === 'Promotion') $badge_class = 'bg-success';
                            if ($r['type'] === 'Commendation') $badge_class = 'bg-info';
                            if ($r['type'] === 'Appraisal') $badge_class = 'bg-primary';
                            ?>
                            <span class="badge <?php echo $badge_class; ?> p-2 text-white"><?php echo $r['type']; ?></span>
                        </td>
                        <td class="text-wrap" style="max-width: 350px;">
                            <strong><?php echo htmlspecialchars($r['title']); ?></strong>
                            <br><small class="text-secondary d-block text-truncate" style="max-width: 350px;" title="<?php echo htmlspecialchars($r['details']); ?>"><?php echo htmlspecialchars($r['details']); ?></small>
                        </td>
                        <td>
                            <?php if ($r['rating']): ?>
                                <span class="text-warning">
                                    <?php echo str_repeat('★', $r['rating']); ?>
                                    <?php echo str_repeat('☆', 5 - $r['rating']); ?>
                                </span>
                            <?php else: ?>
                                <span class="text-muted">N/A</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $r['effective_date'] ? format_date($r['effective_date']) : 'Immediate'; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($r['hr_first'] . ' ' . $r['hr_last']); ?></strong>
                            <br><small class="text-muted"><?php echo format_date($r['created_at']); ?></small>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center text-muted p-4">No performance appraisal records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once '../includes/footer.php'; ?>
