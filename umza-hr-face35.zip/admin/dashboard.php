<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Admin Dashboard & Analytics Panel
 */

require_once '../includes/header.php';
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Finance Officer', 'Department Head']);

$user_id = $_SESSION['user_id'];
$dept_id = null;

// If Department Head, restrict stats to their own department
if ($_SESSION['role'] === 'Department Head') {
    $stmt = $pdo->prepare("SELECT `department_id` FROM `staff` WHERE `id` = ?");
    $stmt->execute([$user_id]);
    $dept_id = $stmt->fetchColumn();
}

try {
    // 1. STATS CALCULATIONS
    if ($dept_id) {
        $total_staff = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `department_id` = ?");
        $total_staff->execute([$dept_id]);
        $total_staff = $total_staff->fetchColumn();

        $active_staff = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `department_id` = ? AND `status` = 'Active'");
        $active_staff->execute([$dept_id]);
        $active_staff = $active_staff->fetchColumn();

        $pending_staff = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `department_id` = ? AND `status` = 'Pending'");
        $pending_staff->execute([$dept_id]);
        $pending_staff = $pending_staff->fetchColumn();

        $pending_leaves = $pdo->prepare("SELECT COUNT(lr.id) FROM `leave_requests` lr JOIN `staff` s ON lr.staff_id = s.id WHERE s.department_id = ? AND lr.status = 'Pending'");
        $pending_leaves->execute([$dept_id]);
        $pending_leaves = $pending_leaves->fetchColumn();

        $open_complaints = $pdo->prepare("SELECT COUNT(c.id) FROM `complaints` c JOIN `staff` s ON c.staff_id = s.id WHERE s.department_id = ? AND c.status IN ('Pending', 'Under Review')");
        $open_complaints->execute([$dept_id]);
        $open_complaints = $open_complaints->fetchColumn();
        
        $active_flights = 0;
    } else {
        $total_staff = $pdo->query("SELECT COUNT(*) FROM `staff`")->fetchColumn();
        $active_staff = $pdo->query("SELECT COUNT(*) FROM `staff` WHERE `status` = 'Active'")->fetchColumn();
        $pending_staff = $pdo->query("SELECT COUNT(*) FROM `staff` WHERE `status` = 'Pending'")->fetchColumn();
        $pending_leaves = $pdo->query("SELECT COUNT(*) FROM `leave_requests` WHERE `status` = 'Pending'")->fetchColumn();
        $open_complaints = $pdo->query("SELECT COUNT(*) FROM `complaints` WHERE `status` IN ('Pending', 'Under Review')")->fetchColumn();
        
        // Active flights scheduled
        $active_flights = $pdo->query("SELECT COUNT(*) FROM `flight_schedules` WHERE `status` = 'Scheduled'")->fetchColumn();
    }

    // 2. AVIATION EXPIRY ALARMS (For all crew)
    $expiry_alerts = [];
    if (!in_array($_SESSION['role'], ['Department Head'])) {
        $today = date('Y-m-d');
        $alarm_stmt = $pdo->query("SELECT ar.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code 
                                   FROM `aviation_records` ar 
                                   JOIN `staff` s ON ar.staff_id = s.id 
                                   WHERE ar.license_expiry < '$today' OR ar.medical_expiry < '$today' OR ar.passport_expiry < '$today'");
        $expiry_alerts = $alarm_stmt->fetchAll();
    }

    // 3. CHART DATA QUERIES
    // Leaves by type
    if ($dept_id) {
        $leaves_stmt = $pdo->prepare("SELECT `leave_type` as label, COUNT(lr.id) as count FROM `leave_requests` lr JOIN `staff` s ON lr.staff_id = s.id WHERE s.department_id = ? GROUP BY `leave_type`");
        $leaves_stmt->execute([$dept_id]);
    } else {
        $leaves_stmt = $pdo->query("SELECT `leave_type` as label, COUNT(id) as count FROM `leave_requests` GROUP BY `leave_type`");
    }
    $leaves_data = $leaves_stmt->fetchAll();

    // Staff per department
    $depts_stmt = $pdo->query("SELECT d.name as label, COUNT(s.id) as count FROM `departments` d LEFT JOIN `staff` s ON d.id = s.department_id AND s.status = 'Active' GROUP BY d.id");
    $depts_data = $depts_stmt->fetchAll();

    // Complaints by status
    if ($dept_id) {
        $complaints_stmt = $pdo->prepare("SELECT c.status as label, COUNT(c.id) as count FROM `complaints` c JOIN `staff` s ON c.staff_id = s.id WHERE s.department_id = ? GROUP BY c.status");
        $complaints_stmt->execute([$dept_id]);
    } else {
        $complaints_stmt = $pdo->query("SELECT `status` as label, COUNT(id) as count FROM `complaints` GROUP BY `status`");
    }
    $complaints_data = $complaints_stmt->fetchAll();

    // Staff growth by month (Last 6 months)
    $growth_data = [];
    for ($i = 5; $i >= 0; $i--) {
        $month_end = date('Y-m-t 23:59:59', strtotime("-$i months"));
        $label = date('M Y', strtotime("-$i months"));
        
        if ($dept_id) {
            $g_stmt = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `department_id` = ? AND `created_at` <= ?");
            $g_stmt->execute([$dept_id, $month_end]);
        } else {
            $g_stmt = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `created_at` <= ?");
            $g_stmt->execute([$month_end]);
        }
        $count = $g_stmt->fetchColumn();
        $growth_data[] = ['label' => $label, 'count' => $count];
    }

    // 4. RECENT ACTIVITY LOGS
    if ($dept_id) {
        $logs_stmt = $pdo->prepare("SELECT l.*, s.first_name, s.last_name, s.display_name, s.role FROM `activity_logs` l JOIN `staff` s ON l.user_id = s.id WHERE s.department_id = ? ORDER BY l.id DESC LIMIT 5");
        $logs_stmt->execute([$dept_id]);
    } else {
        $logs_stmt = $pdo->query("SELECT l.*, s.first_name, s.last_name, s.display_name, s.role FROM `activity_logs` l LEFT JOIN `staff` s ON l.user_id = s.id ORDER BY l.id DESC LIMIT 5");
    }
    $recent_logs = $logs_stmt->fetchAll();

} catch (PDOException $e) {
    die("Error fetching dashboard statistics: " . $e->getMessage());
}
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="fw-bold text-aviation">
            <i class="fa-solid fa-chart-pie me-2"></i>Management Dashboard
            <button class="btn btn-sm btn-outline-aviation float-end" style="font-size: 0.85rem;" data-bs-toggle="modal" data-bs-target="#editNameModal">
                <i class="fa-solid fa-user-pen"></i> Edit My Name
            </button>
        </h2>
        <p class="text-muted">Welcome to the UMZA Aviation Services Ltd HR Management Portal. Roster flight schedules, audit profiles and monitor compliance metrics.</p>
    </div>
</div>

<!-- Warning Alarms: Aviation Expiry Alarms -->
<?php if (count($expiry_alerts) > 0): ?>
    <div class="alert alert-danger border-0 shadow-sm mb-4 p-3" role="alert">
        <h6 class="alert-heading fw-bold mb-2"><i class="fa-solid fa-triangle-exclamation me-1"></i>CRITICAL FLIGHT SAFETY ALARM: EXPIRED CREW DOCUMENTS</h6>
        <div class="row g-2 small" style="max-height:120px; overflow-y:auto;">
            <?php foreach ($expiry_alerts as $alarm): 
                $today = date('Y-m-d');
                $is_lic_exp = ($alarm['license_expiry'] && $alarm['license_expiry'] < $today);
                $is_med_exp = ($alarm['medical_expiry'] && $alarm['medical_expiry'] < $today);
                $is_pass_exp = ($alarm['passport_expiry'] && $alarm['passport_expiry'] < $today);
            ?>
                <div class="col-md-6 border-bottom pb-1">
                    <strong><?php echo htmlspecialchars(display_name($alarm)); ?> (<?php echo htmlspecialchars($alarm['staff_code']); ?>):</strong>
                    <?php if ($is_lic_exp) echo '<span class="text-danger fw-bold">[Expired License]</span> '; ?>
                    <?php if ($is_med_exp) echo '<span class="text-danger fw-bold">[Expired Medical Certificate]</span> '; ?>
                    <?php if ($is_pass_exp) echo '<span class="text-danger fw-bold">[Expired Passport]</span> '; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <p class="mb-0 mt-2 small text-muted">Aviation regulations forbid rostering flight crew members with expired certificates. Grounded crew members are highlighted above.</p>
    </div>
<?php endif; ?>

<!-- Statistics Cards Grid -->
<div class="row g-3 mb-4">
    <!-- Card 1: Total Staff -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm border-0 glass-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon me-3">
                    <i class="fa-solid fa-users"></i>
                </div>
                <div>
                    <h6 class="text-uppercase text-muted mb-1" style="font-size: 0.75rem; letter-spacing: 0.5px;">Active Staff</h6>
                    <h3 class="fw-bold mb-0 text-aviation"><?php echo $active_staff; ?></h3>
                    <small class="text-secondary"><?php echo $total_staff; ?> Total Registry</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Card 2: Pending Approval -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm border-0 glass-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-warning-subtle text-warning me-3">
                    <i class="fa-solid fa-user-clock"></i>
                </div>
                <div>
                    <h6 class="text-uppercase text-muted mb-1" style="font-size: 0.75rem; letter-spacing: 0.5px;">Pending Approval</h6>
                    <h3 class="fw-bold mb-0 text-warning"><?php echo $pending_staff; ?></h3>
                    <small class="text-muted">Awaiting HR Approval</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Pending Leaves -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm border-0 glass-card">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-info-subtle text-info me-3">
                    <i class="fa-solid fa-calendar-minus"></i>
                </div>
                <div>
                    <h6 class="text-uppercase text-muted mb-1" style="font-size: 0.75rem; letter-spacing: 0.5px;">Pending Leaves</h6>
                    <h3 class="fw-bold mb-0 text-info"><?php echo $pending_leaves; ?></h3>
                    <small class="text-muted">Awaiting Verification</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 4: Flight Schedules -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm border-0 bg-aviation text-white">
            <div class="card-body d-flex align-items-center">
                <div class="stat-icon bg-white text-aviation me-3">
                    <i class="fa-solid fa-plane-departure"></i>
                </div>
                <div>
                    <h6 class="text-uppercase text-white-50 mb-1" style="font-size: 0.75rem; letter-spacing: 0.5px;">Rostered Flights</h6>
                    <h3 class="fw-bold mb-0 text-white"><?php echo $active_flights; ?></h3>
                    <small class="text-white-50">Active Roster Duties</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Charts Grid -->
<div class="row g-4 mb-4">
    <!-- Chart 1: Department Statistics -->
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 p-3 h-100 bg-white" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-chart-pie me-2"></i>Department Distribution (Active)</h5>
            <div class="chart-container" style="position: relative; height:280px; width:100%">
                <canvas id="deptChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart 2: Staff Growth -->
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 p-3 h-100 bg-white" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-chart-line me-2"></i>Staff Growth Curve</h5>
            <div class="chart-container" style="position: relative; height:280px; width:100%">
                <canvas id="growthChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart 3: Leave Types -->
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 p-3 h-100 bg-white" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-chart-bar me-2"></i>Leaves Approved by Category</h5>
            <div class="chart-container" style="position: relative; height:280px; width:100%">
                <canvas id="leaveChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart 4: Complaints Statuses -->
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 p-3 h-100 bg-white" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-triangle-exclamation me-2"></i>Grievances Status</h5>
            <div class="chart-container" style="position: relative; height:280px; width:100%">
                <canvas id="complaintsChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Audit Trail Logs -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card shadow-sm border-0 bg-white" style="border-radius: 12px; overflow: hidden;">
            <div class="card-header bg-aviation p-3 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0 text-white"><i class="fa-solid fa-receipt me-2"></i>Audit Trail & Activity Logs</h5>
                <span class="badge bg-light text-success fw-bold text-uppercase">Security Operations Logs</span>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0" style="vertical-align: middle; font-size: 0.85rem;">
                    <thead class="table-light">
                        <tr>
                            <th>Time</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Details</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($recent_logs) > 0): ?>
                            <?php foreach ($recent_logs as $log): ?>
                                <tr>
                                    <td><?php echo format_datetime($log['created_at']); ?></td>
                                    <td>
                                        <?php if ($log['user_id']): ?>
                                            <strong><?php echo htmlspecialchars(display_name($log)); ?></strong> 
                                            <br><small class="text-muted"><?php echo htmlspecialchars($log['role']); ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">System/Guest</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($log['action']); ?></span>
                                    </td>
                                    <td class="text-wrap" style="max-width: 350px;"><?php echo htmlspecialchars($log['details']); ?></td>
                                    <td><code class="text-secondary"><?php echo htmlspecialchars($log['ip_address']); ?></code></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted p-4">No recent logs found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Render Charts via JS -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const deptLabels = <?php echo json_encode(array_column($depts_data, 'label')); ?>;
        const deptCounts = <?php echo json_encode(array_column($depts_data, 'count')); ?>;
        
        const growthLabels = <?php echo json_encode(array_column($growth_data, 'label')); ?>;
        const growthCounts = <?php echo json_encode(array_column($growth_data, 'count')); ?>;

        const leaveLabels = <?php echo json_encode(array_column($leaves_data, 'label')); ?>;
        const leaveCounts = <?php echo json_encode(array_column($leaves_data, 'count')); ?>;

        const complaintLabels = <?php echo json_encode(array_column($complaints_data, 'label')); ?>;
        const complaintCounts = <?php echo json_encode(array_column($complaints_data, 'count')); ?>;

        // Colors
        const classicGreen = '#2d6a4f';
        const mintGreen = '#52b788';
        const warningOrange = '#dd6b20';
        const infoBlue = '#3182ce';
        const grayColor = '#718096';

        // Department Chart
        new Chart(document.getElementById('deptChart'), {
            type: 'doughnut',
            data: {
                labels: deptLabels,
                datasets: [{
                    data: deptCounts,
                    backgroundColor: [classicGreen, mintGreen, '#1d3557', '#457b9d', '#e63946', '#f4a261', '#2a9d8f', '#e9c46a', '#a8dadc', '#8338ec', '#ff006e']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'right', labels: { boxWidth: 10, font: { size: 9 } } } }
            }
        });

        // Growth Chart
        new Chart(document.getElementById('growthChart'), {
            type: 'line',
            data: {
                labels: growthLabels,
                datasets: [{
                    label: 'Total Staff Count',
                    data: growthCounts,
                    borderColor: classicGreen,
                    backgroundColor: 'rgba(45, 106, 79, 0.05)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
            }
        });

        // Leaves Chart
        new Chart(document.getElementById('leaveChart'), {
            type: 'bar',
            data: {
                labels: leaveLabels,
                datasets: [{
                    label: 'Request Count',
                    data: leaveCounts,
                    backgroundColor: mintGreen,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
            }
        });

        // Complaints Chart
        new Chart(document.getElementById('complaintsChart'), {
            type: 'doughnut',
            data: {
                labels: complaintLabels,
                datasets: [{
                    data: complaintCounts,
                    backgroundColor: [warningOrange, infoBlue, classicGreen, grayColor]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'right', labels: { boxWidth: 10, font: { size: 10 } } } }
            }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>
