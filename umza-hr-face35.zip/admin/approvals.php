<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Managing Director approvals: letters and memos sent by HR
 */

require_once '../includes/auth.php';
require_once '../includes/memos_lib.php';
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer']);

$user_id = (int)$_SESSION['user_id'];
$can_decide = is_md() || $_SESSION['role'] === 'Super Admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $msg = '';
    $err = '';
    if (!$can_decide) {
        $err = "Only the Managing Director can approve.";
    } elseif (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $err = "Security check failed. Please try again.";
    } else {
        $kind = $_POST['kind'] ?? '';
        $id = intval($_POST['id'] ?? 0);
        $decision = ($_POST['decision'] ?? '') === 'approve' ? 'approve' : 'reject';
        $comment = trim($_POST['comment'] ?? '');

        if ($decision === 'reject' && $comment === '') {
            $err = "Please write what should be corrected when returning an item.";
        } elseif ($kind === 'letter') {
            $q = $pdo->prepare("SELECT l.*, s.email, s.first_name, s.last_name, s.display_name, hr.email AS hr_email, hr.first_name AS hr_first, hr.id AS hr_id
                                FROM `staff_letters` l JOIN `staff` s ON s.id = l.staff_id LEFT JOIN `staff` hr ON hr.id = l.created_by
                                WHERE l.id = ? AND l.status = 'Pending MD'");
            $q->execute([$id]);
            $l = $q->fetch();
            if (!$l) {
                $err = "This letter is no longer waiting for approval.";
            } else {
                $pdo->prepare("UPDATE `staff_letters` SET `status` = ?, `md_id` = ?, `md_decision_at` = NOW(), `md_comment` = ? WHERE `id` = ?")
                    ->execute([$decision === 'approve' ? 'Approved' : 'Rejected', $user_id, $comment ?: null, $id]);
                log_activity($user_id, $decision === 'approve' ? 'MD_LETTER_APPROVED' : 'MD_LETTER_RETURNED', "Letter #$id: {$l['title']}" . ($comment ? " - $comment" : ''));
                if ($decision === 'approve') {
                    // Staff member receives the letter
                    add_notification($l['staff_id'], "New official letter", "Your " . $l['letter_type'] . " (\"" . $l['title'] . "\") has been issued.");
                    $link = get_base_url() . "/staff/print-letter.php?id=$id";
                    send_email($l['email'], $l['recipient_name'] ?: display_name($l), "Official " . $l['letter_type'] . ": " . $l['title'],
                        "<p>An official <strong>" . htmlspecialchars($l['letter_type']) . "</strong> has been approved by the Managing Director and issued to you.</p>
                         <p><strong>Subject:</strong> " . htmlspecialchars($l['title']) . "</p>
                         <p><a href='$link' class='btn'>Open Official Letter</a></p>");
                }
                if (!empty($l['hr_email'])) {
                    add_notification($l['hr_id'], $decision === 'approve' ? 'Letter approved by MD' : 'Letter returned by MD', "\"{$l['title']}\"" . ($comment ? ": $comment" : ''));
                    send_email($l['hr_email'], $l['hr_first'], ($decision === 'approve' ? 'Approved' : 'Returned for correction') . ": " . $l['title'],
                        "<p>The Managing Director has <strong>" . ($decision === 'approve' ? 'APPROVED' : 'RETURNED') . "</strong> the letter <strong>" . htmlspecialchars($l['title']) . "</strong> for " . htmlspecialchars($l['recipient_name'] ?: display_name($l)) . ".</p>"
                        . ($comment ? "<p><strong>MD comment:</strong> " . nl2br(htmlspecialchars($comment)) . "</p>" : '')
                        . ($decision === 'approve' ? "<p>The staff member has been notified.</p>" : "<p>Please correct it and send it again.</p><p><a href='" . get_base_url() . "/admin/letters.php?edit=$id' class='btn'>Correct Letter</a></p>"));
                }
                $msg = $decision === 'approve' ? "Letter approved and issued to the staff member." : "Letter returned to HR for correction.";
            }
        } elseif ($kind === 'memo') {
            $q = $pdo->prepare("SELECT m.*, s.email AS hr_email, s.first_name AS hr_first, s.first_name, s.last_name, s.display_name FROM `memos` m LEFT JOIN `staff` s ON s.id = m.created_by WHERE m.id = ? AND m.status = 'Pending MD'");
            $q->execute([$id]);
            $m = $q->fetch();
            if (!$m) {
                $err = "This memo is no longer waiting for approval.";
            } else {
                $pdo->prepare("UPDATE `memos` SET `status` = ?, `md_id` = ?, `md_decision_at` = NOW(), `md_comment` = ? WHERE `id` = ?")
                    ->execute([$decision === 'approve' ? 'Published' : 'Rejected', $user_id, $comment ?: null, $id]);
                log_activity($user_id, $decision === 'approve' ? 'MD_MEMO_APPROVED' : 'MD_MEMO_RETURNED', "Memo #$id: {$m['title']}" . ($comment ? " - $comment" : ''));
                if ($decision === 'approve') {
                    $sent = distribute_memo($m, display_name($m) ?: 'Human Resources');
                    $msg = "Memo approved and sent to $sent staff.";
                } else {
                    $msg = "Memo returned to HR.";
                }
                if (!empty($m['hr_email'])) {
                    add_notification($m['created_by'], $decision === 'approve' ? 'Memo approved by MD' : 'Memo returned by MD', "\"{$m['title']}\"" . ($comment ? ": $comment" : ''));
                    send_email($m['hr_email'], $m['hr_first'], ($decision === 'approve' ? 'Approved' : 'Returned') . ": " . $m['title'],
                        "<p>The Managing Director has <strong>" . ($decision === 'approve' ? 'APPROVED and published' : 'RETURNED') . "</strong> the memo <strong>" . htmlspecialchars($m['title']) . "</strong>.</p>"
                        . ($comment ? "<p><strong>MD comment:</strong> " . nl2br(htmlspecialchars($comment)) . "</p>" : ''));
                }
            }
        }
    }
    header("Location: approvals.php?" . ($err ? "error=" . urlencode($err) : "success=" . urlencode($msg)));
    exit;
}

$pending_letters = $pdo->query("SELECT l.*, s.first_name, s.last_name, s.display_name, s.staff_id AS staff_code, hr.first_name AS hr_first, hr.last_name AS hr_last, hr.display_name AS hr_display
                                FROM `staff_letters` l JOIN `staff` s ON s.id = l.staff_id LEFT JOIN `staff` hr ON hr.id = l.created_by
                                WHERE l.status = 'Pending MD' ORDER BY l.submitted_at, l.id")->fetchAll();
$pending_memos = $pdo->query("SELECT m.*, s.first_name, s.last_name, s.display_name FROM `memos` m LEFT JOIN `staff` s ON s.id = m.created_by
                              WHERE m.status = 'Pending MD' ORDER BY m.id")->fetchAll();
$recent = $pdo->query("(SELECT 'Letter' AS kind, l.id, l.title, l.status, l.md_decision_at AS decided, l.md_comment FROM `staff_letters` l WHERE l.md_decision_at IS NOT NULL AND l.md_id IS NOT NULL)
                       UNION ALL
                       (SELECT 'Memo', m.id, m.title, m.status, m.md_decision_at, m.md_comment FROM `memos` m WHERE m.md_decision_at IS NOT NULL)
                       ORDER BY decided DESC LIMIT 15")->fetchAll();

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-stamp me-2"></i>MD Approvals</h2>
        <p class="text-muted mb-0"><?php echo $can_decide ? 'Read each item on the company letterhead, then approve it or return it to HR with your comments.' : 'Items HR has sent to the Managing Director. You can correct returned letters in HR Letters.'; ?></p>
    </div>
</div>

<?php $items = array_merge(
    array_map(fn($l) => ['kind' => 'letter', 'row' => $l, 'title' => $l['title'], 'type' => $l['letter_type'],
        'for' => $l['recipient_name'] ?: display_name($l), 'by' => display_name(['display_name' => $l['hr_display'], 'first_name' => $l['hr_first'], 'last_name' => $l['hr_last']]),
        'when' => $l['submitted_at'] ?: $l['created_at'], 'preview' => get_base_url() . '/staff/print-letter.php?id=' . $l['id']], $pending_letters),
    array_map(fn($m) => ['kind' => 'memo', 'row' => $m, 'title' => $m['title'], 'type' => $m['type'],
        'for' => ($m['audience'] === 'Department' ? dept_title($m['department_id']) : 'All Staff'), 'by' => display_name($m),
        'when' => $m['created_at'], 'preview' => get_base_url() . '/staff/print-memo.php?id=' . $m['id']], $pending_memos)
); ?>

<?php if (!$items): ?>
    <div class="card shadow-sm border-0 p-5 text-center mb-4" style="border-radius:12px;">
        <i class="fa-solid fa-circle-check fa-3x text-success mb-3"></i>
        <h5 class="fw-bold text-aviation">Nothing waiting for approval</h5>
        <p class="text-muted mb-0">Letters and memos that HR sends to the MD will appear here.</p>
    </div>
<?php endif; ?>

<?php foreach ($items as $it): $id = (int)$it['row']['id']; ?>
    <div class="card shadow-sm border-0 mb-4" style="border-radius:12px;overflow:hidden;">
        <div class="card-header bg-light d-flex flex-wrap justify-content-between align-items-center gap-2 p-3">
            <div>
                <span class="badge bg-aviation"><?php echo $it['kind'] === 'letter' ? 'Letter' : 'Memo'; ?></span>
                <span class="badge bg-light text-dark border"><?php echo htmlspecialchars($it['type']); ?></span>
                <h5 class="fw-bold text-aviation mb-0 mt-1"><?php echo htmlspecialchars($it['title']); ?></h5>
                <small class="text-muted">For: <strong><?php echo htmlspecialchars($it['for']); ?></strong> &middot; From: <?php echo htmlspecialchars($it['by']); ?> &middot; <?php echo format_datetime($it['when']); ?></small>
            </div>
            <a href="<?php echo $it['preview']; ?>" target="_blank" class="btn btn-sm btn-outline-aviation"><i class="fa-solid fa-up-right-from-square me-1"></i>Open full page</a>
        </div>
        <div class="card-body p-3">
            <div class="row g-3">
                <div class="col-lg-8">
                    <iframe src="<?php echo $it['preview']; ?>&embed=1" style="width:100%;height:560px;border:1px solid #dee2e6;border-radius:8px;background:#e9ecef;" title="Preview"></iframe>
                </div>
                <div class="col-lg-4">
                    <?php if ($can_decide): ?>
                        <form method="POST" class="mb-3">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="kind" value="<?php echo $it['kind']; ?>">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="hidden" name="decision" value="approve">
                            <button class="btn btn-success w-100 py-3 fw-bold" onclick="return confirm('Approve this <?php echo $it['kind']; ?>? It will be sent out immediately.');"><i class="fa-solid fa-check-double me-1"></i>APPROVE</button>
                        </form>
                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="kind" value="<?php echo $it['kind']; ?>">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="hidden" name="decision" value="reject">
                            <label class="form-label small fw-bold">Return to HR with corrections</label>
                            <textarea class="form-control mb-2" name="comment" rows="4" placeholder="e.g. Correct the effective date to 1st January and add the new grade level." required></textarea>
                            <button class="btn btn-outline-danger w-100"><i class="fa-solid fa-rotate-left me-1"></i>Return for Correction</button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-warning small"><i class="fa-solid fa-hourglass-half me-1"></i>Waiting for the Managing Director.</div>
                        <?php if ($it['kind'] === 'letter'): ?><a href="letters.php?edit=<?php echo $id; ?>" class="btn btn-sm btn-outline-secondary w-100"><i class="fa-solid fa-pen me-1"></i>Correct before approval</a><?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<?php if ($recent): ?>
<div class="card shadow-sm border-0 p-4" style="border-radius:12px;">
    <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-clock-rotate-left me-2"></i>Recent MD Decisions</h5>
    <div class="table-responsive">
        <table class="table table-sm mb-0" style="font-size:0.85rem;">
            <thead><tr><th>Item</th><th>Title</th><th>Decision</th><th>Date</th><th>Comment</th></tr></thead>
            <tbody>
            <?php foreach ($recent as $r): $approved = in_array($r['status'], ['Approved', 'Published'], true); ?>
                <tr>
                    <td><?php echo $r['kind']; ?></td>
                    <td><?php echo htmlspecialchars($r['title']); ?></td>
                    <td><span class="badge <?php echo $approved ? 'bg-success' : 'bg-danger'; ?>"><?php echo $approved ? 'Approved' : 'Returned'; ?></span></td>
                    <td><?php echo format_datetime($r['decided']); ?></td>
                    <td class="small text-muted"><?php echo htmlspecialchars($r['md_comment'] ?? ''); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
