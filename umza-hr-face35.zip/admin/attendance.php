<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Attendance & Shift Management Hub
 */

require_once '../includes/auth.php';
require_feature('attendance');
require_login();
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Finance Officer', 'Department Head']);

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';
$date_filter = $_GET['date'] ?? date('Y-m-d');
$dept_filter = intval($_GET['dept'] ?? 0);

// Restrict department head to their own department
if ($_SESSION['role'] === 'Department Head') {
    $stmt = $pdo->prepare("SELECT `department_id` FROM `staff` WHERE `id` = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $dept_filter = intval($stmt->fetchColumn());
}

// ---- Face registration done in the HR officer's browser from staff passport photos ----
if (isset($_GET['face_list']) && is_hr_role()) {
    header('Content-Type: application/json');
    $rows = $pdo->query("SELECT `id`, `first_name`, `last_name`, `display_name`, `passport_photo`, `face_descriptor_photo`, `face_descriptor`, `face_source` FROM `staff`
                         WHERE `status` = 'Active' AND `passport_photo` IS NOT NULL AND `passport_photo` <> ''")->fetchAll();
    $out = [];
    foreach ($rows as $r) {
        $current = !empty($r['face_descriptor']) && (in_array($r['face_source'], ['registration', 'capture'], true) || $r['face_descriptor_photo'] === $r['passport_photo']);
        if ((!$current || isset($_GET['all'])) && upload_path_url($r['passport_photo']) !== '') {
            $out[] = ['id' => (int)$r['id'], 'name' => display_name($r), 'photo' => upload_path_url($r['passport_photo']), 'path' => $r['passport_photo']];
        }
    }
    echo json_encode($out);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'face_enrol') {
    header('Content-Type: application/json');
    if (!is_hr_role() || !verify_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['ok' => false, 'error' => 'Not allowed']);
        exit;
    }
    $sid = intval($_POST['staff_id'] ?? 0);
    $path = $_POST['path'] ?? '';
    $desc = parse_face_descriptor($_POST['descriptor'] ?? '');
    if ($desc) {
        // Never overwrite a face captured live at registration / first clock-in
        $pdo->prepare("UPDATE `staff` SET `face_descriptor` = ?, `face_descriptor_photo` = ?, `face_source` = 'passport', `face_enrolled_by` = 'hr', `face_enrolled_at` = NOW()
                       WHERE `id` = ? AND `passport_photo` = ? AND (`face_source` IS NULL OR `face_source` = 'passport')")->execute([json_encode($desc), $path, $sid, $path]);
        log_activity($_SESSION['user_id'], 'FACE_ENROLLED', "Registered face for staff #$sid from passport photo");
    }
    echo json_encode(['ok' => (bool)$desc]);
    exit;
}

// Handle actions (Create Shift)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Only HR and Super Admin can create shifts
    require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);
    
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        if ($action === 'create_shift') {
            $name = trim($_POST['name']);
            $start = $_POST['start_time'];
            $end = $_POST['end_time'];
            $desc = trim($_POST['description'] ?? '');
            
            if (empty($name) || empty($start) || empty($end)) {
                $error = "Shift name, start time, and end time are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `shifts` (`name`, `start_time`, `end_time`, `description`) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$name, $start, $end, $desc ?: null]);
                    log_activity($_SESSION['user_id'], 'SHIFT_CREATED', "Created new shift: $name");
                    $success = "Shift created successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to create shift: " . $e->getMessage();
                }
            }
        }
    }
    
    $redir_url = "attendance.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch active shifts
try {
    $shifts = $pdo->query("SELECT * FROM `shifts` ORDER BY `name` ASC")->fetchAll();
} catch (PDOException $e) {
    $shifts = [];
}

// Fetch daily attendance records based on filter date and department
try {
    $params = [$date_filter];
    $query_where = "";
    // Heads of Department only see their own department
    if ($_SESSION['role'] === 'Department Head') {
        $dept_filter = get_user_department_id();
    }
    
    if ($dept_filter > 0) {
        $query_where .= " AND s.department_id = ?";
        $params[] = $dept_filter;
    }
    
    $sql = "SELECT a.*, s.first_name, s.last_name, s.display_name, s.passport_photo, s.staff_id as staff_code,
                   li.name AS in_loc, lo.name AS out_loc, d.name as department_name, p.title as position_title, sh.name as shift_name 
            FROM `staff` s 
            LEFT JOIN `attendance` a ON s.id = a.staff_id AND a.date = ? 
            LEFT JOIN `departments` d ON s.department_id = d.id 
            LEFT JOIN `positions` p ON s.position_id = p.id 
            LEFT JOIN `shifts` sh ON a.shift_id = sh.id 
            LEFT JOIN `attendance_locations` li ON li.id = a.clock_in_location_id
            LEFT JOIN `attendance_locations` lo ON lo.id = a.clock_out_location_id 
            WHERE s.status = 'Active' $query_where 
            ORDER BY a.clock_in DESC, s.first_name ASC";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $attendance_records = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error listing attendance: " . $e->getMessage());
}

// Fetch Statistics counts for dashboard
$present_count = 0;
$late_count = 0;
$absent_count = 0;
$total_overtime = 0.00;

foreach ($attendance_records as $rec) {
    if (empty($rec['clock_in'])) {
        $absent_count++;
    } else {
        $present_count++;
        if ($rec['status'] === 'Late') $late_count++;
        $total_overtime += floatval($rec['overtime_hours'] ?? 0.00);
    }
}

// Fetch departments for filtering
$departments = $pdo->query("SELECT * FROM `departments` ORDER BY `name` ASC")->fetchAll();

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-user-clock me-2"></i>Attendance Dashboard</h2>
        <p class="text-muted">Monitor clock-in/out times, overtime tracking, and schedule operational flight shifts.</p>
    </div>
</div>

<!-- Stats Indicators -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 bg-white glass-card">
            <div class="card-body py-3 d-flex align-items-center">
                <div class="stat-icon bg-success-subtle text-success me-3">
                    <i class="fa-solid fa-check"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-0 text-success"><?php echo $present_count; ?></h4>
                    <small class="text-muted">Total Present</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 bg-white glass-card">
            <div class="card-body py-3 d-flex align-items-center">
                <div class="stat-icon bg-warning-subtle text-warning me-3">
                    <i class="fa-solid fa-clock"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-0 text-warning"><?php echo $late_count; ?></h4>
                    <small class="text-muted">Late Coming Reports</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 bg-white glass-card">
            <div class="card-body py-3 d-flex align-items-center">
                <div class="stat-icon bg-danger-subtle text-danger me-3">
                    <i class="fa-solid fa-user-slash"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-0 text-danger"><?php echo $absent_count; ?></h4>
                    <small class="text-muted">Absent Reports</small>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 bg-white glass-card">
            <div class="card-body py-3 d-flex align-items-center">
                <div class="stat-icon bg-primary-subtle text-primary me-3">
                    <i class="fa-solid fa-business-time"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-0 text-primary"><?php echo $total_overtime; ?> hrs</h4>
                    <small class="text-muted">Flight Overtime Accumulated</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and main display -->
<div class="row g-4">
    <!-- Left Column: Attendance Roster -->
    <div class="col-lg-8 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center border-bottom pb-3 mb-3 gap-2">
                <h5 class="fw-bold text-aviation mb-0"><i class="fa-solid fa-clipboard-user me-2"></i>Daily Duty Checkpoint Sheet</h5>
                
                <!-- Filter form -->
                <form method="GET" action="attendance.php" class="row g-2 align-items-center">
                    <div class="col-auto">
                        <input type="date" class="form-control form-control-sm" name="date" value="<?php echo htmlspecialchars($date_filter); ?>">
                    </div>
                    <?php if ($_SESSION['role'] !== 'Department Head'): ?>
                        <div class="col-auto">
                            <select class="form-select form-select-sm" name="dept">
                                <option value="0">All Departments</option>
                                <?php foreach ($departments as $d): ?>
                                    <option value="<?php echo $d['id']; ?>" <?php echo $dept_filter == $d['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($d['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-sm btn-aviation"><i class="fa-solid fa-filter me-1"></i>Filter</button>
                    </div>
                </form>
            </div>
            
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                    <thead>
                        <tr>
                            <th>Staff Name</th>
                            <th>Department & Title</th>
                            <th>Clock In</th>
                            <th>Clock Out</th>
                            <th>Overtime</th>
                            <th>Status</th>
                            <th>Location (GPS)</th>
                            <th>Face</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attendance_records as $rec): 
                            $clocked = !empty($rec['clock_in']);
                            $status_badge = 'bg-danger';
                            $status_text = 'Absent';
                            if ($clocked) {
                                $status_text = $rec['status'];
                                $status_badge = ($rec['status'] === 'Present') ? 'bg-success' : (($rec['status'] === 'Late') ? 'bg-warning text-dark' : 'bg-secondary');
                            }
                        ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars(display_name($rec)); ?></strong>
                                    <br><small class="text-secondary">ID: <code><?php echo htmlspecialchars($rec['staff_code']); ?></code></small>
                                </td>
                                <td>
                                    <span class="fw-semibold text-aviation"><?php echo htmlspecialchars($rec['department_name']); ?></span>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($rec['position_title']); ?></small>
                                </td>
                                <td><code><?php echo $clocked ? date('H:i A', strtotime($rec['clock_in'])) : '--:--'; ?></code></td>
                                <td><code><?php echo ($clocked && !empty($rec['clock_out'])) ? date('H:i A', strtotime($rec['clock_out'])) : '--:--'; ?></code></td>
                                <td><span class="badge bg-light text-dark border"><?php echo $clocked ? $rec['overtime_hours'] : '0.00'; ?> hrs</span></td>
                                <td>
                                    <span class="badge <?php echo $status_badge; ?>"><?php echo $status_text; ?></span>
                                </td>
                                <td class="small">
                                    <?php if ($clocked): ?>
                                        <?php if (!empty($rec['clock_in_lat'])): ?>
                                            <a href="https://www.google.com/maps?q=<?php echo $rec['clock_in_lat'] . ',' . $rec['clock_in_lng']; ?>" target="_blank" rel="noopener" title="Open clock-in position on map">
                                                <i class="fa-solid fa-location-dot me-1"></i><?php echo htmlspecialchars($rec['in_loc'] ?? 'Outside locations'); ?></a>
                                            <div class="text-muted" style="font-size:0.7rem;"><?php echo $rec['clock_in_distance'] !== null ? (int)$rec['clock_in_distance'] . ' m from centre' : ''; ?><?php echo $rec['clock_in_accuracy'] ? ' · ±' . (int)$rec['clock_in_accuracy'] . ' m' : ''; ?></div>
                                        <?php else: ?><span class="text-muted">No GPS</span><?php endif; ?>
                                        <?php if (!empty($rec['clock_out_lat']) && ($rec['out_loc'] ?? '') !== ($rec['in_loc'] ?? '')): ?>
                                            <div style="font-size:0.7rem;">Out: <a href="https://www.google.com/maps?q=<?php echo $rec['clock_out_lat'] . ',' . $rec['clock_out_lng']; ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($rec['out_loc'] ?? 'Outside'); ?></a></div>
                                        <?php endif; ?>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td class="text-nowrap">
                                    <?php if ($clocked && $rec['clock_in_face_score'] !== null): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle mb-1" title="Face match score (distance <?php echo $rec['clock_in_face_score']; ?>)"><i class="fa-solid fa-face-smile me-1"></i><?php echo max(0, round((1 - $rec['clock_in_face_score']) * 100)); ?>% match</span><br>
                                    <?php endif; ?>
                                    <?php if ($clocked && (!empty($rec['clock_in_photo']) || !empty($rec['clock_out_photo']))): ?>
                                        <button type="button" class="btn p-0 border-0" data-bs-toggle="modal" data-bs-target="#faceModal"
                                                data-name="<?php echo htmlspecialchars(display_name($rec)); ?>"
                                                data-passport="<?php echo photo_url($rec['passport_photo']); ?>"
                                                data-in="<?php echo !empty($rec['clock_in_photo']) ? photo_url($rec['clock_in_photo']) : ''; ?>"
                                                data-out="<?php echo !empty($rec['clock_out_photo']) ? photo_url($rec['clock_out_photo']) : ''; ?>"
                                                data-ip="<?php echo htmlspecialchars($rec['ip_address'] ?? ''); ?>"
                                                title="Compare with passport photo">
                                            <img src="<?php echo photo_url($rec['passport_photo']); ?>" class="rounded border" style="width:30px;height:30px;object-fit:cover;" alt="Passport">
                                            <?php if (!empty($rec['clock_in_photo'])): ?><img src="<?php echo photo_url($rec['clock_in_photo']); ?>" class="rounded border border-success" style="width:30px;height:30px;object-fit:cover;" alt="In"><?php endif; ?>
                                            <?php if (!empty($rec['clock_out_photo'])): ?><img src="<?php echo photo_url($rec['clock_out_photo']); ?>" class="rounded border border-danger" style="width:30px;height:30px;object-fit:cover;" alt="Out"><?php endif; ?>
                                        </button>
                                    <?php elseif ($clocked): ?>
                                        <span class="badge bg-light text-muted border">No photo</span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right Column: Shift manager -->
    <div class="col-lg-4 col-md-12">
        <?php if (is_hr_role()):
            $loc_count = (int)$pdo->query("SELECT COUNT(*) FROM `attendance_locations` WHERE `is_active` = 1")->fetchColumn();
            $face_missing = (int)$pdo->query("SELECT COUNT(*) FROM `staff` WHERE `status` = 'Active' AND `passport_photo` IS NOT NULL AND `passport_photo` <> ''
                                               AND (`face_descriptor` IS NULL OR ((`face_source` IS NULL OR `face_source` = 'passport') AND (`face_descriptor_photo` IS NULL OR `face_descriptor_photo` <> `passport_photo`)))")->fetchColumn();
            $no_photo = (int)$pdo->query("SELECT COUNT(*) FROM `staff` WHERE `status` = 'Active' AND (`passport_photo` IS NULL OR `passport_photo` = '')")->fetchColumn(); ?>
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-shield-halved me-2"></i>Clock-in Security</h5>
            <div class="d-flex justify-content-between small mb-2">
                <span><i class="fa-solid fa-location-dot me-1 text-aviation"></i>GPS locations active</span><strong><?php echo $loc_count; ?></strong>
            </div>
            <a href="locations.php" class="btn btn-sm btn-outline-aviation w-100 mb-3"><i class="fa-solid fa-map-location-dot me-1"></i>Manage GPS Locations &amp; Radius</a>
            <div class="d-flex justify-content-between small mb-1">
                <span><i class="fa-solid fa-face-smile me-1 text-aviation"></i>Faces not yet registered</span><strong id="faceMissing"><?php echo $face_missing; ?></strong>
            </div>
            <?php if ($no_photo): ?><div class="small text-danger mb-1"><?php echo $no_photo; ?> active staff have no passport photo (they cannot use face recognition).</div><?php endif; ?>
            <button type="button" class="btn btn-sm btn-aviation w-100" id="btnEnrolFaces"><i class="fa-solid fa-user-check me-1"></i>Register faces from passport photos</button>
            <div class="small text-muted mt-2" id="enrolStatus">Optional. New staff register their face with the camera when they sign up; existing staff register it automatically at their first clock-in. This button prepares a face pattern from passport photos for anyone not yet registered.</div>
        </div>
        <script src="<?php echo base_path(); ?>/libs/face-api/face-api.js"></script>
        <script>
        document.getElementById('btnEnrolFaces').addEventListener('click', async function () {
            const btn = this, out = document.getElementById('enrolStatus');
            btn.disabled = true;
            try {
                const url = <?php echo json_encode(base_path() . '/face-model.php'); ?>;
                out.textContent = 'Loading face recognition...';
                await faceapi.nets.ssdMobilenetv1.loadFromUri(url);
                await faceapi.nets.faceLandmark68Net.loadFromUri(url);
                await faceapi.nets.faceRecognitionNet.loadFromUri(url);
                const list = await fetch('attendance.php?face_list=1', { credentials: 'same-origin' }).then(r => r.json());
                let done = 0, failed = [];
                for (const st of list) {
                    out.textContent = 'Reading ' + st.name + ' (' + (done + failed.length + 1) + ' of ' + list.length + ')...';
                    try {
                        const img = await faceapi.fetchImage(st.photo);
                        const det = await faceapi.detectSingleFace(img, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.3 })).withFaceLandmarks().withFaceDescriptor();
                        if (!det) { failed.push(st.name); continue; }
                        const body = new URLSearchParams({ action: 'face_enrol', csrf_token: <?php echo json_encode(generate_csrf_token()); ?>, staff_id: st.id, path: st.path, descriptor: JSON.stringify(Array.from(det.descriptor)) });
                        const r = await fetch('attendance.php', { method: 'POST', body, credentials: 'same-origin' }).then(x => x.json());
                        if (r.ok) done++; else failed.push(st.name);
                    } catch (e) { failed.push(st.name); }
                }
                document.getElementById('faceMissing').textContent = failed.length;
                out.innerHTML = 'Registered ' + done + ' face(s).' + (failed.length ? ' <span class="text-danger">No clear face found in the passport photo of: ' + failed.map(n => n.replace(/</g, '&lt;')).join(', ') + '. Upload clearer photos for them.</span>' : '');
            } catch (e) {
                out.textContent = 'Error: ' + e.message;
            }
            btn.disabled = false;
        });
        </script>
        <?php endif; ?>
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-calendar-days me-2"></i>Create New Shift</h5>
            
            <?php if (in_array($_SESSION['role'], ['Super Admin', 'HR Director', 'HR Manager'])): ?>
                <form method="POST" action="attendance.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="create_shift">
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Shift Name *</label>
                        <input type="text" class="form-control form-control-sm" name="name" placeholder="e.g. Flight Dispatch Shift B" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold">Start Time *</label>
                            <input type="time" class="form-control form-control-sm" name="start_time" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold">End Time *</label>
                            <input type="time" class="form-control form-control-sm" name="end_time" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Shift Description</label>
                        <textarea class="form-control form-control-sm" name="description" rows="2" placeholder="Roster notes..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-plus me-1"></i>Create Shift</button>
                </form>
            <?php else: ?>
                <div class="alert alert-secondary mb-0 small"><i class="fa-solid fa-ban me-1"></i> Shift creation is restricted to HR Director and HR Managers.</div>
            <?php endif; ?>
        </div>

        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-stopwatch me-2"></i>Active Operational Shifts</h5>
            
            <div class="list-group list-group-flush">
                <?php foreach ($shifts as $sh): ?>
                    <div class="list-group-item px-0 py-2">
                        <h6 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars($sh['name']); ?></h6>
                        <small class="text-secondary"><i class="fa-solid fa-clock me-1"></i>Hours: <?php echo date('H:i', strtotime($sh['start_time'])); ?> - <?php echo date('H:i', strtotime($sh['end_time'])); ?></small>
                        <p class="text-muted small mb-0"><?php echo htmlspecialchars($sh['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Face capture comparison -->
<div class="modal fade" id="faceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-aviation text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-user-check me-2"></i><span id="faceName">Attendance Photos</span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 text-center">
                    <div class="col-md-4"><div class="small fw-bold text-secondary mb-1">Passport Photo (on file)</div><img id="facePassport" class="img-fluid rounded border" style="max-height:260px;object-fit:cover;"></div>
                    <div class="col-md-4"><div class="small fw-bold text-success mb-1">Clock-In Capture</div><img id="faceIn" class="img-fluid rounded border"><div id="faceInNone" class="text-muted small d-none">None</div></div>
                    <div class="col-md-4"><div class="small fw-bold text-danger mb-1">Clock-Out Capture</div><img id="faceOut" class="img-fluid rounded border"><div id="faceOutNone" class="text-muted small d-none">None</div></div>
                </div>
                <p class="small text-muted mt-3 mb-0">Compare the live captures with the passport photo to confirm the right person clocked in. <span id="faceIp"></span></p>
            </div>
        </div>
    </div>
</div>
<script>
    document.getElementById('faceModal').addEventListener('show.bs.modal', function (e) {
        const b = e.relatedTarget;
        document.getElementById('faceName').textContent = b.dataset.name;
        document.getElementById('facePassport').src = b.dataset.passport;
        document.getElementById('faceIp').textContent = b.dataset.ip ? 'Device IP: ' + b.dataset.ip : '';
        [['in', 'faceIn'], ['out', 'faceOut']].forEach(function (p) {
            const img = document.getElementById(p[1]), none = document.getElementById(p[1] + 'None');
            if (b.dataset[p[0]]) { img.src = b.dataset[p[0]]; img.classList.remove('d-none'); none.classList.add('d-none'); }
            else { img.classList.add('d-none'); none.classList.remove('d-none'); }
        });
    });
</script>

<?php require_once '../includes/footer.php'; ?>
