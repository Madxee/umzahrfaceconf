<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * HR Letters Automatic Generation System
 */

require_once '../includes/auth.php';
require_once '../includes/mail.php';
require_feature('letters');
require_login();
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Finance Officer']);

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

$can_write = is_hr_role() || $_SESSION['role'] === 'Finance Officer';
$require_md = get_setting('letters_require_md', '1') === '1';
$letter_types = ['Employment Letter', 'Confirmation Letter', 'Promotion Letter', 'Query Letter', 'Warning Letter', 'Leave Approval Letter',
                 'Salary Letter', 'Experience Letter', 'Commendation Letter', 'Transfer Letter', 'Suspension Letter', 'Termination Letter', 'General Letter'];

/** Merge {{placeholders}} with staff details. */
function merge_letter_placeholders($text, $staff) {
    return strtr($text, [
        '{{full_name}}' => display_name($staff),
        '{{first_name}}' => $staff['first_name'],
        '{{other_name}}' => $staff['other_name'] ?? '',
        '{{last_name}}' => $staff['last_name'],
        '{{staff_id}}' => $staff['staff_id'],
        '{{position}}' => $staff['position_title'] ?: 'Staff',
        '{{department}}' => $staff['department_name'] ?: 'the Company',
        '{{date}}' => date('jS F, Y'),
        '{{employment_date}}' => format_date($staff['employment_date'], 'jS F, Y'),
    ]);
}

/** Email + notify the staff member that an approved letter is ready. */
function deliver_letter_to_staff($letter_id) {
    global $pdo;
    $q = $pdo->prepare("SELECT l.*, s.email, s.first_name, s.last_name, s.display_name FROM `staff_letters` l JOIN `staff` s ON s.id = l.staff_id WHERE l.id = ?");
    $q->execute([$letter_id]);
    $l = $q->fetch();
    if (!$l) return;
    add_notification($l['staff_id'], "New official letter", "Your " . $l['letter_type'] . " (\"" . $l['title'] . "\") has been issued. View and print it from HR Letters.");
    $link = get_base_url() . "/staff/print-letter.php?id=" . (int)$l['id'];
    send_email($l['email'], $l['recipient_name'] ?: display_name($l), "Official " . $l['letter_type'] . ": " . $l['title'],
        "<p>An official <strong>" . htmlspecialchars($l['letter_type']) . "</strong> has been issued to you by UMZA Aviation Services Ltd.</p>
         <p><strong>Subject:</strong> " . htmlspecialchars($l['title']) . "</p>
         <p>Please log in to view, download or print it on the company letterhead.</p>
         <p><a href='$link' class='btn'>Open Official Letter</a></p>");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $can_write && in_array($_POST['action'] ?? '', ['save_letter', 'delete_letter'], true)) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security check failed. Please try again.";
    } elseif ($_POST['action'] === 'delete_letter') {
        $lid = intval($_POST['letter_id'] ?? 0);
        $pdo->prepare("DELETE FROM `staff_letters` WHERE `id` = ?")->execute([$lid]);
        log_activity($_SESSION['user_id'], 'HR_LETTER_DELETED', "Deleted letter #$lid");
        $success = "Letter deleted.";
    } else {
        $lid = intval($_POST['letter_id'] ?? 0);
        $staff_id = intval($_POST['staff_id'] ?? 0);
        $letter_type = in_array($_POST['letter_type'] ?? '', $letter_types, true) ? $_POST['letter_type'] : '';
        $title = trim($_POST['title'] ?? '');
        $raw_content = trim($_POST['content'] ?? '');
        $recipient_name = trim($_POST['recipient_name'] ?? '');
        $recipient_details = trim($_POST['recipient_details'] ?? '');
        $mode = $_POST['submit_mode'] ?? 'send_md';
        if (!in_array($mode, ['draft', 'send_md', 'approve'], true)) $mode = 'send_md';
        if ($mode === 'approve' && ($require_md || !is_hr_role())) $mode = 'send_md';

        if ($staff_id <= 0 || !$letter_type || $title === '' || $raw_content === '') {
            $error = "Please choose the staff member, letter type, title and write the letter.";
        } else {
            $stmt = $pdo->prepare("SELECT s.*, d.name AS department_name, p.title AS position_title FROM `staff` s
                                   LEFT JOIN `departments` d ON s.department_id = d.id LEFT JOIN `positions` p ON s.position_id = p.id WHERE s.id = ?");
            $stmt->execute([$staff_id]);
            $staff = $stmt->fetch();
            if (!$staff) {
                $error = "Selected employee not found.";
            } else {
                $content = merge_letter_placeholders($raw_content, $staff);
                $title = merge_letter_placeholders($title, $staff);
                $status = ['draft' => 'Draft', 'send_md' => 'Pending MD', 'approve' => 'Approved'][$mode];
                $fields = [$staff_id, $letter_type, $title, $content, $recipient_name ?: null, $recipient_details ?: null, $status, $mode === 'send_md' ? 1 : 0];
                if ($lid) {
                    $pdo->prepare("UPDATE `staff_letters` SET `staff_id`=?, `letter_type`=?, `title`=?, `content`=?, `recipient_name`=?, `recipient_details`=?, `status`=?, `requires_md`=?,
                                   `submitted_at` = IF(? = 'Pending MD', NOW(), `submitted_at`), `md_id` = NULL, `md_decision_at` = NULL WHERE `id`=?")
                        ->execute(array_merge($fields, [$status, $lid]));
                    log_activity($_SESSION['user_id'], 'HR_LETTER_UPDATED', "Updated letter #$lid ($letter_type) - now $status");
                } else {
                    $pdo->prepare("INSERT INTO `staff_letters` (`staff_id`, `letter_type`, `title`, `content`, `recipient_name`, `recipient_details`, `status`, `requires_md`, `submitted_at`, `created_by`)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, " . ($status === 'Pending MD' ? 'NOW()' : 'NULL') . ", ?)")
                        ->execute(array_merge($fields, [$_SESSION['user_id']]));
                    $lid = (int)$pdo->lastInsertId();
                    log_activity($_SESSION['user_id'], 'HR_LETTER_GENERATED', "Created $letter_type for " . display_name($staff) . " - $status");
                }
                if ($status === 'Pending MD') {
                    $n = notify_md_pending($letter_type, $title, $_SESSION['name']);
                    $success = "Letter sent to the Managing Director for approval." . ($n ? '' : ' Note: no active Managing Director account exists yet - create one in Staff Directory (role: Managing Director).');
                } elseif ($status === 'Approved') {
                    $pdo->prepare("UPDATE `staff_letters` SET `md_decision_at` = NOW() WHERE `id` = ?")->execute([$lid]);
                    deliver_letter_to_staff($lid);
                    $success = "Letter approved and issued to " . display_name($staff) . ".";
                } else {
                    $success = "Draft saved. Send it to the MD when ready.";
                }
            }
        }
    }
    header("Location: letters.php?" . ($error ? "error=" . urlencode($error) : "success=" . urlencode($success)));
    exit;
}

// Fetch generated letters log
try {
    $letters_log = $pdo->query("SELECT l.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, hr.first_name as hr_first, hr.last_name as hr_last,
                                       md.first_name AS md_first, md.last_name AS md_last, md.display_name AS md_display
                                FROM `staff_letters` l 
                                JOIN `staff` s ON l.staff_id = s.id 
                                LEFT JOIN `staff` hr ON l.created_by = hr.id 
                                LEFT JOIN `staff` md ON l.md_id = md.id
                                ORDER BY l.id DESC")->fetchAll();
} catch (PDOException $e) {
    $letters_log = [];
}

// Fetch list of active staff for form
$staff_list = $pdo->query("SELECT s.id, s.first_name, s.last_name, s.display_name, s.staff_id, p.title AS position_title, d.name AS department_name
                           FROM `staff` s LEFT JOIN `positions` p ON p.id = s.position_id LEFT JOIN `departments` d ON d.id = s.department_id
                           WHERE s.`status` = 'Active' ORDER BY s.`first_name` ASC")->fetchAll();
$editing = null;
if (!empty($_GET['edit']) && $can_write) {
    $e = $pdo->prepare("SELECT * FROM `staff_letters` WHERE `id` = ?");
    $e->execute([intval($_GET['edit'])]);
    $editing = $e->fetch() ?: null;
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-file-signature me-2"></i>HR Letters Generator</h2>
        <p class="text-muted">Generate formal employment contracts, confirmation letters, queries, warnings, and salary certificates.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Generate Letter Form -->
    <div class="col-lg-5 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-magic me-2"></i><?php echo !empty($editing) ? 'Correct Letter' : 'Write Official Letter'; ?></h5>
            
            <?php if (!$can_write): ?>
                <p class="text-muted small mb-0">Letters are written by HR. Use <a href="approvals.php">MD Approvals</a> to approve letters sent to you.</p>
            <?php else: ?>
            <?php if ($editing): ?>
                <div class="alert alert-warning py-2 small">Editing letter #<?php echo (int)$editing['id']; ?> (status: <strong><?php echo htmlspecialchars($editing['status']); ?></strong>).
                    <?php if (!empty($editing['md_comment'])): ?><br><strong>MD comment:</strong> <?php echo nl2br(htmlspecialchars($editing['md_comment'])); ?><?php endif; ?>
                    <a href="letters.php" class="ms-1">Cancel</a></div>
            <?php endif; ?>
            <form method="POST" action="letters.php" id="letterForm">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="save_letter">
                <input type="hidden" name="letter_id" value="<?php echo (int)($editing['id'] ?? 0); ?>">

                <div class="mb-3">
                    <label class="form-label fw-bold">Recipient Staff *</label>
                    <select class="form-select" name="staff_id" id="staffPick" required>
                        <option value="">Choose Employee</option>
                        <?php foreach ($staff_list as $sm): ?>
                            <option value="<?php echo $sm['id']; ?>" data-name="<?php echo htmlspecialchars(display_name($sm)); ?>"
                                data-details="<?php echo htmlspecialchars(trim(($sm['position_title'] ?? '') . (($sm['department_name'] ?? '') ? ', ' . $sm['department_name'] : ''), ', ')); ?>"
                                <?php echo (int)($editing['staff_id'] ?? 0) === (int)$sm['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars(display_name($sm)); ?> (<?php echo htmlspecialchars($sm['staff_id']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Name on Letter</label>
                        <input type="text" class="form-control" name="recipient_name" id="recipientName" value="<?php echo htmlspecialchars($editing['recipient_name'] ?? ''); ?>" placeholder="e.g. Mr. Chinedu Emeka Okafor">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Position / Department line</label>
                        <input type="text" class="form-control" name="recipient_details" id="recipientDetails" value="<?php echo htmlspecialchars($editing['recipient_details'] ?? ''); ?>" placeholder="e.g. Senior IT Officer, IT Department">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Letter Category *</label>
                        <select class="form-select" id="letter_type" name="letter_type" onchange="injectTemplate()" required>
                            <option value="">Choose Category</option>
                            <?php foreach ($letter_types as $t): ?>
                                <option value="<?php echo $t; ?>" <?php echo ($editing['letter_type'] ?? '') === $t ? 'selected' : ''; ?>><?php echo $t; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Letter Title *</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($editing['title'] ?? ''); ?>" placeholder="e.g. Letter of Promotion" required>
                    </div>
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label class="form-label fw-bold mb-0">Letter Body *</label>
                        <small class="text-secondary" style="font-size:0.7rem;">Placeholders: <code>{{full_name}}</code> <code>{{position}}</code> <code>{{department}}</code> <code>{{date}}</code></small>
                    </div>
                    <textarea class="form-control" id="content" name="content" rows="12" required style="font-family:'Times New Roman',Times,serif; font-size:0.95rem;"><?php echo htmlspecialchars($editing['content'] ?? ''); ?></textarea>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" name="submit_mode" value="send_md" class="btn btn-aviation py-2"><i class="fa-solid fa-paper-plane me-1"></i>Send to MD for Approval</button>
                    <?php if (!$require_md && is_hr_role()): ?>
                        <button type="submit" name="submit_mode" value="approve" class="btn btn-success py-2"><i class="fa-solid fa-check-double me-1"></i>Approve &amp; Issue Now (HR)</button>
                    <?php endif; ?>
                    <button type="submit" name="submit_mode" value="draft" class="btn btn-outline-secondary py-2" formnovalidate><i class="fa-solid fa-floppy-disk me-1"></i>Save as Draft</button>
                </div>
                <div class="form-text mt-2"><?php echo $require_md ? 'Letters reach the staff member only after the Managing Director approves them.' : 'MD approval is optional (System Settings).'; ?></div>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Letters log -->
    <div class="col-lg-7 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i>Generated Letters Log</h5>
            
            <?php if (count($letters_log) > 0): ?>
                <div class="table-responsive" style="max-height: 580px; overflow-y: auto;">
                    <table class="table table-striped table-hover mb-0" style="font-size: 0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Staff Name</th>
                                <th>Letter Title</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($letters_log as $log): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars(display_name($log)); ?></strong>
                                        <br><small class="text-secondary">No: <code><?php echo htmlspecialchars($log['staff_code']); ?></code></small>
                                    </td>
                                    <td>
                                        <span class="fw-semibold text-dark"><?php echo htmlspecialchars($log['title']); ?></span>
                                        <br><small class="text-muted">Date: <?php echo format_date($log['created_at']); ?></small>
                                    </td>
                                    <td><span class="badge bg-light text-aviation border"><?php echo $log['letter_type']; ?></span></td>
                                    <td>
                                        <?php $st = $log['status'] ?? 'Approved';
                                        $cls = ['Approved' => 'bg-success', 'Pending MD' => 'bg-warning text-dark', 'Rejected' => 'bg-danger', 'Draft' => 'bg-secondary'][$st] ?? 'bg-light text-dark'; ?>
                                        <span class="badge <?php echo $cls; ?>"><?php echo $st === 'Rejected' ? 'Returned by MD' : htmlspecialchars($st); ?></span>
                                        <br><small class="text-secondary">By <?php echo htmlspecialchars(trim(($log['hr_first'] ?? '') . ' ' . ($log['hr_last'] ?? ''))); ?></small>
                                        <?php if ($st === 'Approved' && !empty($log['md_id'])): ?><br><small class="text-success">MD: <?php echo htmlspecialchars(display_name(['display_name' => $log['md_display'], 'first_name' => $log['md_first'], 'last_name' => $log['md_last']])); ?></small><?php endif; ?>
                                        <?php if (!empty($log['md_comment']) && $st === 'Rejected'): ?><br><small class="text-danger" title="<?php echo htmlspecialchars($log['md_comment']); ?>">"<?php echo htmlspecialchars(mb_strimwidth($log['md_comment'], 0, 60, '...')); ?>"</small><?php endif; ?>
                                    </td>
                                    <td class="text-nowrap">
                                        <a href="../staff/print-letter.php?id=<?php echo $log['id']; ?>" target="_blank" class="btn btn-sm btn-aviation py-0 px-2" style="font-size:0.75rem;">
                                            <i class="fa-solid fa-eye me-1"></i><?php echo $st === 'Approved' ? 'Print' : 'Preview'; ?>
                                        </a>
                                        <?php if ($can_write): ?>
                                            <a href="letters.php?edit=<?php echo $log['id']; ?>" class="btn btn-sm btn-outline-secondary py-0 px-2" style="font-size:0.75rem;" title="Edit / correct"><i class="fa-solid fa-pen"></i></a>
                                            <?php if ($st !== 'Approved'): ?>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('Delete this letter?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="delete_letter"><input type="hidden" name="letter_id" value="<?php echo $log['id']; ?>">
                                                <button class="btn btn-sm btn-outline-danger py-0 px-2" style="font-size:0.75rem;"><i class="fa-solid fa-trash-can"></i></button>
                                            </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No letters generated in historical logs yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    const templates = {
        "Employment Letter": {
            "title": "Letter of Employment Appointment",
            "body": "Dear {{full_name}},\n\nWe are pleased to offer you formal employment with UMZA Aviation Services Ltd in the position of {{position}} inside the {{department}} Department.\n\nYour employment will commence on {{employment_date}} and your initial base salary and allowances will be detailed in the attached schedule.\n\nYou will report to the department supervisor at the Lagos airport operations command center.\n\nWelcome to our team.\n\nYours faithfully,"
        },
        "Confirmation Letter": {
            "title": "Letter of Service Confirmation",
            "body": "Dear {{full_name}},\n\nFollowing the successful completion of your 6-month probationary service period at UMZA Aviation Services Ltd, we are pleased to confirm your permanent appointment as {{position}} inside the {{department}} Department effective from {{date}}.\n\nAll other terms and regulations of your employment contract remain active.\n\nYours faithfully,"
        },
        "Promotion Letter": {
            "title": "Letter of Operational Promotion",
            "body": "Dear {{full_name}},\n\nIn recognition of your exceptional flight crew safety records, operational discipline, and contributions to UMZA Aviation Services Ltd, we are pleased to promote you to your new position.\n\nYour salary grading and operational allowances have been adjusted accordingly effective from {{date}}.\n\nCongratulations on this well-deserved advancement.\n\nYours faithfully,"
        },
        "Query Letter": {
            "title": "Formal Disciplinary Query",
            "body": "Dear {{full_name}},\n\nIt has been reported to the HR department that you were involved in an operational irregularity or violation of airline procedures.\n\nYou are hereby queried to explain in writing within 48 hours why disciplinary action should not be taken against you.\n\nSubmit your defense reply via the staff query center.\n\nYours faithfully,"
        },
        "Warning Letter": {
            "title": "Formal Warning Query",
            "body": "Dear {{full_name}},\n\nFollowing review of your response to the disciplinary query and operational details, this letter serves as a formal warning regarding compliance with standard operating manuals of UMZA Aviation Services Ltd.\n\nFurther infractions will result in suspension or termination of your airport access cards and crew clearance.\n\nYours faithfully,"
        },
        "Leave Approval Letter": {
            "title": "Leave Authorization Clearance",
            "body": "Dear {{full_name}},\n\nYour request for official leave has been approved.\n\nYou are authorized to depart from flight roster duties for your approved leave segment. You are expected to return to duty on date scheduled.\n\nYours faithfully,"
        },
        "Salary Letter": {
            "title": "Salary Status Verification",
            "body": "To Whom It May Concern,\n\nThis letter confirms that {{full_name}} is an active employee at UMZA Aviation Services Ltd in the position of {{position}}.\n\nTheir current net monthly salary is [Insert salary figure] Naira, and they have been with the company since {{employment_date}}.\n\nThis letter is generated upon request for verification purposes.\n\nYours faithfully,"
        },
        "Experience Letter": {
            "title": "Certificate of Flight Experience",
            "body": "To Whom It May Concern,\n\nThis certifies that {{full_name}} has served as {{position}} inside the {{department}} Department at UMZA Aviation Services Ltd from {{employment_date}} to {{date}}.\n\nDuring their tenure, they maintained a high standard of professional flight crew coordination and safety compliance.\n\nWe wish them success in their future aviation endeavors.\n\nYours faithfully,"
        }
    };

    function injectTemplate() {
        const type = document.getElementById('letter_type').value;
        const titleInput = document.getElementById('title');
        const contentArea = document.getElementById('content');
        
        if (type && templates[type]) {
            if (contentArea.value.trim() !== '' && !confirm('Replace the current text with the ' + type + ' template?')) return;
            titleInput.value = templates[type].title;
            contentArea.value = templates[type].body;
        }
    }
</script>

<script>
    // Pre-fill the name / details line from the chosen staff (HR can still correct them)
    (function () {
        const pick = document.getElementById('staffPick');
        if (!pick) return;
        pick.addEventListener('change', function () {
            const o = pick.options[pick.selectedIndex];
            const n = document.getElementById('recipientName'), d = document.getElementById('recipientDetails');
            if (o && o.dataset.name) { n.value = o.dataset.name; d.value = o.dataset.details || ''; }
        });
    })();
</script>

<?php require_once '../includes/footer.php'; ?>
