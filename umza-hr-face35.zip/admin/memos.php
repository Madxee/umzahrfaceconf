<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Internal Memo & Circular Broadcast System
 */

require_once '../includes/auth.php';
require_feature('memos');
require_once '../includes/mail.php';
require_once '../includes/memos_lib.php';

// HR roles publish to everyone or a department; Heads of Department publish to their own department
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Department Head']);

$user_id = $_SESSION['user_id'];
$is_hod = ($_SESSION['role'] === 'Department Head');
$my_dept_id = get_user_department_id();
$all_departments = $pdo->query("SELECT `id`, `name` FROM `departments` ORDER BY `name`")->fetchAll();
$dept_names = array_column($all_departments, 'name', 'id');
$memo_types = ['Internal Memo', 'Circular', 'Announcement', 'Policy Update', 'Company News', 'Department Notice'];

$message = '';
$error = '';

// Handle creating a new memo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'publish_memo') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $type = in_array($_POST['type'] ?? '', $memo_types, true) ? $_POST['type'] : '';
    $content = trim($_POST['content'] ?? '');
    $audience = ($_POST['audience'] ?? 'All') === 'Department' ? 'Department' : 'All';
    $target_dept = intval($_POST['department_id'] ?? 0);
    if ($is_hod) {
        // A Head of Department can only write to their own department
        $audience = 'Department';
        $target_dept = $my_dept_id;
    }
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF validation failed.";
    } elseif (isset($_SESSION['processed_csrf']) && $_SESSION['processed_csrf'] === $csrf_token) {
        header("Location: memos.php?success=" . urlencode("Memo already published."));
        exit;
    } elseif (empty($title) || empty($type) || empty($content)) {
        $error = "Please fill in all memo fields.";
    } elseif ($audience === 'Department' && !isset($dept_names[$target_dept])) {
        $error = $is_hod ? "Your profile has no department. Ask HR to set your department first." : "Please choose the department that should receive this memo.";
    } else {
        // Mark CSRF immediately to prevent concurrent duplicate submissions
        $_SESSION['processed_csrf'] = $csrf_token;
        
        try {
            // Handle optional PDF/Image attachment
            $pdf_path = '';
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $file_tmp = $_FILES['attachment']['tmp_name'];
                $file_name = $_FILES['attachment']['name'];
                $file_size = $_FILES['attachment']['size'];
                
                $file_mime = get_file_mime($file_tmp, $_FILES['attachment']['type'] ?? '');
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                $allowed_exts = ['pdf', 'jpg', 'jpeg', 'png', 'webp'];
                
                if ($file_size > UPLOAD_MAX_SIZE) {
                    $error = "Attachment size exceeds 5MB limit.";
                } elseif (!in_array($file_ext, $allowed_exts, true) || ($file_mime !== 'application/pdf' && !str_starts_with($file_mime, 'image/'))) {
                    $error = "Only PDF documents and image files are allowed for attachments.";
                } else {
                    $new_filename = 'memo_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                    $upload_dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . 'documents';
                    if (!is_dir($upload_dir)) {
                        @mkdir($upload_dir, 0777, true);
                    }
                    
                    $dest_path = $upload_dir . DIRECTORY_SEPARATOR . $new_filename;
                    
                    $uploaded = false;
                    if (move_uploaded_file($file_tmp, $dest_path)) {
                        $uploaded = true;
                    } else if (copy($file_tmp, $dest_path)) {
                        $uploaded = true;
                    } else if (file_put_contents($dest_path, file_get_contents($file_tmp)) !== false) {
                        $uploaded = true;
                    }
                    
                    if ($uploaded) {
                        $pdf_path = 'uploads/documents/' . $new_filename;
                    } else {
                        $error = "Failed to upload attachment file.";
                    }
                }
            }

            if (empty($error)) {
                // Insert Memo (HR may send it to the MD first)
                $needs_md = !$is_hod && !is_md() && !empty($_POST['needs_md']);
                $status = $needs_md ? 'Pending MD' : 'Published';
                $insert = $pdo->prepare("INSERT INTO `memos` (`title`, `type`, `content`, `file_path`, `created_by`, `audience`, `department_id`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $insert->execute([$title, $type, $content, $pdf_path, $user_id, $audience, $audience === 'Department' ? $target_dept : null, $status]);
                $memo_id = $pdo->lastInsertId();

                $audience_label = $audience === 'Department' ? dept_title($target_dept) : 'all staff';
                if ($needs_md) {
                    log_activity($user_id, 'MEMO_SENT_TO_MD', "Memo ID $memo_id: $title sent to MD for approval");
                    $n = notify_md_pending('Memo', $title, $_SESSION['name']);
                    $message = "Memo sent to the Managing Director for approval. It will be emailed to $audience_label as soon as it is approved." . ($n ? '' : ' Note: no active Managing Director account exists yet.');
                } else {
                    log_activity($user_id, 'MEMO_PUBLISHED', "Published memo ID $memo_id: $title ($type) to $audience_label");
                    $memo_row = ['id' => $memo_id, 'title' => $title, 'type' => $type, 'content' => $content, 'file_path' => $pdf_path, 'audience' => $audience, 'department_id' => $target_dept];
                    $sent = distribute_memo($memo_row, $_SESSION['name']);
                    $mail_err = mail_last_error();
                    $message = "Memo published to $audience_label. Email notification sent to $sent staff and in-app alerts delivered.";
                    if ($mail_err) {
                        $message .= " Note: some emails could not be sent (" . $mail_err . "). Check System Settings > Email Log.";
                    }
                }
            }
        } catch (PDOException $e) {
            $error = "Failed to publish memo: " . $e->getMessage();
            unset($_SESSION['processed_csrf']); // Allow retry on failure
        }
    }
    
    // Redirect to clear resubmissions
    if (empty($error)) {
        header("Location: memos.php?success=" . urlencode($message));
    } else {
        header("Location: memos.php?error=" . urlencode($error));
    }
    exit;
}

// Re-send the email notification for a memo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'resend_memo') {
    $memo_id = intval($_POST['memo_id'] ?? 0);
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        header("Location: memos.php?error=" . urlencode("CSRF validation failed."));
        exit;
    }
    $stmt = $pdo->prepare("SELECT * FROM `memos` WHERE `id` = ?");
    $stmt->execute([$memo_id]);
    $memo = $stmt->fetch();
    if (!$memo || ($is_hod && (int)$memo['created_by'] !== (int)$user_id) || ($memo['status'] ?? 'Published') !== 'Published') {
        header("Location: memos.php?error=" . urlencode("Memo not found or not yet approved."));
        exit;
    }
    $sent = distribute_memo($memo, $_SESSION['name']);
    $err = mail_last_error();
    log_activity($user_id, 'MEMO_EMAIL_RESENT', "Re-sent memo ID $memo_id email to $sent staff");
    header("Location: memos.php?" . ($err ? "error=" . urlencode("Re-send attempted for $sent staff, but some emails failed: $err") : "success=" . urlencode("Email notification re-sent to $sent staff.")));
    exit;
}

// Handle deleting a memo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_memo') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $memo_id = intval($_POST['memo_id'] ?? 0);
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF validation failed.";
    } else {
        try {
            // Fetch file path to delete from disk
            $stmt = $pdo->prepare("SELECT `file_path`, `created_by` FROM `memos` WHERE `id` = ?");
            $stmt->execute([$memo_id]);
            $memo = $stmt->fetch();
            if ($memo && $is_hod && (int)$memo['created_by'] !== (int)$user_id) {
                $memo = false; // Heads may only delete their own memos
            }
            
            if ($memo) {
                if (!empty($memo['file_path'])) {
                    $full_file_path = BASE_PATH . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $memo['file_path']);
                    if (file_exists($full_file_path)) {
                        @unlink($full_file_path);
                    }
                }
                
                $delete = $pdo->prepare("DELETE FROM `memos` WHERE `id` = ?");
                $delete->execute([$memo_id]);
                
                log_activity($user_id, 'MEMO_DELETED', "Deleted memo ID $memo_id");
                $message = "Memo deleted successfully.";
            } else {
                $error = "Memo not found.";
            }
        } catch (PDOException $e) {
            $error = "Failed to delete memo: " . $e->getMessage();
        }
    }
    
    header("Location: memos.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error)));
    exit;
}

// Fetch published memos
try {
    if ($is_hod) {
        $stmt = $pdo->prepare("SELECT m.*, s.first_name, s.last_name, s.display_name, s.role 
                              FROM `memos` m LEFT JOIN `staff` s ON m.created_by = s.id 
                              WHERE m.created_by = ? OR (m.status = 'Published' AND (m.audience = 'All' OR m.department_id = ?))
                              ORDER BY m.id DESC");
        $stmt->execute([$user_id, $my_dept_id]);
        $memos = $stmt->fetchAll();
    } else {
        $memos = $pdo->query("SELECT m.*, s.first_name, s.last_name, s.display_name, s.role 
                              FROM `memos` m LEFT JOIN `staff` s ON m.created_by = s.id 
                              ORDER BY m.id DESC")->fetchAll();
    }
} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-bullhorn me-2"></i>Memos & Circulars</h2>
        <p class="text-muted"><?php echo $is_hod ? 'Send memos to staff in your department. Each memo is emailed to them and shown in their portal.' : 'Broadcast memos to all staff or to one department. Every memo is emailed and shown in-app.'; ?></p>
    </div>
    <div class="col-md-6 text-md-end">
        <button class="btn btn-aviation" data-bs-toggle="modal" data-bs-target="#newMemoModal">
            <i class="fa-solid fa-square-plus me-1"></i>Publish New Memo
        </button>
    </div>
</div>

<!-- Modal for New Memo -->
<div class="modal fade" id="newMemoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-aviation text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-bullhorn me-2"></i><?php echo $is_hod ? 'New Department Memo' : 'Create New Company Broadcast'; ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="memos.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="publish_memo">
                <div class="modal-body text-start">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="title">Memo Title / Subject *</label>
                            <input type="text" class="form-control" id="title" name="title" placeholder="e.g. Flight Schedule Adjustment / Holiday Notice" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="type">Memo Category *</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="">Select Category</option>
                                <?php foreach ($memo_types as $t): ?>
                                    <option value="<?php echo $t; ?>" <?php echo ($is_hod && $t === 'Department Notice') ? 'selected' : ''; ?>><?php echo $t; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <?php if ($is_hod): ?>
                            <div class="col-12">
                                <div class="alert alert-info py-2 mb-0 small"><i class="fa-solid fa-users me-1"></i>This memo will be sent to all staff in <strong><?php echo htmlspecialchars(get_department_label($my_dept_id)); ?></strong> by email and in-app notification.</div>
                            </div>
                        <?php else: ?>
                            <div class="col-md-6">
                                <label class="form-label fw-bold" for="audience">Send To *</label>
                                <select class="form-select" id="audience" name="audience" onchange="document.getElementById('deptPick').classList.toggle('d-none', this.value !== 'Department')">
                                    <option value="All">All active staff</option>
                                    <option value="Department">One department</option>
                                </select>
                            </div>
                            <div class="col-md-6 d-none" id="deptPick">
                                <label class="form-label fw-bold" for="department_id">Department</label>
                                <select class="form-select" id="department_id" name="department_id">
                                    <?php foreach ($all_departments as $d): ?>
                                        <option value="<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" for="content">Memo Content / Description *</label>
                        <textarea class="form-control" id="content" name="content" rows="6" placeholder="Write details here..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" for="attachment">Attachment Circular (PDF or Image, Max 5MB)</label>
                        <input type="file" class="form-control" id="attachment" name="attachment" accept=".pdf,.png,.jpg,.jpeg,.webp">
                        <div class="form-text" style="font-size:0.75rem;">Allows employees to download an official signed PDF document or view an attached image.</div>
                    </div>
                    <?php if (!$is_hod && !is_md()): ?>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="needs_md" value="1" id="needsMd">
                        <label class="form-check-label" for="needsMd"><strong>Send to the Managing Director for approval first</strong>
                            <div class="small text-muted">Staff receive it only after the MD approves it.</div></label>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-aviation btn-sm"><i class="fa-solid fa-share-from-square me-1"></i>Publish & Broadcast</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Memos List Grid -->
<div class="row">
    <div class="col-12">
        <?php if (count($memos) > 0): ?>
            <?php foreach ($memos as $m): ?>
                <div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-header bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-aviation text-white p-2 mb-1" style="font-size:0.7rem;"><?php echo htmlspecialchars($m['type']); ?></span>
                            <span class="badge bg-light text-dark border p-2 mb-1" style="font-size:0.7rem;"><i class="fa-solid fa-users me-1"></i><?php echo ($m['audience'] ?? 'All') === 'Department' ? htmlspecialchars(get_department_label($m['department_id'])) . ' Dept' : 'All Staff'; ?></span>
                            <?php $mst = $m['status'] ?? 'Published'; if ($mst !== 'Published'): ?>
                                <span class="badge <?php echo $mst === 'Pending MD' ? 'bg-warning text-dark' : 'bg-danger'; ?> p-2 mb-1" style="font-size:0.7rem;"><?php echo $mst === 'Rejected' ? 'Returned by MD' : 'Awaiting MD approval'; ?></span>
                                <?php if (!empty($m['md_comment'])): ?><div class="small text-danger">MD: <?php echo htmlspecialchars($m['md_comment']); ?></div><?php endif; ?>
                            <?php endif; ?>
                            <span class="badge bg-light text-secondary border p-2 mb-1" style="font-size:0.7rem;" title="Email notifications"><i class="fa-solid fa-envelope me-1"></i><?php echo (int)($m['emails_sent'] ?? 0); ?></span>
                            <h5 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars($m['title']); ?></h5>
                        </div>
                        <div class="text-end d-flex align-items-center gap-3">
                            <div>
                                <small class="text-secondary d-block"><?php echo format_datetime($m['created_at']); ?></small>
                                <small class="text-muted italic">By: <?php echo htmlspecialchars(display_name($m)); ?></small>
                            </div>
                            <?php if (!$is_hod || (int)$m['created_by'] === (int)$user_id): ?>
                            <form method="POST" action="memos.php" onsubmit="return confirm('Send the email notification for this memo again?');">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="resend_memo">
                                <input type="hidden" name="memo_id" value="<?php echo $m['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-aviation" title="Re-send email"><i class="fa-solid fa-paper-plane"></i></button>
                            </form>
                            <form method="POST" action="memos.php" onsubmit="return confirm('Are you sure you want to delete this memo? This action cannot be undone.');">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="delete_memo">
                                <input type="hidden" name="memo_id" value="<?php echo $m['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Memo">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <div class="row">
                            <div class="col-md-9 border-end">
                                <div class="text-dark" style="white-space: pre-wrap; font-size:0.9rem;">
                                    <?php echo htmlspecialchars($m['content']); ?>
                                </div>
                            </div>
                            <div class="col-md-3 ps-md-4 mt-3 mt-md-0 d-flex flex-column justify-content-between align-items-start">
                                <div>
                                    <h6 class="fw-bold text-aviation border-bottom pb-2 w-100"><i class="fa-solid fa-paperclip me-1"></i>Downloads</h6>
                                    <a href="<?php echo get_base_url(); ?>/staff/print-memo.php?id=<?php echo $m['id']; ?>" target="_blank" class="btn btn-sm btn-outline-dark w-100 mb-2"><i class="fa-solid fa-file-signature me-1"></i>Official Copy (Letterhead)</a>

                                     <?php if (!empty($m['file_path'])): ?>
                                         <?php 
                                         $ext = strtolower(pathinfo($m['file_path'], PATHINFO_EXTENSION));
                                         $file_name = basename($m['file_path']);
                                         ?>
                                         <div class="d-flex flex-column gap-2 w-100">
                                             <a href="<?php echo get_base_url() . '/' . $m['file_path']; ?>" target="_blank" class="btn btn-sm btn-outline-aviation w-100">
                                                 <i class="fa-solid fa-eye me-1"></i>View Inline
                                             </a>
                                             <a href="<?php echo get_base_url() . '/' . $m['file_path']; ?>" download="<?php echo htmlspecialchars($file_name); ?>" class="btn btn-sm btn-aviation w-100">
                                                 <i class="fa-solid fa-download me-1"></i>Download File
                                             </a>
                                         </div>
                                     <?php else: ?>
                                         <p class="text-muted small">No circular attachments.</p>
                                     <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card shadow-sm border-0 bg-white p-5 text-center" style="border-radius: 12px;">
                <i class="fa-solid fa-bullhorn fa-4x text-success mb-3"></i>
                <h4 class="fw-bold text-aviation">No Memos Published</h4>
                <p class="text-muted mb-0">No company-wide memos or policy updates have been issued yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
