<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Directory & HR Actions
 */

require_once '../includes/auth.php';
require_once '../includes/mail.php';

// Force HR Admin roles
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Finance Officer', 'Department Head']);

// 1. HANDLE RECORD EXPORT (CSV)
if (isset($_GET['export']) && $_GET['export'] === 'csv' && (is_hr_role() || $_SESSION['role'] === 'Finance Officer')) {
    // Clear buffer
    ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=umza_staff_records_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    
    // Header Row
    fputcsv($output, ['Staff ID', 'First Name', 'Other Name', 'Last Name', 'Display Name', 'Gender', 'Date of Birth', 'Email', 'Phone', 'Address', 'Department', 'Position', 'Role', 'Status', 'Employment Date']);
    
    // Fetch data
    $query = "SELECT s.staff_id, s.first_name, s.last_name, s.display_name, s.gender, s.dob, s.email, s.phone, s.address, d.name as department, p.title as position, s.role, s.status, s.employment_date 
              FROM staff s 
              LEFT JOIN departments d ON s.department_id = d.id 
              LEFT JOIN positions p ON s.position_id = p.id 
              ORDER BY s.id ASC";
    $stmt = $pdo->query($query);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

// 2. HANDLE HR ACTIONS (APPROVE / SUSPEND / REACTIVATE / DELETE)
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $target_id = intval($_POST['target_id'] ?? 0);
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "Security verification failed.";
    } elseif (!is_hr_role()) {
        $error = "Only HR can approve, suspend or reject staff accounts.";
    } elseif ($target_id <= 0) {
        $error = "Invalid target employee selected.";
    } else {
        // Fetch target staff details
        $stmt = $pdo->prepare("SELECT * FROM `staff` WHERE `id` = ?");
        $stmt->execute([$target_id]);
        $target_staff = $stmt->fetch();
        
        if (!$target_staff) {
            $error = "Employee not found.";
        } elseif ($target_staff['role'] === 'Super Admin' && $_SESSION['role'] !== 'Super Admin' && in_array($action, ['suspend', 'reject'], true)) {
            $error = "Only a Super Admin can change another Super Admin's account.";
        } else {
            $target_name = display_name($target_staff);
            
            if ($action === 'resend_verification') {
                if ((int)$target_staff['email_verified'] === 1) {
                    $error = "$target_name's email is already verified.";
                } else {
                    $token = $target_staff['verification_token'] ?: bin2hex(random_bytes(32));
                    $pdo->prepare("UPDATE `staff` SET `verification_token` = ? WHERE `id` = ?")->execute([$token, $target_id]);
                    if (send_verification_email($target_staff['email'], $target_name, $token)) {
                        log_activity($_SESSION['user_id'], 'VERIFICATION_RESENT', "Re-sent verification email to $target_name");
                        $message = "Verification email sent to " . $target_staff['email'] . ".";
                    } else {
                        $error = "Could not send the verification email: " . mail_last_error() . " (check System Settings > Email).";
                    }
                }
            }
            elseif ($action === 'mark_verified') {
                $pdo->prepare("UPDATE `staff` SET `email_verified` = 1, `verification_token` = NULL WHERE `id` = ?")->execute([$target_id]);
                log_activity($_SESSION['user_id'], 'EMAIL_VERIFIED_BY_HR', "HR manually verified email for $target_name");
                $message = "$target_name's email marked as verified.";
            }
            elseif ($action === 'approve') {
                // Change status to Active and mark email as verified
                $update = $pdo->prepare("UPDATE `staff` SET `status` = 'Active', `email_verified` = 1 WHERE `id` = ?");
                $update->execute([$target_id]);
                
                // Add default staff ID details in `staff_ids` table
                $verify_token = bin2hex(random_bytes(16));
                $issue_date = date('Y-m-d');
                $validity_years = intval(get_setting('id_card_validity_years', 3));
                $expiry_date = date('Y-m-d', strtotime("+$validity_years years"));
                
                $id_stmt = $pdo->prepare("INSERT INTO `staff_ids` (`staff_id`, `verification_token`, `issue_date`, `expiry_date`, `status`) 
                                          VALUES (?, ?, ?, ?, 'Active') 
                                          ON DUPLICATE KEY UPDATE `status` = 'Active'");
                $id_stmt->execute([$target_id, $verify_token, $issue_date, $expiry_date]);
                
                // Log activity
                log_activity($_SESSION['user_id'], 'STAFF_APPROVED', "Approved registration for: $target_name ($target_staff[staff_id])");
                log_activity($target_id, 'ACCOUNT_ACTIVATED', "Account activated by HR Manager");
                
                // Send Email Notification
                $subject = "Registration Approved - UMZA Aviation Services Ltd";
                $body = "
                    <p>Congratulations! Your registration on the UMZA Aviation Services Ltd HR Portal has been approved by the HR department.</p>
                    <p>Your account is now fully active. You can log in and access your portal dashboard:</p>
                    <p><a href='" . get_base_url() . "/index.php' class='btn'>Login to Portal</a></p>
                    <p>If you have any questions, please contact the IT or HR department.</p>";
                $mailed = send_email($target_staff['email'], $target_name, $subject, $body);
                
                $message = "Successfully approved registration for $target_name." . ($mailed ? " Approval email sent." : " (Approval email could not be sent - check System Settings > Email.)");
            } 
            elseif ($action === 'suspend') {
                if ($target_staff['role'] === 'Super Admin' && $_SESSION['role'] !== 'Super Admin') {
                    $error = "You do not have permission to suspend a Super Admin.";
                } else {
                    $update = $pdo->prepare("UPDATE `staff` SET `status` = 'Suspended' WHERE `id` = ?");
                    $update->execute([$target_id]);
                    
                    // Suspend ID Card too
                    $pdo->prepare("UPDATE `staff_ids` SET `status` = 'Suspended' WHERE `staff_id` = ?")->execute([$target_id]);
                    
                    log_activity($_SESSION['user_id'], 'STAFF_SUSPENDED', "Suspended account: $target_name ($target_staff[staff_id])");
                    log_activity($target_id, 'ACCOUNT_SUSPENDED', "Account suspended by HR Manager");
                    
                    $subject = "Account Suspended - UMZA Aviation Services Ltd";
                    $body = "
                        <p>Please be informed that your account on the UMZA Aviation Services Ltd HR Portal has been suspended by the HR department.</p>
                        <p>As a result, you will not be able to log in or access company resources through the portal.</p>
                        <p>If you believe this is an error or need clarification, please contact your department head or HR director directly.</p>";
                    send_email($target_staff['email'], $target_name, $subject, $body);

                    $message = "Successfully suspended account for $target_name.";
                }
            } 
            elseif ($action === 'reactivate') {
                $update = $pdo->prepare("UPDATE `staff` SET `status` = 'Active' WHERE `id` = ?");
                $update->execute([$target_id]);
                
                // Reactivate ID Card
                $pdo->prepare("UPDATE `staff_ids` SET `status` = 'Active' WHERE `staff_id` = ?")->execute([$target_id]);
                
                log_activity($_SESSION['user_id'], 'STAFF_REACTIVATED', "Reactivated account: $target_name ($target_staff[staff_id])");
                log_activity($target_id, 'ACCOUNT_REACTIVATED', "Account reactivated by HR Manager");
                
                $subject = "Account Reactivated - UMZA Aviation Services Ltd";
                $body = "
                    <p>We are pleased to inform you that your account on the UMZA Aviation Services Ltd HR Portal has been reactivated.</p>
                    <p>You can now log in and access your portal dashboard:</p>
                    <p><a href='" . get_base_url() . "/index.php' class='btn'>Login to Portal</a></p>";
                send_email($target_staff['email'], $target_name, $subject, $body);

                $message = "Successfully reactivated account for $target_name.";
            }
            elseif ($action === 'reject') {
                // Remove photo if exists
                if (!empty($target_staff['passport_photo']) && file_exists(BASE_PATH . '/' . $target_staff['passport_photo'])) {
                    unlink(BASE_PATH . '/' . $target_staff['passport_photo']);
                }
                
                // Delete staff record
                $delete = $pdo->prepare("DELETE FROM `staff` WHERE `id` = ?");
                $delete->execute([$target_id]);
                
                log_activity($_SESSION['user_id'], 'STAFF_REJECTED', "Rejected and deleted registration for: $target_name ($target_staff[staff_id])");
                
                $subject = "Registration Rejected - UMZA Aviation Services Ltd";
                $body = "
                    <p>Thank you for your interest in registering on the UMZA Aviation Services Ltd HR Portal.</p>
                    <p>Unfortunately, your registration has been rejected by the HR department. Your profile and uploaded credentials have been removed from our system.</p>
                    <p>If you believe this is an error or if you need to submit correct information, please re-submit your registration with the correct details or contact HR.</p>";
                send_email($target_staff['email'], $target_name, $subject, $body);

                $message = "Rejected and deleted registration for $target_name.";
            }
        }
    }
    
    // Redirect to prevent form resubmission
    $redir_url = "staff.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// 3. RETRIEVE FILTER AND SEARCH VARIABLES
$search = trim($_GET['search'] ?? '');
$filter_dept = intval($_GET['dept'] ?? 0);
$filter_role = trim($_GET['role'] ?? '');
$filter_status = trim($_GET['status'] ?? '');

// Load Departments for select dropdown
$depts = $pdo->query("SELECT * FROM `departments` ORDER BY `name` ASC")->fetchAll();

// Build Query
$query_parts = [];
$params = [];

if ($search !== '') {
    $query_parts[] = "(s.first_name LIKE ? OR s.last_name LIKE ? OR s.other_name LIKE ? OR s.display_name LIKE ? OR s.staff_id LIKE ? OR s.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Restrict department head to their own department
if ($_SESSION['role'] === 'Department Head') {
    // Fetch dept ID of head
    $stmt = $pdo->prepare("SELECT `department_id` FROM `staff` WHERE `id` = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $filter_dept = intval($stmt->fetchColumn());
}

if ($filter_dept > 0) {
    $query_parts[] = "s.department_id = ?";
    $params[] = $filter_dept;
}

if ($filter_role !== '') {
    $query_parts[] = "s.role = ?";
    $params[] = $filter_role;
}

if ($filter_status !== '') {
    $query_parts[] = "s.status = ?";
    $params[] = $filter_status;
}

$where_clause = '';
if (count($query_parts) > 0) {
    $where_clause = "WHERE " . implode(" AND ", $query_parts);
}

$sql = "SELECT s.*, d.name as department, p.title as position 
        FROM `staff` s 
        LEFT JOIN `departments` d ON s.department_id = d.id 
        LEFT JOIN `positions` p ON s.position_id = p.id 
        $where_clause 
        ORDER BY s.status DESC, s.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$staff_list = $stmt->fetchAll();

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-users me-2"></i>Staff Directory</h2>
        <p class="text-muted">Manage employee records, approvals, and credentials.</p>
    </div>
    <div class="col-md-6 text-md-end d-flex align-items-center justify-content-md-end gap-2">
        <a href="add-staff.php" class="btn btn-success">
            <i class="fa-solid fa-user-plus me-2"></i>Add New Employee
        </a>
        <a href="staff.php?export=csv" class="btn btn-outline-aviation">
            <i class="fa-solid fa-file-csv me-2"></i>Export Staff Records
        </a>
    </div>
</div>

<!-- Search & Filters -->
<div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px;">
    <div class="card-body p-3">
        <form method="GET" action="staff.php" class="row g-2">
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text bg-light text-muted border-end-0"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" class="form-control border-start-0 bg-light" name="search" placeholder="Search by name, ID, or email..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>
            
            <?php if ($_SESSION['role'] !== 'Department Head'): ?>
            <div class="col-md-2">
                <select class="form-select bg-light" name="dept">
                    <option value="">All Departments</option>
                    <?php foreach ($depts as $d): ?>
                        <option value="<?php echo $d['id']; ?>" <?php echo $filter_dept == $d['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($d['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            
            <div class="col-md-2">
                <select class="form-select bg-light" name="role">
                    <option value="">All Roles</option>
                    <option value="Super Admin" <?php echo $filter_role === 'Super Admin' ? 'selected' : ''; ?>>Super Admin</option>
                    <option value="HR Manager" <?php echo $filter_role === 'HR Manager' ? 'selected' : ''; ?>>HR Manager</option>
                    <option value="HR Officer" <?php echo $filter_role === 'HR Officer' ? 'selected' : ''; ?>>HR Officer</option>
                    <option value="Department Head" <?php echo $filter_role === 'Department Head' ? 'selected' : ''; ?>>Department Head</option>
                    <option value="Staff" <?php echo $filter_role === 'Staff' ? 'selected' : ''; ?>>Staff</option>
                </select>
            </div>

            <div class="col-md-2">
                <select class="form-select bg-light" name="status">
                    <option value="">All Statuses</option>
                    <option value="Pending" <?php echo $filter_status === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="Active" <?php echo $filter_status === 'Active' ? 'selected' : ''; ?>>Active</option>
                    <option value="Suspended" <?php echo $filter_status === 'Suspended' ? 'selected' : ''; ?>>Suspended</option>
                </select>
            </div>

            <div class="col-md-2 d-grid">
                <button type="submit" class="btn btn-aviation"><i class="fa-solid fa-filter me-2"></i>Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Staff Table -->
<div class="table-responsive-custom">
    <table class="table table-custom align-middle mb-0">
        <thead>
            <tr>
                <th>Passport</th>
                <th>Employee Details</th>
                <th>Staff ID</th>
                <th>Department & Position</th>
                <th>Status</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($staff_list) > 0): ?>
                <?php foreach ($staff_list as $staff): ?>
                    <tr>
                        <td>
                            <img src="<?php echo photo_url($staff['passport_photo'] ?? ''); ?>" 
                                 class="rounded shadow-sm" 
                                 style="width: 50px; height: 60px; object-fit: cover;" 
                                 alt="Passport">
                        </td>
                        <td>
                            <h6 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars(display_name($staff)); ?></h6>
                            <small class="text-muted"><i class="fa-solid fa-envelope me-1"></i><?php echo htmlspecialchars($staff['email']); ?></small>
                        </td>
                        <td>
                            <code class="fw-bold text-dark"><?php echo htmlspecialchars($staff['staff_id']); ?></code>
                        </td>
                        <td>
                            <strong><?php echo htmlspecialchars($staff['department'] ?? 'No Dept'); ?></strong>
                            <br><small class="text-muted"><?php echo htmlspecialchars($staff['position'] ?? 'No Position'); ?></small>
                        </td>
                        <td>
                            <?php 
                            $status_class = 'badge-status-pending';
                            if ($staff['status'] === 'Active') $status_class = 'badge-status-active';
                            if ($staff['status'] === 'Suspended') $status_class = 'badge-status-suspended';
                            ?>
                            <span class="badge-status <?php echo $status_class; ?>"><?php echo $staff['status']; ?></span>
                            <?php if ($staff['email_verified'] == 1): ?>
                                <span class="badge bg-light text-success border border-success-subtle ms-1" style="font-size:0.65rem;"><i class="fa-solid fa-envelope-circle-check"></i> Verified</span>
                            <?php else: ?>
                                <span class="badge bg-light text-danger border border-danger-subtle ms-1" style="font-size:0.65rem;"><i class="fa-solid fa-envelope-open"></i> Unverified</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <div class="d-flex justify-content-end gap-1">
                                <?php if (!in_array($_SESSION['role'], ['Department Head', 'Managing Director'], true)): ?>
                                <a href="staff-profile.php?id=<?php echo $staff['id']; ?>" class="btn btn-sm btn-outline-aviation" title="View Profile">
                                    <i class="fa-solid fa-eye"></i> View Profile
                                </a>
                                <?php endif; ?>
                                
                                <?php if (is_hr_role()): ?>
                                    <?php if ((int)$staff['email_verified'] !== 1): ?>
                                        <form method="POST" action="staff.php" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="target_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="action" value="resend_verification">
                                            <button type="submit" class="btn btn-sm btn-outline-secondary" title="Resend verification email"><i class="fa-solid fa-paper-plane"></i></button>
                                        </form>
                                        <form method="POST" action="staff.php" class="d-inline" onsubmit="return confirm('Mark this email address as verified without the link?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="target_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="action" value="mark_verified">
                                            <button type="submit" class="btn btn-sm btn-outline-success" title="Mark email verified"><i class="fa-solid fa-envelope-circle-check"></i></button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($staff['status'] === 'Pending'): ?>
                                        <form method="POST" action="staff.php" class="d-inline" onsubmit="return confirm('Are you sure you want to APPROVE this registration?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="target_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" class="btn btn-sm btn-success"><i class="fa-solid fa-circle-check"></i> Approve</button>
                                        </form>
                                        <form method="POST" action="staff.php" class="d-inline" onsubmit="return confirm('Are you sure you want to REJECT and DELETE this registration?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="target_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fa-solid fa-circle-xmark"></i> Reject</button>
                                        </form>
                                    <?php elseif ($staff['status'] === 'Active' && $staff['role'] !== 'Super Admin'): ?>
                                        <form method="POST" action="staff.php" class="d-inline" onsubmit="return confirm('Are you sure you want to SUSPEND this employee\'s account?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="target_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="action" value="suspend">
                                            <button type="submit" class="btn btn-sm btn-warning text-white"><i class="fa-solid fa-user-slash"></i> Suspend</button>
                                        </form>
                                    <?php elseif ($staff['status'] === 'Suspended'): ?>
                                        <form method="POST" action="staff.php" class="d-inline" onsubmit="return confirm('Are you sure you want to REACTIVATE this account?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            <input type="hidden" name="target_id" value="<?php echo $staff['id']; ?>">
                                            <input type="hidden" name="action" value="reactivate">
                                            <button type="submit" class="btn btn-sm btn-success"><i class="fa-solid fa-user-check"></i> Reactivate</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center text-muted p-4">
                        <i class="fa-solid fa-users-slash fa-2x mb-2 text-secondary d-block"></i>
                        No employees found matching these filter criteria.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once '../includes/footer.php'; ?>
