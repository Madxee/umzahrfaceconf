<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Disciplinary Query Management
 */

require_once '../includes/auth.php';
require_feature('queries');
require_once '../includes/mail.php';

// Force HR Admin roles
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle issuing a new query
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'issue_query') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $staff_id_target = intval($_POST['staff_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $reason = trim($_POST['reason'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $deadline = $_POST['deadline'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF validation failed.";
    } elseif ($staff_id_target <= 0 || empty($title) || empty($reason) || empty($description) || empty($deadline)) {
        $error = "Please fill in all query details.";
    } else {
        try {
            // Check target staff
            $stmt = $pdo->prepare("SELECT * FROM `staff` WHERE `id` = ?");
            $stmt->execute([$staff_id_target]);
            $target_staff = $stmt->fetch();
            
            if (!$target_staff) {
                $error = "Employee not found.";
            } else {
                $staff_name = display_name($target_staff);
                
                // Insert query
                $insert = $pdo->prepare("INSERT INTO `queries` (`staff_id`, `title`, `reason`, `description`, `deadline`, `status`, `issued_by`) 
                                         VALUES (?, ?, ?, ?, ?, 'Issued', ?)");
                $insert->execute([$staff_id_target, $title, $reason, $description, $deadline, $user_id]);
                
                $query_id = $pdo->lastInsertId();
                
                // Add notification
                add_notification($staff_id_target, "Official Query Issued", "You have been issued an official query: $title. Reply deadline: $deadline.");
                
                log_activity($user_id, 'QUERY_ISSUED', "Issued disciplinary query ID $query_id to $staff_name. Reason: $reason");
                
                // Send Email Notification
                $subject = "URGENT: Formal Disciplinary Query Issued";
                $body = "
                    <p>Please be informed that you have been issued a formal disciplinary query from the HR department.</p>
                    <p><strong>Query details:</strong></p>
                    <ul>
                        <li><strong>Title:</strong> " . htmlspecialchars($title) . "</li>
                        <li><strong>Reason:</strong> " . htmlspecialchars($reason) . "</li>
                        <li><strong>Description:</strong> " . nl2br(htmlspecialchars($description)) . "</li>
                        <li><strong>Response Deadline:</strong> <span style='color:#e53e3e; font-weight:bold;'>" . format_date($deadline) . "</span></li>
                    </ul>
                    <p>You are required to log in to the Staff Portal and submit a formal response before the deadline.</p>
                    <p><a href='" . get_base_url() . "/staff/queries.php' class='btn'>View and Reply to Query</a></p>
                    <p>Failure to respond within the stipulated time may lead to further disciplinary actions.</p>";
                
                send_email($target_staff['email'], $staff_name, $subject, $body);
                
                $message = "Disciplinary query issued successfully and email sent to $staff_name.";
            }
        } catch (PDOException $e) {
            $error = "Failed to issue query: " . $e->getMessage();
        }
    }
    
    // Redirect to clear resubmissions
    $redir_url = "queries.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Handle query updates (Mark Resolved / Escalate)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && in_array($_POST['action'], ['resolve_query', 'escalate_query'])) {
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    $query_id = intval($_POST['query_id'] ?? 0);
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } elseif ($query_id <= 0) {
        $error = "Invalid query reference.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT q.*, s.first_name, s.last_name, s.display_name, s.email FROM `queries` q JOIN `staff` s ON q.staff_id = s.id WHERE q.id = ?");
            $stmt->execute([$query_id]);
            $query_row = $stmt->fetch();
            
            if (!$query_row) {
                $error = "Query record not found.";
            } else {
                $staff_name = display_name($query_row);
                $new_status = ($action === 'resolve_query') ? 'Resolved' : 'Escalated';
                
                $update = $pdo->prepare("UPDATE `queries` SET `status` = ? WHERE `id` = ?");
                $update->execute([$new_status, $query_id]);
                
                log_activity($user_id, 'QUERY_STATUS_UPDATED', "Marked query ID $query_id as $new_status for $staff_name");
                
                // Add notification
                add_notification($query_row['staff_id'], "Query Status Update", "Your query regarding '{$query_row['title']}' has been marked: $new_status.");
                
                // Send email
                $subject = "Update: Disciplinary Query status";
                $body = "
                    <p>This is to inform you that your response to the disciplinary query regarding <strong>{$query_row['title']}</strong> has been reviewed.</p>
                    <p>The query status is now marked as: <span style='font-weight:bold;'>" . strtoupper($new_status) . "</span></p>";
                
                send_email($query_row['email'], $staff_name, $subject, $body);
                
                $message = "Query status successfully updated to $new_status.";
            }
        } catch (PDOException $e) {
            $error = "Failed to update status: " . $e->getMessage();
        }
    }
    
    $redir_url = "queries.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch all queries and replies
try {
    $queries = $pdo->query("SELECT q.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, d.name as department 
                            FROM `queries` q 
                            JOIN `staff` s ON q.staff_id = s.id 
                            LEFT JOIN `departments` d ON s.department_id = d.id 
                            ORDER BY q.id DESC")->fetchAll();
    
    // Map replies by query ID
    $query_ids = array_column($queries, 'id');
    $replies_map = [];
    if (count($query_ids) > 0) {
        $placeholders = implode(',', array_fill(0, count($query_ids), '?'));
        $replies_stmt = $pdo->prepare("SELECT * FROM `query_replies` WHERE `query_id` IN ($placeholders) ORDER BY `id` ASC");
        $replies_stmt->execute($query_ids);
        $replies = $replies_stmt->fetchAll();
        
        foreach ($replies as $rep) {
            $replies_map[$rep['query_id']][] = $rep;
        }
    }
    
    // Load staff list for Query form dropdown
    $staff_list = $pdo->query("SELECT `id`, `first_name`, `last_name`, `display_name`, `staff_id` FROM `staff` WHERE `status` = 'Active' ORDER BY `first_name` ASC")->fetchAll();

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-file-shield me-2"></i>Disciplinary Query Center</h2>
        <p class="text-muted">Issue query notifications, review staff defenses, and manage status logs.</p>
    </div>
    <div class="col-md-6 text-md-end">
        <button class="btn btn-aviation" data-bs-toggle="modal" data-bs-target="#issueQueryModal">
            <i class="fa-solid fa-circle-exclamation me-1"></i>Issue New Query
        </button>
    </div>
</div>

<!-- Modal for New Query -->
<div class="modal fade" id="issueQueryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-triangle-exclamation me-2"></i>Issue Formal Disciplinary Query</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="queries.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="issue_query">
                <div class="modal-body text-start">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="staff_id">Target Employee *</label>
                            <select class="form-select" id="staff_id" name="staff_id" required>
                                <option value="">Select Employee</option>
                                <?php foreach ($staff_list as $st): ?>
                                    <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars(display_name($st)) . " (" . htmlspecialchars($st['staff_id']) . ")"; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold" for="deadline">Defense Deadline *</label>
                            <input type="date" class="form-control" id="deadline" name="deadline" min="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" for="title">Query Subject / Title *</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="e.g., Unexcused Absence from Flight Duty" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" for="reason">Primary Reason *</label>
                        <select class="form-select" id="reason" name="reason" required>
                            <option value="">Select Category</option>
                            <option value="Absent Without Leave (AWOL)">Absent Without Leave (AWOL)</option>
                            <option value="Late Coming / Unpunctuality">Late Coming / Unpunctuality</option>
                            <option value="Insubordination to Supervisors">Insubordination to Supervisors</option>
                            <option value="Negligence of Flight/Safety Duties">Negligence of Flight/Safety Duties</option>
                            <option value="Professional Misconduct / Ethics Breach">Professional Misconduct / Ethics Breach</option>
                            <option value="Other Breach of Conduct">Other Breach of Conduct</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold" for="description">Detailed Accusation Description *</label>
                        <textarea class="form-control" id="description" name="description" rows="5" placeholder="Provide complete facts, dates, and evidence regarding the infraction..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-paper-plane me-1"></i>Issue Query</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Queries List -->
<div class="row">
    <div class="col-12">
        <?php if (count($queries) > 0): ?>
            <?php foreach ($queries as $q): ?>
                <div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-header bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-danger text-white p-2 mb-1" style="font-size:0.7rem;"><?php echo htmlspecialchars($q['reason']); ?></span>
                            <h5 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars($q['title']); ?></h5>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-<?php echo $q['status'] === 'Resolved' ? 'success' : ($q['status'] === 'Replied' ? 'info' : ($q['status'] === 'Escalated' ? 'danger' : 'warning')); ?> p-2 fs-6">
                                <?php echo $q['status']; ?>
                            </span>
                            <small class="text-danger fw-bold d-block mt-1">Deadline: <?php echo format_date($q['deadline']); ?></small>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <div class="row">
                            <div class="col-md-8 border-end">
                                <p class="text-secondary small mb-2">Issued on <?php echo format_datetime($q['created_at']); ?> to:</p>
                                <h6><strong><?php echo htmlspecialchars(display_name($q)); ?></strong> (ID: <?php echo htmlspecialchars($q['staff_code']); ?> | <?php echo htmlspecialchars($q['department'] ?? 'Unassigned'); ?>)</h6>
                                
                                <div class="mt-3 p-3 bg-light rounded text-dark" style="white-space: pre-wrap; font-size:0.9rem;">
                                    <?php echo htmlspecialchars($q['description']); ?>
                                </div>
                                
                                <!-- Render Replies -->
                                <h6 class="fw-bold text-aviation mt-4 mb-2"><i class="fa-solid fa-reply me-1"></i>Employee Defense Response:</h6>
                                <?php if (isset($replies_map[$q['id']])): ?>
                                    <?php foreach ($replies_map[$q['id']] as $reply): ?>
                                        <div class="p-3 bg-light border border-info-subtle rounded mb-2 text-dark" style="font-size:0.9rem;">
                                            <small class="text-muted float-end"><?php echo format_datetime($reply['created_at']); ?></small>
                                            <p class="mb-2"><?php echo nl2br(htmlspecialchars($reply['reply_text'])); ?></p>
                                            <?php if (!empty($reply['file_path'])): ?>
                                                <a href="<?php echo get_base_url() . '/' . $reply['file_path']; ?>" target="_blank" class="text-decoration-none text-aviation small fw-bold">
                                                    <i class="fa-solid fa-paperclip me-1"></i>Attached Defense Document
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted small">Awaiting defense submission from employee.</p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Actions Column -->
                            <div class="col-md-4 ps-md-4 mt-3 mt-md-0 d-flex flex-column justify-content-end">
                                <?php if ($q['status'] !== 'Resolved'): ?>
                                    <form method="POST" action="queries.php" class="mb-2" onsubmit="return confirm('Mark this disciplinary query as RESOLVED?');">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="query_id" value="<?php echo $q['id']; ?>">
                                        <input type="hidden" name="action" value="resolve_query">
                                        <button type="submit" class="btn btn-success btn-sm w-100 py-2"><i class="fa-solid fa-check-circle me-1"></i>Mark Resolved</button>
                                    </form>
                                <?php endif; ?>
                                
                                <?php if ($q['status'] !== 'Escalated'): ?>
                                    <form method="POST" action="queries.php" onsubmit="return confirm('ESCALATE this query to a formal board review?');">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="query_id" value="<?php echo $q['id']; ?>">
                                        <input type="hidden" name="action" value="escalate_query">
                                        <button type="submit" class="btn btn-danger btn-sm w-100 py-2"><i class="fa-solid fa-circle-exclamation me-1"></i>Escalate Query</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card shadow-sm border-0 bg-white p-5 text-center" style="border-radius: 12px;">
                <i class="fa-solid fa-check-circle fa-4x text-success mb-3"></i>
                <h4 class="fw-bold text-aviation">No Disciplinary Queries Active</h4>
                <p class="text-muted mb-0">All corporate discipline files are in order.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
