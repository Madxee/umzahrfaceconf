<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Admin Panel - Grievances, Queries & Disciplinary Investigations
 */

require_once '../includes/auth.php';
require_feature('complaints');
require_login();
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer', 'Department Head']);

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle HR Response submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'respond_complaint') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $complaint_id = intval($_POST['complaint_id'] ?? 0);
    $hr_response = trim($_POST['hr_response'] ?? '');
    $status = $_POST['status'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } elseif ($complaint_id <= 0 || empty($hr_response) || empty($status)) {
        $error = "Please fill in all response details.";
    } else {
        try {
            // Fetch complaint detail
            $stmt = $pdo->prepare("SELECT c.*, s.first_name, s.last_name, s.display_name, s.email FROM `complaints` c JOIN `staff` s ON c.staff_id = s.id WHERE c.id = ?");
            $stmt->execute([$complaint_id]);
            $complaint = $stmt->fetch();
            
            if (!$complaint) {
                $error = "Complaint record not found.";
            } else {
                $staff_name = display_name($complaint);
                
                // Update complaint
                $update = $pdo->prepare("UPDATE `complaints` SET `status` = ?, `hr_response` = ? WHERE `id` = ?");
                $update->execute([$status, $hr_response, $complaint_id]);
                
                // Add notification
                add_notification($complaint['staff_id'], "Complaint Status Update", "Your complaint (Tracking: {$complaint['tracking_number']}) status is now: $status.");
                
                log_activity($user_id, 'COMPLAINT_RESPONDED', "Responded to complaint tracking ID {$complaint['tracking_number']}. Status updated to: $status.");
                
                // Send Email Notification
                $subject = "Complaint Update: Tracking #{$complaint['tracking_number']}";
                $body = "
                    <p>There has been an update regarding the complaint you submitted on the HR Portal.</p>
                    <ul>
                        <li><strong>Tracking Code:</strong> {$complaint['tracking_number']}</li>
                        <li><strong>Title:</strong> " . htmlspecialchars($complaint['title']) . "</li>
                        <li><strong>Current Status:</strong> <span style='font-weight:bold; color:#2d6a4f;'>$status</span></li>
                    </ul>
                    <p><strong>HR Admin Response:</strong><br>" . nl2br(htmlspecialchars($hr_response)) . "</p>
                    <p>You can track the progress of your grievance by logging in to the Staff Portal dashboard.</p>
                    <p><a href='" . get_base_url() . "/staff/complaints.php' class='btn'>View My Complaints</a></p>";
                
                send_email($complaint['email'], $staff_name, $subject, $body);
                
                $message = "Response submitted and employee notified via email.";
            }
        } catch (PDOException $e) {
            $error = "A database error occurred: " . $e->getMessage();
        }
    }
    
    // Redirect to prevent duplicate posting
    $redir_url = "complaints.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch complaints
$filter_status = trim($_GET['status'] ?? '');
$filter_type = trim($_GET['type'] ?? '');

$query_parts = [];
$params = [];

if ($filter_status !== '') {
    $query_parts[] = "c.status = ?";
    $params[] = $filter_status;
}

if ($filter_type !== '') {
    $query_parts[] = "c.type = ?";
    $params[] = $filter_type;
}

// Department Head restriction
if ($_SESSION['role'] === 'Department Head') {
    // Fetch dept ID of head
    $stmt = $pdo->prepare("SELECT `department_id` FROM `staff` WHERE `id` = ?");
    $stmt->execute([$user_id]);
    $dept_id = intval($stmt->fetchColumn());
    
    $query_parts[] = "s.department_id = ?";
    $params[] = $dept_id;
}

$where_clause = '';
if (count($query_parts) > 0) {
    $where_clause = "WHERE " . implode(" AND ", $query_parts);
}

try {
    $sql = "SELECT c.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, d.name as department 
            FROM `complaints` c 
            JOIN `staff` s ON c.staff_id = s.id 
            LEFT JOIN `departments` d ON s.department_id = d.id 
            $where_clause 
            ORDER BY c.id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $complaints = $stmt->fetchAll();

    // Map attachments by complaint ID
    $complaint_ids = array_column($complaints, 'id');
    $attachments_map = [];
    
    if (count($complaint_ids) > 0) {
        // Build placeholders for IN clause
        $placeholders = implode(',', array_fill(0, count($complaint_ids), '?'));
        $files_stmt = $pdo->prepare("SELECT * FROM `complaint_files` WHERE `complaint_id` IN ($placeholders)");
        $files_stmt->execute($complaint_ids);
        $files = $files_stmt->fetchAll();
        
        foreach ($files as $file) {
            $attachments_map[$file['complaint_id']][] = $file;
        }
    }

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-triangle-exclamation me-2"></i>Staff Complaints Panel</h2>
        <p class="text-muted">Review, investigate, and resolve workplace grievances and complaints.</p>
    </div>
</div>

<!-- Filters -->
<div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px;">
    <div class="card-body p-3">
        <form method="GET" action="complaints.php" class="row g-2">
            <div class="col-md-4">
                <select class="form-select bg-light" name="type">
                    <option value="">All Complaint Categories</option>
                    <option value="HR Complaint" <?php echo $filter_type === 'HR Complaint' ? 'selected' : ''; ?>>HR Complaint</option>
                    <option value="Management Complaint" <?php echo $filter_type === 'Management Complaint' ? 'selected' : ''; ?>>Management Complaint</option>
                    <option value="Payroll Complaint" <?php echo $filter_type === 'Payroll Complaint' ? 'selected' : ''; ?>>Payroll Complaint</option>
                    <option value="Workplace Complaint" <?php echo $filter_type === 'Workplace Complaint' ? 'selected' : ''; ?>>Workplace Complaint</option>
                    <option value="Other Complaint" <?php echo $filter_type === 'Other Complaint' ? 'selected' : ''; ?>>Other Complaint</option>
                </select>
            </div>
            
            <div class="col-md-4">
                <select class="form-select bg-light" name="status">
                    <option value="">All Statuses</option>
                    <option value="Pending" <?php echo $filter_status === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="Under Review" <?php echo $filter_status === 'Under Review' ? 'selected' : ''; ?>>Under Review</option>
                    <option value="Resolved" <?php echo $filter_status === 'Resolved' ? 'selected' : ''; ?>>Resolved</option>
                    <option value="Closed" <?php echo $filter_status === 'Closed' ? 'selected' : ''; ?>>Closed</option>
                </select>
            </div>

            <div class="col-md-4 d-grid">
                <button type="submit" class="btn btn-aviation"><i class="fa-solid fa-filter me-2"></i>Filter Complaints</button>
            </div>
        </form>
    </div>
</div>

<!-- Complaints Grid -->
<div class="row g-4">
    <div class="col-12">
        <?php if (count($complaints) > 0): ?>
            <?php foreach ($complaints as $c): ?>
                <div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-header bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-aviation text-white p-2 mb-1" style="font-size:0.7rem;"><?php echo htmlspecialchars($c['type']); ?></span>
                            <h5 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars($c['title']); ?></h5>
                        </div>
                        <div class="text-end">
                            <code class="fw-bold text-dark fs-6 d-block">ID: <?php echo htmlspecialchars($c['tracking_number']); ?></code>
                            <?php 
                            $status_class = 'badge-status-pending';
                            if ($c['status'] === 'Under Review') $status_class = 'badge-status-pending text-warning border-warning';
                            if ($c['status'] === 'Resolved') $status_class = 'badge-status-active';
                            if ($c['status'] === 'Closed') $status_class = 'badge-status-closed';
                            ?>
                            <span class="badge-status <?php echo $status_class; ?>"><?php echo $c['status']; ?></span>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <div class="row">
                            <div class="col-md-8 border-end">
                                <p class="text-secondary small mb-2">Submitted on <?php echo format_datetime($c['created_at']); ?> by:</p>
                                <h6><strong><?php echo htmlspecialchars(display_name($c)); ?></strong> (ID: <?php echo htmlspecialchars($c['staff_code']); ?> | <?php echo htmlspecialchars($c['department'] ?? 'Unassigned'); ?>)</h6>
                                
                                <div class="mt-3 p-3 bg-light rounded text-dark text-wrap" style="white-space: pre-wrap; font-size:0.9rem;">
                                    <?php echo htmlspecialchars($c['description']); ?>
                                </div>
                                
                                <?php if (!empty($c['hr_response'])): ?>
                                    <div class="mt-3 p-3 border border-success-subtle bg-success-subtle rounded text-dark" style="font-size:0.9rem;">
                                        <h6 class="fw-bold text-success mb-1"><i class="fa-solid fa-reply me-1"></i>HR Action Response:</h6>
                                        <p class="mb-0"><?php echo nl2br(htmlspecialchars($c['hr_response'])); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Attachments & Actions Column -->
                            <div class="col-md-4 ps-md-4 mt-3 mt-md-0 d-flex flex-direction-column justify-content-between flex-wrap">
                                <div>
                                    <h6 class="fw-bold text-aviation border-bottom pb-2 mb-2"><i class="fa-solid fa-paperclip me-1"></i>Attachments</h6>
                                     <?php if (isset($attachments_map[$c['id']])): ?>
                                         <div class="mb-4">
                                             <?php foreach ($attachments_map[$c['id']] as $file): ?>
                                                 <div class="d-flex align-items-center justify-content-between mb-2 p-2 bg-light rounded border">
                                                     <span class="small fw-semibold text-wrap text-aviation" style="max-width: 60%; word-break: break-all; font-size:0.75rem;">
                                                         <i class="fa-solid fa-file-lines me-1"></i>
                                                         <?php echo htmlspecialchars($file['file_name']); ?>
                                                     </span>
                                                     <div class="btn-group btn-group-sm">
                                                         <a href="<?php echo get_base_url() . '/' . $file['file_path']; ?>" target="_blank" class="btn btn-outline-aviation btn-sm" title="View Document">
                                                             <i class="fa-solid fa-eye"></i> View
                                                         </a>
                                                         <a href="<?php echo get_base_url() . '/' . $file['file_path']; ?>" download="<?php echo htmlspecialchars($file['file_name']); ?>" class="btn btn-aviation btn-sm" title="Download Document">
                                                             <i class="fa-solid fa-download"></i>
                                                         </a>
                                                     </div>
                                                 </div>
                                             <?php endforeach; ?>
                                         </div>
                                     <?php else: ?>
                                         <p class="text-muted small mb-4">No attachments uploaded.</p>
                                     <?php endif; ?>
                                </div>
                                
                                <div class="w-100 mt-auto">
                                    <button class="btn btn-aviation w-100 py-2 btn-sm" data-bs-toggle="modal" data-bs-target="#respondModal<?php echo $c['id']; ?>">
                                        <i class="fa-solid fa-pen-nib me-1"></i>Respond / Update Status
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- RESPONSE MODAL -->
                <div class="modal fade" id="respondModal<?php echo $c['id']; ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header bg-aviation text-white">
                                <h5 class="modal-title fw-bold">Update Complaint Action: <?php echo htmlspecialchars($c['tracking_number']); ?></h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form method="POST" action="complaints.php">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="complaint_id" value="<?php echo $c['id']; ?>">
                                <div class="modal-body text-start">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold" for="status<?php echo $c['id']; ?>">Complaint Status *</label>
                                        <select class="form-select" id="status<?php echo $c['id']; ?>" name="status" required>
                                            <option value="Pending" <?php echo $c['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Under Review" <?php echo $c['status'] === 'Under Review' ? 'selected' : ''; ?>>Under Review</option>
                                            <option value="Resolved" <?php echo $c['status'] === 'Resolved' ? 'selected' : ''; ?>>Resolved</option>
                                            <option value="Closed" <?php echo $c['status'] === 'Closed' ? 'selected' : ''; ?>>Closed</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold" for="response<?php echo $c['id']; ?>">Response / Resolution Action *</label>
                                        <textarea class="form-control" id="response<?php echo $c['id']; ?>" name="hr_response" rows="5" placeholder="Detail the action taken by HR to address or resolve this complaint..." required><?php echo htmlspecialchars($c['hr_response']); ?></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer bg-light">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" name="action" value="respond_complaint" class="btn btn-aviation btn-sm"><i class="fa-solid fa-paper-plane me-1"></i>Submit Response</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card shadow-sm border-0 bg-white p-5 text-center" style="border-radius: 12px;">
                <i class="fa-solid fa-circle-check fa-4x text-success mb-3"></i>
                <h4 class="fw-bold text-aviation">No Complaints Found</h4>
                <p class="text-muted mb-0">All staff complaints have been successfully closed or resolved.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
