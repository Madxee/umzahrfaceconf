<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Attendance Locations (GPS geofences): head office, airport stations and route offices
 */

require_once '../includes/auth.php';
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);
require_feature('attendance');

$user_id = $_SESSION['user_id'];
$types = ['Head Office', 'Airport Station', 'Route Office', 'Hangar / Maintenance', 'Training Centre', 'Other'];

function loc_back($ok, $msg, $id = 0) {
    header("Location: locations.php?" . ($ok ? 'success=' : 'error=') . urlencode($msg) . ($id ? "&edit=$id" : ''));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        loc_back(false, 'Security validation failed.');
    }
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);

    try {
        if ($action === 'save_location') {
            $name = trim($_POST['name'] ?? '');
            $type = in_array($_POST['type'] ?? '', $types, true) ? $_POST['type'] : 'Other';
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $city = trim($_POST['city'] ?? '');
            $lat = filter_var($_POST['latitude'] ?? '', FILTER_VALIDATE_FLOAT);
            $lng = filter_var($_POST['longitude'] ?? '', FILTER_VALIDATE_FLOAT);
            $radius = intval($_POST['radius_m'] ?? 0);
            $notes = trim($_POST['notes'] ?? '');
            $active = isset($_POST['is_active']) ? 1 : 0;

            if ($name === '') loc_back(false, 'Location name is required.', $id);
            if ($lat === false || $lng === false || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
                loc_back(false, 'Set a valid GPS point: click the map, use your current GPS, or type latitude and longitude.', $id);
            }
            if ($radius < 20 || $radius > 20000) loc_back(false, 'Radius must be between 20 and 20,000 metres.', $id);

            if ($id) {
                $pdo->prepare("UPDATE `attendance_locations` SET `name`=?, `type`=?, `code`=?, `city`=?, `latitude`=?, `longitude`=?, `radius_m`=?, `notes`=?, `is_active`=?, `verified`=1 WHERE `id`=?")
                    ->execute([$name, $type, $code ?: null, $city ?: null, $lat, $lng, $radius, $notes ?: null, $active, $id]);
                log_activity($user_id, 'LOCATION_UPDATED', "Updated attendance location: $name ($lat, $lng, {$radius}m)");
            } else {
                $pdo->prepare("INSERT INTO `attendance_locations` (`name`,`type`,`code`,`city`,`latitude`,`longitude`,`radius_m`,`notes`,`is_active`,`verified`) VALUES (?,?,?,?,?,?,?,?,?,1)")
                    ->execute([$name, $type, $code ?: null, $city ?: null, $lat, $lng, $radius, $notes ?: null, $active]);
                $id = (int)$pdo->lastInsertId();
                log_activity($user_id, 'LOCATION_CREATED', "Added attendance location: $name ($lat, $lng, {$radius}m)");
            }

            // Staff assigned to this location (none ticked = everyone may use every location)
            $pdo->prepare("DELETE FROM `staff_locations` WHERE `location_id` = ?")->execute([$id]);
            $ins = $pdo->prepare("INSERT IGNORE INTO `staff_locations` (`staff_id`, `location_id`) VALUES (?, ?)");
            foreach ((array)($_POST['staff_ids'] ?? []) as $sid) {
                if (intval($sid) > 0) $ins->execute([intval($sid), $id]);
            }
            loc_back(true, "Location \"$name\" saved.");
        }

        if ($action === 'toggle_location') {
            $pdo->prepare("UPDATE `attendance_locations` SET `is_active` = 1 - `is_active` WHERE `id` = ?")->execute([$id]);
            loc_back(true, 'Location updated.');
        }

        if ($action === 'delete_location') {
            $n = $pdo->prepare("SELECT `name` FROM `attendance_locations` WHERE `id` = ?");
            $n->execute([$id]);
            $name = $n->fetchColumn();
            $pdo->prepare("DELETE FROM `attendance_locations` WHERE `id` = ?")->execute([$id]);
            log_activity($user_id, 'LOCATION_DELETED', "Removed attendance location: $name");
            loc_back(true, "Location \"$name\" removed. Past attendance records are kept.");
        }
    } catch (PDOException $e) {
        loc_back(false, 'Database error: ' . $e->getMessage(), $id);
    }
    loc_back(false, 'Unknown action.');
}

$locations = $pdo->query("SELECT l.*,
        (SELECT COUNT(*) FROM staff_locations sl WHERE sl.location_id = l.id) AS staff_count,
        (SELECT COUNT(*) FROM attendance a WHERE a.clock_in_location_id = l.id AND a.date = CURDATE()) AS today_count
    FROM `attendance_locations` l ORDER BY (l.type = 'Head Office') DESC, l.name")->fetchAll();

$edit = null;
$edit_staff = [];
if (!empty($_GET['edit'])) {
    $st = $pdo->prepare("SELECT * FROM `attendance_locations` WHERE `id` = ?");
    $st->execute([intval($_GET['edit'])]);
    $edit = $st->fetch() ?: null;
    if ($edit) {
        $q = $pdo->prepare("SELECT `staff_id` FROM `staff_locations` WHERE `location_id` = ?");
        $q->execute([$edit['id']]);
        $edit_staff = array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN));
    }
}
$show_form = $edit || isset($_GET['new']);
$all_staff = $pdo->query("SELECT s.id, s.first_name, s.last_name, s.display_name, s.staff_id, d.name AS dept
                          FROM `staff` s LEFT JOIN `departments` d ON d.id = s.department_id
                          WHERE s.status = 'Active' ORDER BY d.name, s.first_name")->fetchAll();

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="<?php echo get_base_url(); ?>/libs/leaflet/leaflet.css">
<script src="<?php echo get_base_url(); ?>/libs/leaflet/leaflet.js"></script>

<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-location-dot me-2"></i>Attendance Locations (GPS)</h2>
        <p class="text-muted mb-0">Staff can only clock in when their phone or laptop GPS is inside one of these areas. Add the head office, every airport station and route office, and set a radius for each.</p>
    </div>
    <div class="col-md-4 text-md-end mt-3 mt-md-0">
        <a href="attendance.php" class="btn btn-outline-aviation me-1"><i class="fa-solid fa-user-clock me-1"></i>Attendance Hub</a>
        <a href="locations.php?new=1" class="btn btn-aviation"><i class="fa-solid fa-plus me-1"></i>Add Location</a>
    </div>
</div>

<?php if ($show_form): ?>
<div class="card shadow-sm border-0 mb-4" style="border-radius:12px;">
    <div class="card-header bg-aviation text-white fw-bold"><i class="fa-solid fa-map-pin me-2"></i><?php echo $edit ? 'Edit: ' . htmlspecialchars($edit['name']) : 'New Attendance Location'; ?></div>
    <div class="card-body">
        <form method="POST" action="locations.php" id="locForm">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <input type="hidden" name="action" value="save_location">
            <input type="hidden" name="id" value="<?php echo (int)($edit['id'] ?? 0); ?>">
            <div class="row g-3">
                <div class="col-lg-5">
                    <div class="mb-2">
                        <label class="form-label fw-bold">Name *</label>
                        <input class="form-control" name="name" required value="<?php echo htmlspecialchars($edit['name'] ?? ''); ?>" placeholder="e.g. Lagos Station - MMA2 Terminal">
                    </div>
                    <div class="row g-2 mb-2">
                        <div class="col-6">
                            <label class="form-label fw-bold">Type</label>
                            <select class="form-select" name="type">
                                <?php foreach ($types as $t): ?><option <?php echo ($edit['type'] ?? 'Airport Station') === $t ? 'selected' : ''; ?>><?php echo $t; ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <label class="form-label fw-bold">Code</label>
                            <input class="form-control" name="code" maxlength="10" value="<?php echo htmlspecialchars($edit['code'] ?? ''); ?>" placeholder="LOS">
                        </div>
                        <div class="col-3">
                            <label class="form-label fw-bold">City</label>
                            <input class="form-control" name="city" value="<?php echo htmlspecialchars($edit['city'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="row g-2 mb-2">
                        <div class="col-6">
                            <label class="form-label fw-bold">Latitude *</label>
                            <input class="form-control" name="latitude" id="lat" required value="<?php echo htmlspecialchars($edit['latitude'] ?? ''); ?>" placeholder="9.0330000">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold">Longitude *</label>
                            <input class="form-control" name="longitude" id="lng" required value="<?php echo htmlspecialchars($edit['longitude'] ?? ''); ?>" placeholder="7.4890000">
                        </div>
                    </div>
                    <button type="button" class="btn btn-outline-aviation w-100 mb-1" id="btnHere"><i class="fa-solid fa-location-crosshairs me-1"></i>Use my current GPS (stand at the location)</button>
                    <div class="small text-muted mb-2" id="hereMsg">Or click / drag the pin on the map.</div>
                    <label class="form-label fw-bold">Allowed radius: <span id="radiusVal"><?php echo (int)($edit['radius_m'] ?? 300); ?></span> m</label>
                    <input type="range" class="form-range" min="20" max="5000" step="10" name="radius_m" id="radius" value="<?php echo (int)($edit['radius_m'] ?? 300); ?>">
                    <div class="small text-muted mb-2">Office building: 50-200 m. Airport terminal / apron: 500-2,000 m.</div>
                    <div class="mb-2">
                        <label class="form-label fw-bold">Notes</label>
                        <input class="form-control" name="notes" value="<?php echo htmlspecialchars($edit['notes'] ?? ''); ?>">
                    </div>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="is_active" id="isActive" <?php echo ($edit['is_active'] ?? 1) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="isActive">Active (staff can clock in here)</label>
                    </div>
                    <div class="mb-2">
                        <label class="form-label fw-bold">Only these staff (optional)</label>
                        <select class="form-select" name="staff_ids[]" multiple size="7">
                            <?php $last_dept = null; foreach ($all_staff as $st):
                                if ($st['dept'] !== $last_dept) { if ($last_dept !== null) echo '</optgroup>'; echo '<optgroup label="' . htmlspecialchars($st['dept'] ?: 'No department') . '">'; $last_dept = $st['dept']; } ?>
                                <option value="<?php echo $st['id']; ?>" <?php echo in_array((int)$st['id'], $edit_staff, true) ? 'selected' : ''; ?>><?php echo htmlspecialchars(display_name($st) . ' (' . $st['staff_id'] . ')'); ?></option>
                            <?php endforeach; if ($last_dept !== null) echo '</optgroup>'; ?>
                        </select>
                        <div class="form-text">Hold Ctrl (or Cmd) to pick several. Staff who are assigned to one or more locations can clock in only at those. Staff with no assignment can clock in at any active location.</div>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-aviation flex-grow-1"><i class="fa-solid fa-floppy-disk me-1"></i>Save Location</button>
                        <a href="locations.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div id="editMap" style="height:520px;border-radius:10px;" class="border"></div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-xl-5">
        <div class="card shadow-sm border-0" style="border-radius:12px;">
            <div class="card-body p-0">
                <div id="overviewMap" style="height:560px;border-radius:12px;"></div>
            </div>
        </div>
    </div>
    <div class="col-xl-7">
        <div class="card shadow-sm border-0" style="border-radius:12px;">
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle" style="font-size:0.85rem;">
                    <thead class="table-light"><tr><th>Location</th><th>GPS</th><th>Radius</th><th>Staff</th><th>Today</th><th class="text-end">Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($locations as $l): ?>
                        <tr class="<?php echo $l['is_active'] ? '' : 'text-muted'; ?>">
                            <td>
                                <strong><?php echo htmlspecialchars($l['name']); ?></strong>
                                <?php if ($l['code']): ?><span class="badge bg-light text-dark border ms-1"><?php echo htmlspecialchars($l['code']); ?></span><?php endif; ?>
                                <div class="small text-muted"><?php echo htmlspecialchars($l['type'] . ($l['city'] ? ' · ' . $l['city'] : '')); ?></div>
                                <?php if (!$l['verified']): ?><span class="badge bg-warning text-dark" title="Default point - open Edit and confirm the exact position">Check position</span><?php endif; ?>
                                <?php if (!$l['is_active']): ?><span class="badge bg-secondary">Off</span><?php endif; ?>
                            </td>
                            <td class="small"><a href="https://www.google.com/maps?q=<?php echo $l['latitude'] . ',' . $l['longitude']; ?>" target="_blank" rel="noopener"><?php echo round($l['latitude'], 5) . ', ' . round($l['longitude'], 5); ?></a></td>
                            <td><?php echo number_format($l['radius_m']); ?> m</td>
                            <td><?php echo $l['staff_count'] ? (int)$l['staff_count'] . ' assigned' : '<span class="text-muted">All</span>'; ?></td>
                            <td><?php echo (int)$l['today_count']; ?></td>
                            <td class="text-end text-nowrap">
                                <a href="locations.php?edit=<?php echo $l['id']; ?>" class="btn btn-sm btn-outline-aviation" title="Edit"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" class="d-inline"><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="toggle_location"><input type="hidden" name="id" value="<?php echo $l['id']; ?>">
                                    <button class="btn btn-sm btn-outline-secondary" title="<?php echo $l['is_active'] ? 'Turn off' : 'Turn on'; ?>"><i class="fa-solid <?php echo $l['is_active'] ? 'fa-toggle-on' : 'fa-toggle-off'; ?>"></i></button></form>
                                <form method="POST" class="d-inline" onsubmit="return confirm('Remove this location?');"><input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>"><input type="hidden" name="action" value="delete_location"><input type="hidden" name="id" value="<?php echo $l['id']; ?>">
                                    <button class="btn btn-sm btn-outline-danger" title="Remove"><i class="fa-solid fa-trash-can"></i></button></form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$locations): ?><tr><td colspan="6" class="text-center text-muted p-4">No locations yet. Click "Add Location".</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    const tiles = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    const attr = '&copy; OpenStreetMap contributors';
    const locations = <?php echo json_encode(array_map(fn($l) => ['id' => (int)$l['id'], 'name' => $l['name'], 'lat' => (float)$l['latitude'], 'lng' => (float)$l['longitude'], 'r' => (int)$l['radius_m'], 'on' => (bool)$l['is_active']], $locations)); ?>;
    if (typeof L === 'undefined') return;

    // Overview of every location
    const ov = L.map('overviewMap').setView([9.08, 8.68], 6);
    L.tileLayer(tiles, { attribution: attr, maxZoom: 19 }).addTo(ov);
    const bounds = [];
    locations.forEach(function (l) {
        const color = l.on ? '#2d6a4f' : '#999';
        L.circle([l.lat, l.lng], { radius: l.r, color: color, fillOpacity: 0.15 }).addTo(ov);
        L.marker([l.lat, l.lng]).addTo(ov).bindPopup('<strong>' + l.name.replace(/</g, '&lt;') + '</strong><br>' + l.r + ' m radius<br><a href="locations.php?edit=' + l.id + '">Edit</a>');
        bounds.push([l.lat, l.lng]);
    });
    if (bounds.length > 1) ov.fitBounds(bounds, { padding: [30, 30] });

    // Editor
    const em = document.getElementById('editMap');
    if (!em) return;
    const latIn = document.getElementById('lat'), lngIn = document.getElementById('lng');
    const rIn = document.getElementById('radius'), rVal = document.getElementById('radiusVal');
    const start = [parseFloat(latIn.value) || 9.0330, parseFloat(lngIn.value) || 7.4890];
    const map = L.map('editMap').setView(start, latIn.value ? 16 : 12);
    L.tileLayer(tiles, { attribution: attr, maxZoom: 19 }).addTo(map);
    const marker = L.marker(start, { draggable: true }).addTo(map);
    const circle = L.circle(start, { radius: parseInt(rIn.value, 10), color: '#2d6a4f', fillOpacity: 0.2 }).addTo(map);
    let accCircle = null;
    function setPoint(lat, lng, pan) {
        latIn.value = lat.toFixed(7); lngIn.value = lng.toFixed(7);
        marker.setLatLng([lat, lng]); circle.setLatLng([lat, lng]);
        if (pan) map.setView([lat, lng], Math.max(map.getZoom(), 17));
    }
    map.on('click', function (e) { setPoint(e.latlng.lat, e.latlng.lng, false); });
    marker.on('dragend', function () { const p = marker.getLatLng(); setPoint(p.lat, p.lng, false); });
    [latIn, lngIn].forEach(function (el) { el.addEventListener('change', function () {
        const a = parseFloat(latIn.value), b = parseFloat(lngIn.value);
        if (!isNaN(a) && !isNaN(b)) setPoint(a, b, true);
    }); });
    rIn.addEventListener('input', function () { rVal.textContent = rIn.value; circle.setRadius(parseInt(rIn.value, 10)); });
    document.getElementById('btnHere').addEventListener('click', function () {
        const msg = document.getElementById('hereMsg');
        if (!navigator.geolocation) { msg.textContent = 'This browser cannot read GPS.'; return; }
        msg.textContent = 'Reading GPS... (allow location access)';
        navigator.geolocation.getCurrentPosition(function (p) {
            setPoint(p.coords.latitude, p.coords.longitude, true);
            if (accCircle) map.removeLayer(accCircle);
            accCircle = L.circle([p.coords.latitude, p.coords.longitude], { radius: p.coords.accuracy, color: '#0d6efd', weight: 1, fillOpacity: 0.05 }).addTo(map);
            msg.textContent = 'Set from your GPS (accuracy about ' + Math.round(p.coords.accuracy) + ' m). For best results use a phone outdoors or near a window.';
        }, function (err) {
            msg.textContent = 'Could not read GPS: ' + err.message + (location.protocol !== 'https:' ? ' (GPS needs https://)' : '');
        }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
    });
    setTimeout(function () { map.invalidateSize(); }, 300);
})();
</script>

<?php require_once '../includes/footer.php'; ?>
