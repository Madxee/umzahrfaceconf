<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Aviation Hub (Flight Crew, Rostering, Access Cards, PPE & Uniforms)
 */

require_once '../includes/auth.php';
require_feature('aviation');
require_login();
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer', 'Department Head']);

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

// Handle Actions (Roster Flight, Assign Airport Card, Uniform Issuance)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        // 1. Roster Flight
        if ($action === 'roster_flight') {
            $staff_id = intval($_POST['staff_id']);
            $flight_no = trim($_POST['flight_number']);
            $dep_apt = trim(strtoupper($_POST['departure_airport']));
            $arr_apt = trim(strtoupper($_POST['arrival_airport']));
            $dep_time = $_POST['departure_time'];
            $arr_time = $_POST['arrival_time'];
            $role_on_flight = trim($_POST['role_on_flight']);
            
            if ($staff_id <= 0 || empty($flight_no) || empty($dep_apt) || empty($arr_apt) || empty($dep_time) || empty($arr_time)) {
                $error = "All flight details are required to schedule a flight crew assignment.";
            } else {
                try {
                    // Check if crew member has medical class and license expired
                    $chk = $pdo->prepare("SELECT * FROM `aviation_records` WHERE `staff_id` = ?");
                    $chk->execute([$staff_id]);
                    $rec = $chk->fetch();
                    $today = date('Y-m-d');
                    
                    if ($rec && $rec['medical_expiry'] && $rec['medical_expiry'] < $today) {
                        $error = "ERROR: Cannot roster this crew member. Class Medical Certificate has expired! Grounded.";
                    } elseif ($rec && $rec['license_expiry'] && $rec['license_expiry'] < $today) {
                        $error = "ERROR: Cannot roster this crew member. Pilot/Crew license has expired!";
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO `flight_schedules` (`staff_id`, `flight_number`, `departure_airport`, `arrival_airport`, `departure_time`, `arrival_time`, `role_on_flight`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?, 'Scheduled')");
                        $stmt->execute([$staff_id, $flight_no, $dep_apt, $arr_apt, $dep_time, $arr_time, $role_on_flight]);
                        
                        // Notify staff
                        add_notification($staff_id, "New Flight Assigned", "Flight $flight_no on route $dep_apt -> $arr_apt has been scheduled on your roster.");
                        
                        log_activity($_SESSION['user_id'], 'FLIGHT_CREW_ROSTERED', "Scheduled flight $flight_no for crew ID $staff_id");
                        $success = "Flight crew assignment scheduled successfully.";
                    }
                } catch (PDOException $e) {
                    $error = "Failed to roster flight crew: " . $e->getMessage();
                }
            }
        }
        
        // 2. Issue Uniform / PPE
        elseif ($action === 'issue_uniform') {
            $staff_id = intval($_POST['staff_id']);
            $item = trim($_POST['item_name']);
            $size = trim($_POST['size']);
            $qty = intval($_POST['quantity']);
            $issued = $_POST['issued_date'];
            
            if ($staff_id <= 0 || empty($item) || empty($size) || $qty <= 0) {
                $error = "Staff member, item name, size, and quantity are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `uniform_issuance` (`staff_id`, `item_name`, `size`, `quantity`, `issued_date`, `status`) VALUES (?, ?, ?, ?, ?, 'New')");
                    $stmt->execute([$staff_id, $item, $size, $qty, $issued]);
                    
                    log_activity($_SESSION['user_id'], 'UNIFORM_ISSUED', "Issued $qty $item (Size: $size) to staff $staff_id");
                    $success = "Uniform/PPE issuance registered successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to register uniform issue.";
                }
            }
        }
    }
    
    $redir_url = "aviation.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch upcoming flight schedules
try {
    $flights = $pdo->query("SELECT f.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code 
                            FROM `flight_schedules` f 
                            JOIN `staff` s ON f.staff_id = s.id 
                            ORDER BY f.departure_time ASC, f.id DESC")->fetchAll();
} catch (PDOException $e) {
    $flights = [];
}

// Fetch document expirations
try {
    $expiries = $pdo->query("SELECT ar.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, d.name as department_name 
                             FROM `aviation_records` ar 
                             JOIN `staff` s ON ar.staff_id = s.id 
                             LEFT JOIN `departments` d ON s.department_id = d.id 
                             ORDER BY ar.license_expiry ASC, ar.medical_expiry ASC")->fetchAll();
} catch (PDOException $e) {
    $expiries = [];
}

// Fetch uniform inventory logistics
try {
    $uniforms = $pdo->query("SELECT u.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code 
                             FROM `uniform_issuance` u 
                             JOIN `staff` s ON u.staff_id = s.id 
                             ORDER BY u.issued_date DESC")->fetchAll();
} catch (PDOException $e) {
    $uniforms = [];
}

// Fetch crew list (Pilots, Cabin Crew, OCC Dispatchers)
try {
    $crew_members = $pdo->query("SELECT id, first_name, last_name, display_name, staff_id, role 
                                 FROM `staff` 
                                 WHERE `status` = 'Active' 
                                 ORDER BY `first_name` ASC")->fetchAll();
} catch (PDOException $e) {
    $crew_members = [];
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-plane-up me-2"></i>Aviation Operations Desk</h2>
        <p class="text-muted">Roster flight crew schedules, monitor pilot license and medical certificate renewals, and track uniforms.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Flight Scheduler & Roster List -->
    <div class="col-lg-8 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-3">
                <h5 class="fw-bold text-aviation mb-0"><i class="fa-solid fa-calendar-check me-2"></i>Scheduled Flight Roster</h5>
                <button type="button" class="btn btn-sm btn-aviation" data-bs-toggle="modal" data-bs-target="#rosterModal">
                    <i class="fa-solid fa-plus me-1"></i>Roster Flight Crew
                </button>
            </div>
            
            <?php if (count($flights) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Flight No</th>
                                <th>Crew Assigned</th>
                                <th>Route</th>
                                <th>Departure</th>
                                <th>Arrival</th>
                                <th>Role On Flight</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($flights as $f): 
                                $status_badge = 'flight-status-' . strtolower($f['status']);
                            ?>
                                <tr>
                                    <td><strong class="text-dark"><code><?php echo htmlspecialchars($f['flight_number']); ?></code></strong></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars(display_name($f)); ?></strong>
                                        <br><small class="text-secondary">Code: <?php echo htmlspecialchars($f['staff_code']); ?></small>
                                    </td>
                                    <td><code><?php echo htmlspecialchars($f['departure_airport']); ?></code> <i class="fa-solid fa-arrow-right-long mx-1 text-aviation"></i> <code><?php echo htmlspecialchars($f['arrival_airport']); ?></code></td>
                                    <td><?php echo format_datetime($f['departure_time']); ?></td>
                                    <td><?php echo format_datetime($f['arrival_time']); ?></td>
                                    <td><span class="badge bg-secondary"><?php echo htmlspecialchars($f['role_on_flight'] ?: 'Not Specified'); ?></span></td>
                                    <td><span class="badge <?php echo $status_badge; ?> py-1 px-2"><?php echo $f['status']; ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No flights active in scheduled roster. Click Roster Flight Crew to schedule.</p>
            <?php endif; ?>
        </div>

        <!-- Document renewals warning panel -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-triangle-exclamation me-2"></i>Medical, License & Visa Expiry Warnings</h5>
            
            <?php if (count($expiries) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Crew Member</th>
                                <th>License Validity</th>
                                <th>Medical Clearance</th>
                                <th>Passport Validity</th>
                                <th>Airport Access Card</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($expiries as $exp): 
                                $today = date('Y-m-d');
                                
                                // License
                                $lic_exp = $exp['license_expiry'];
                                $lic_color = (!$lic_exp) ? 'text-muted' : (($lic_exp < $today) ? 'text-danger fw-bold' : ((strtotime($lic_exp) < strtotime('+30 days')) ? 'text-warning' : 'text-success'));
                                $lic_val = $lic_exp ? format_date($lic_exp) . ' (' . ($exp['license_type'] ?: 'N/A') . ')' : 'N/A';
                                
                                // Medical
                                $med_exp = $exp['medical_expiry'];
                                $med_color = (!$med_exp) ? 'text-muted' : (($med_exp < $today) ? 'text-danger fw-bold' : ((strtotime($med_exp) < strtotime('+30 days')) ? 'text-warning' : 'text-success'));
                                $med_val = $med_exp ? format_date($med_exp) . ' (' . ($exp['medical_class'] ?: 'N/A') . ')' : 'N/A';
                                
                                // Passport
                                $pass_exp = $exp['passport_expiry'];
                                $pass_color = (!$pass_exp) ? 'text-muted' : (($pass_exp < $today) ? 'text-danger fw-bold' : 'text-success');
                                $pass_val = $pass_exp ? format_date($pass_exp) : 'N/A';
                                
                                // Airport access card
                                $aac_exp = $exp['airport_access_card_expiry'];
                                $aac_color = (!$aac_exp) ? 'text-muted' : (($aac_exp < $today) ? 'text-danger fw-bold' : 'text-success');
                                $aac_val = $aac_exp ? format_date($aac_exp) . ' (' . ($exp['airport_access_card_no'] ?: 'N/A') . ')' : 'N/A';
                            ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars(display_name($exp)); ?></strong>
                                        <br><small class="text-secondary">ID: <code><?php echo htmlspecialchars($exp['staff_code']); ?></code></small>
                                    </td>
                                    <td class="<?php echo $lic_color; ?>"><?php echo $lic_val; ?></td>
                                    <td class="<?php echo $med_color; ?>"><?php echo $med_val; ?></td>
                                    <td class="<?php echo $pass_color; ?>"><?php echo $pass_val; ?></td>
                                    <td class="<?php echo $aac_color; ?>"><?php echo $aac_val; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No aviation records registered to check expiries.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Uniform log & actions -->
    <div class="col-lg-4 col-md-12">
        <!-- Uniform issuance form -->
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-shirt me-2"></i>Issue Uniform & PPE</h5>
            <form method="POST" action="aviation.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="issue_uniform">
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Select Employee *</label>
                    <select class="form-select" name="staff_id" required>
                        <option value="">Choose Staff</option>
                        <?php foreach ($crew_members as $cr): ?>
                            <option value="<?php echo $cr['id']; ?>">
                                <?php echo htmlspecialchars(display_name($cr)); ?> (<?php echo htmlspecialchars($cr['staff_id']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Item Name *</label>
                    <input type="text" class="form-control" name="item_name" placeholder="e.g. Captain Jacket / High-Vis Vest" required>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Size / Dim *</label>
                        <input type="text" class="form-control" name="size" placeholder="e.g. L / 42" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold">Quantity *</label>
                        <input type="number" class="form-control" name="quantity" value="1" min="1" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Issued Date *</label>
                    <input type="date" class="form-control" name="issued_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-check me-1"></i>Issue Uniform Gear</button>
            </form>
        </div>

        <!-- Uniform logs -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-list-ul me-2"></i>Issued Uniforms Log</h5>
            
            <div class="list-group list-group-flush" style="max-height:300px; overflow-y:auto;">
                <?php foreach ($uniforms as $uni): ?>
                    <div class="list-group-item px-0 py-2 text-start small">
                        <strong><?php echo htmlspecialchars(display_name($uni)); ?></strong> (<?php echo htmlspecialchars($uni['staff_code']); ?>)
                        <br><span class="text-aviation fw-semibold"><?php echo $uni['quantity']; ?>x <?php echo htmlspecialchars($uni['item_name']); ?></span> (Size: <code><?php echo htmlspecialchars($uni['size']); ?></code>)
                        <br><small class="text-muted">Issued: <?php echo format_date($uni['issued_date']); ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Roster Flight Crew -->
<div class="modal fade" id="rosterModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" action="aviation.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="roster_flight">
                
                <div class="modal-header bg-aviation text-white">
                    <h5 class="modal-title fw-bold text-white"><i class="fa-solid fa-plane-departure me-2"></i>Roster Flight Crew Assignment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body text-start">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Select Flight Crew *</label>
                            <select class="form-select" name="staff_id" required>
                                <option value="">Choose Pilot/Cabin Crew</option>
                                <?php foreach ($crew_members as $cr): ?>
                                    <option value="<?php echo $cr['id']; ?>">
                                        <?php echo htmlspecialchars(display_name($cr)); ?> (<?php echo htmlspecialchars($cr['staff_id']); ?> - <?php echo $cr['role']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Flight Number *</label>
                            <input type="text" class="form-control" name="flight_number" placeholder="e.g. UMS204" required>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Departure Airport Code (ICAO/IATA) *</label>
                            <input type="text" class="form-control" name="departure_airport" placeholder="e.g. DNMM (Lagos)" maxlength="4" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Arrival Airport Code (ICAO/IATA) *</label>
                            <input type="text" class="form-control" name="arrival_airport" placeholder="e.g. DNAA (Abuja)" maxlength="4" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Departure Date & Time *</label>
                            <input type="datetime-local" class="form-control" name="departure_time" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Arrival Date & Time *</label>
                            <input type="datetime-local" class="form-control" name="arrival_time" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Roster Duty Designation / Board Role *</label>
                        <select class="form-select" name="role_on_flight" required>
                            <option value="Captain">Captain / PIC</option>
                            <option value="First Officer">First Officer / Co-Pilot</option>
                            <option value="Cabin Crew Purser">Cabin Crew Purser</option>
                            <option value="Cabin Attendant">Cabin Attendant</option>
                            <option value="Flight Dispatcher">Flight Dispatcher</option>
                            <option value="Operations Controller">Operations Controller</option>
                        </select>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-aviation">Roster Assignment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
