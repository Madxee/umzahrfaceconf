<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Add New Employee (Direct Admin Privilege)
 */

require_once '../includes/auth.php';
require_once '../includes/mail.php';

// Require HR Admin privilege
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $staff_id          = trim($_POST['staff_id'] ?? '');
    $first_name        = trim($_POST['first_name'] ?? '');
    $other_name        = trim($_POST['other_name'] ?? '');
    $last_name         = trim($_POST['last_name'] ?? '');
    $name_format       = $_POST['name_display_format'] ?? 'first_last';
    if (!array_key_exists($name_format, name_display_formats())) $name_format = 'first_last';
    $gender            = $_POST['gender'] ?? 'Male';
    $dob               = $_POST['dob'] ?? '';
    $email             = trim(strtolower($_POST['email'] ?? ''));
    $phone             = trim($_POST['phone'] ?? '');
    $address           = trim($_POST['address'] ?? '');
    $emergency_contact = trim($_POST['emergency_contact'] ?? '');
    $role              = $_POST['role'] ?? 'Staff';
    $allowed_roles     = ['Staff', 'Department Head', 'Finance Officer', 'HR Officer', 'HR Manager', 'HR Director', 'Managing Director', 'Super Admin'];
    if (!in_array($role, $allowed_roles, true)) $role = 'Staff';
    // Only a Super Admin may create another Super Admin
    if ($role === 'Super Admin' && $_SESSION['role'] !== 'Super Admin') $role = 'HR Manager';
    $status            = $_POST['status'] ?? 'Active';
    $blood_group       = $_POST['blood_group'] ?? 'N/A';
    $allergies         = trim($_POST['allergies'] ?? 'N/A');
    $password          = $_POST['password'] ?? '';
    $csrf_token        = $_POST['csrf_token'] ?? '';

    // Get or Create Department & Position
    $dept_name = trim($_POST['department'] ?? '');
    $pos_title = trim($_POST['position'] ?? '');
    $dept_id = 0;
    $pos_id = 0;

    // Validate CSRF
    if (!verify_csrf_token($csrf_token)) {
        $error = "Security validation failed. Please try again.";
    } elseif (empty($staff_id) || empty($first_name) || empty($last_name) || empty($dob) || empty($email) || empty($phone) || empty($address) || empty($password) || empty($dept_name) || empty($pos_title)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            // Check if email already exists
            $chk_email = $pdo->prepare("SELECT id FROM staff WHERE email = ?");
            $chk_email->execute([$email]);
            if ($chk_email->fetch()) {
                $error = "The email address is already registered.";
            }

            // Check if staff_id already exists
            $chk_id = $pdo->prepare("SELECT id FROM staff WHERE staff_id = ?");
            $chk_id->execute([$staff_id]);
            if ($chk_id->fetch()) {
                $error = "The Staff ID is already registered.";
            }

            if (empty($error)) {
                // Use the chosen department/position, or create them when a new name is typed
            if (!empty($dept_name) && !empty($pos_title)) {
                // Get or Create Dept
                $dept_stmt = $pdo->prepare("SELECT id FROM departments WHERE name = ?");
                $dept_stmt->execute([$dept_name]);
                $dept_id = $dept_stmt->fetchColumn();
                if (!$dept_id) {
                    $ins_dept = $pdo->prepare("INSERT INTO departments (name) VALUES (?)");
                    $ins_dept->execute([$dept_name]);
                    $dept_id = $pdo->lastInsertId();
                }
        
                // Get or Create Position
                $pos_stmt = $pdo->prepare("SELECT id FROM positions WHERE title = ? AND department_id = ?");
                $pos_stmt->execute([$pos_title, $dept_id]);
                $pos_id = $pos_stmt->fetchColumn();
                if (!$pos_id) {
                    $ins_pos = $pdo->prepare("INSERT INTO positions (title, department_id) VALUES (?, ?)");
                    $ins_pos->execute([$pos_title, $dept_id]);
                    $pos_id = $pdo->lastInsertId();
                }
            }

                // Passport Upload Handling
                [$passport_path, $upload_err] = save_uploaded_image('passport_photo', 'passports', 'photo');
                if ($upload_err) {
                    $error = $upload_err;
                }
                $passport_path = $passport_path ?? '';

                if (empty($error)) {
                    // Hash Password
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);

                    // Insert Staff member
                    $sql = "INSERT INTO staff (
                                staff_id, first_name, other_name, last_name, name_display_format, display_name, gender, dob, department_id, position_id, 
                                email, phone, address, emergency_contact, password_hash, role, status, 
                                email_verified, blood_group, allergies, passport_photo, employment_date
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)";
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([
                        $staff_id, $first_name, ($other_name !== '' ? $other_name : null), $last_name, $name_format,
                        compose_display_name($first_name, $other_name, $last_name, $name_format), $gender, $dob, $dept_id, $pos_id,
                        $email, $phone, $address, $emergency_contact, $password_hash, $role, $status,
                        $blood_group, $allergies, $passport_path, date('Y-m-d')
                    ]);
                    
                    $staff_row_id = $pdo->lastInsertId();

                    // Work station for GPS attendance
                    if (intval($_POST['station_id'] ?? 0) > 0) {
                        $pdo->prepare("INSERT IGNORE INTO `staff_locations` (`staff_id`, `location_id`) VALUES (?, ?)")->execute([$staff_row_id, intval($_POST['station_id'])]);
                    }

                    // Leave quota for the current year
                    $quota = intval(get_setting('default_annual_leave_quota', 30));
                    $pdo->prepare("INSERT IGNORE INTO `leave_quotas` (`staff_id`, `year`, `allocated`, `used`, `remaining`) VALUES (?, ?, ?, 0, ?)")
                        ->execute([$staff_row_id, intval(date('Y')), $quota, $quota]);

                    // Generate Active ID Card instantly
                    $verify_token = bin2hex(random_bytes(16));
                    $issue_date = date('Y-m-d');
                    $validity_years = intval(get_setting('id_card_validity_years', 3));
                    $expiry_date = date('Y-m-d', strtotime("+$validity_years years"));
                    
                    $id_stmt = $pdo->prepare("INSERT INTO `staff_ids` (`staff_id`, `verification_token`, `issue_date`, `expiry_date`, `status`) 
                                              VALUES (?, ?, ?, ?, ?)");
                    $id_stmt->execute([$staff_row_id, $verify_token, $issue_date, $expiry_date, $status === 'Suspended' ? 'Suspended' : 'Active']);

                    log_activity($_SESSION['user_id'], 'STAFF_ADDED_DIRECT', "Created employee record: " . compose_display_name($first_name, $other_name, $last_name, $name_format) . " ($staff_id)");
                    $success = "Successfully registered " . compose_display_name($first_name, $other_name, $last_name, $name_format) . ". Active ID card is ready!";
                    
                    // Reset fields
                    $staff_id = $first_name = $other_name = $last_name = $dob = $email = $phone = $address = $emergency_contact = $password = $allergies = '';
                }
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// Existing departments and positions for the pick-or-create inputs
$all_depts = $pdo->query("SELECT `id`, `name` FROM `departments` ORDER BY `name`")->fetchAll();
$all_stations = $pdo->query("SELECT `id`, `name`, `code` FROM `attendance_locations` WHERE `is_active` = 1 ORDER BY (`type` = 'Head Office') DESC, `name`")->fetchAll();
$positions_by_dept = [];
foreach ($pdo->query("SELECT p.title, d.name AS dept FROM `positions` p JOIN `departments` d ON d.id = p.department_id WHERE p.is_active = 1 ORDER BY p.title")->fetchAll() as $row) {
    $positions_by_dept[$row['dept']][] = $row['title'];
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-user-plus me-2"></i>Add New Employee</h2>
        <p class="text-muted">Register employees directly (such as MDs, Chairmen, and Directors) and instantly generate ID cards without self-registration.</p>
    </div>
    <div class="col-md-4 text-md-end">
        <a href="staff.php" class="btn btn-outline-aviation"><i class="fa-solid fa-arrow-left me-2"></i>Back to Directory</a>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
        <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i><?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px;">
    <div class="card-header bg-aviation text-white p-3" style="border-top-left-radius: 12px; border-top-right-radius: 12px;">
        <h5 class="mb-0 fw-bold"><i class="fa-solid fa-user-gear me-2"></i>Employee Details & Account Settings</h5>
    </div>
    <div class="card-body p-4">
        <form method="POST" action="add-staff.php" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            
            <div class="row g-3">
                <!-- Row 1: Staff ID & Name -->
                <div class="col-md-3">
                    <label class="form-label fw-bold">Staff ID / Code <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="staff_id" placeholder="e.g. MD001, UAS102" value="<?php echo htmlspecialchars($staff_id ?? ''); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">First Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php echo htmlspecialchars($first_name ?? ''); ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Other Name</label>
                    <input type="text" class="form-control" name="other_name" placeholder="Middle name" value="<?php echo htmlspecialchars($other_name ?? ''); ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold">Last Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name" value="<?php echo htmlspecialchars($last_name ?? ''); ?>" required>
                </div>
                <div class="col-md-12">
                    <label class="form-label fw-bold">Name to display</label>
                    <select class="form-select" name="name_display_format">
                        <?php echo name_format_options($first_name ?? '', $other_name ?? '', $last_name ?? '', $name_format ?? 'first_last'); ?>
                    </select>
                </div>

                <!-- Row 2: Contact & Authentication -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" name="email" placeholder="e.g. md@umzaair.com" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Phone Number <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="phone" placeholder="Phone Number" value="<?php echo htmlspecialchars($phone ?? ''); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Account Password <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="password" placeholder="Password for login" value="<?php echo htmlspecialchars($password ?? ''); ?>" required>
                </div>

                <!-- Row 3: Demographics -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Gender <span class="text-danger">*</span></label>
                    <select class="form-select" name="gender" required>
                        <option value="Male" <?php echo isset($gender) && $gender === 'Male' ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo isset($gender) && $gender === 'Female' ? 'selected' : ''; ?>>Female</option>
                        <option value="Other" <?php echo isset($gender) && $gender === 'Other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Date of Birth <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" name="dob" value="<?php echo htmlspecialchars($dob ?? ''); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Passport Photo (Optional)</label>
                    <input type="file" class="form-control" name="passport_photo" accept="image/jpeg,image/png,image/webp">
                </div>

                <!-- Row 4: Company Structure -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Department <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="department" list="deptList" id="deptInput" placeholder="Choose or type a new department" value="<?php echo htmlspecialchars($dept_name ?? ''); ?>" autocomplete="off" required>
                    <datalist id="deptList">
                        <?php foreach ($all_depts as $d): ?><option value="<?php echo htmlspecialchars($d['name']); ?>"><?php endforeach; ?>
                    </datalist>
                    <div class="form-text">Pick from the list, or type a new name to create it.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Position <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="position" list="posList" id="posInput" placeholder="Choose or type a new position" value="<?php echo htmlspecialchars($pos_title ?? ''); ?>" autocomplete="off" required>
                    <datalist id="posList"></datalist>
                    <div class="form-text">Positions of the chosen department, or type a new one.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">Portal Role <span class="text-danger">*</span></label>
                    <select class="form-select" name="role" required>
                        <option value="Staff" <?php echo isset($role) && $role === 'Staff' ? 'selected' : ''; ?>>Staff (Read-Only Portal)</option>
                        <option value="Department Head" <?php echo isset($role) && $role === 'Department Head' ? 'selected' : ''; ?>>Department Head</option>
                        <option value="HR Officer" <?php echo isset($role) && $role === 'HR Officer' ? 'selected' : ''; ?>>HR Officer</option>
                        <option value="Finance Officer" <?php echo isset($role) && $role === 'Finance Officer' ? 'selected' : ''; ?>>Finance Officer</option>
                        <option value="HR Manager" <?php echo isset($role) && $role === 'HR Manager' ? 'selected' : ''; ?>>HR Manager</option>
                        <option value="HR Director" <?php echo isset($role) && $role === 'HR Director' ? 'selected' : ''; ?>>HR Director</option>
                        <option value="Managing Director" <?php echo isset($role) && $role === 'Managing Director' ? 'selected' : ''; ?>>Managing Director (approves letters)</option>
                        <?php if ($_SESSION['role'] === 'Super Admin'): ?>
                        <option value="Super Admin" <?php echo isset($role) && $role === 'Super Admin' ? 'selected' : ''; ?>>Super Admin</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="col-md-12">
                    <label class="form-label fw-bold">Work Station (attendance GPS location)</label>
                    <select class="form-select" name="station_id">
                        <option value="">Any active location</option>
                        <?php foreach ($all_stations as $as): ?><option value="<?php echo $as['id']; ?>"><?php echo htmlspecialchars($as['name'] . ($as['code'] ? ' (' . $as['code'] . ')' : '')); ?></option><?php endforeach; ?>
                    </select>
                    <div class="form-text">The staff member registers their face with the camera at their first clock-in.</div>
                </div>

                <!-- Row 5: Medical Details -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Blood Group</label>
                    <select class="form-select" name="blood_group">
                        <option value="N/A" <?php echo isset($blood_group) && $blood_group === 'N/A' ? 'selected' : ''; ?>>N/A</option>
                        <option value="O+" <?php echo isset($blood_group) && $blood_group === 'O+' ? 'selected' : ''; ?>>O+</option>
                        <option value="O-" <?php echo isset($blood_group) && $blood_group === 'O-' ? 'selected' : ''; ?>>O-</option>
                        <option value="A+" <?php echo isset($blood_group) && $blood_group === 'A+' ? 'selected' : ''; ?>>A+</option>
                        <option value="A-" <?php echo isset($blood_group) && $blood_group === 'A-' ? 'selected' : ''; ?>>A-</option>
                        <option value="B+" <?php echo isset($blood_group) && $blood_group === 'B+' ? 'selected' : ''; ?>>B+</option>
                        <option value="B-" <?php echo isset($blood_group) && $blood_group === 'B-' ? 'selected' : ''; ?>>B-</option>
                        <option value="AB+" <?php echo isset($blood_group) && $blood_group === 'AB+' ? 'selected' : ''; ?>>AB+</option>
                        <option value="AB-" <?php echo isset($blood_group) && $blood_group === 'AB-' ? 'selected' : ''; ?>>AB-</option>
                    </select>
                </div>
                <div class="col-md-8">
                    <label class="form-label fw-bold">Allergies (Optional)</label>
                    <input type="text" class="form-control" name="allergies" placeholder="e.g. Dust, Nuts, None" value="<?php echo htmlspecialchars($allergies ?? ''); ?>">
                </div>

                <!-- Row 6: Address & Emergency Contact -->
                <div class="col-md-6">
                    <label class="form-label fw-bold">Home Address <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="address" placeholder="Residential address" value="<?php echo htmlspecialchars($address ?? ''); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">Emergency Contact Details <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="emergency_contact" placeholder="e.g. Sarah Adeboye (Wife): +2348099887766" value="<?php echo htmlspecialchars($emergency_contact ?? ''); ?>" required>
                </div>

                <!-- Row 7: Status Selection -->
                <div class="col-md-4">
                    <label class="form-label fw-bold">Account Status <span class="text-danger">*</span></label>
                    <select class="form-select" name="status" required>
                        <option value="Active" <?php echo isset($status) && $status === 'Active' ? 'selected' : ''; ?>>Active (Approved & ID Printable)</option>
                        <option value="Pending" <?php echo isset($status) && $status === 'Pending' ? 'selected' : ''; ?>>Pending (Awaiting Approval)</option>
                        <option value="Suspended" <?php echo isset($status) && $status === 'Suspended' ? 'selected' : ''; ?>>Suspended (Deactivated)</option>
                    </select>
                </div>
            </div>

            <div class="text-end mt-4 pt-3 border-top">
                <button type="submit" class="btn btn-success px-4 py-2"><i class="fa-solid fa-floppy-disk me-2"></i>Save & Create Employee</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Show the positions that belong to the department typed/selected above
    const positionsByDept = <?php echo json_encode($positions_by_dept); ?>;
    const deptInput = document.getElementById('deptInput');
    const posList = document.getElementById('posList');
    function refreshPositions() {
        posList.innerHTML = '';
        (positionsByDept[deptInput.value.trim()] || []).forEach(function (t) {
            const o = document.createElement('option'); o.value = t; posList.appendChild(o);
        });
    }
    deptInput.addEventListener('input', refreshPositions);
    refreshPositions();
</script>

<?php require_once '../includes/footer.php'; ?>
