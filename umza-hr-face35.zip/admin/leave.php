<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Admin Panel - Leave Request Manager
 */

require_once '../includes/auth.php';
require_feature('leave');
require_login();
require_role(['Super Admin', 'Managing Director', 'HR Director', 'HR Manager', 'HR Officer', 'Department Head']);

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Handle Leave Approval / Rejection / Quota changes
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        // Approve / Reject actions
        if ($action === 'approve_leave' || $action === 'reject_leave') {
            $leave_id = intval($_POST['leave_id'] ?? 0);
            $hr_remarks = trim($_POST['hr_remarks'] ?? '');
            
            try {
                // Fetch leave request details
                $stmt = $pdo->prepare("SELECT lr.*, s.first_name, s.last_name, s.display_name, s.email FROM `leave_requests` lr JOIN `staff` s ON lr.staff_id = s.id WHERE lr.id = ?");
                $stmt->execute([$leave_id]);
                $leave = $stmt->fetch();
                
                if (!$leave) {
                    $error = "Leave request not found.";
                } elseif ($leave['status'] !== 'Pending') {
                    $error = "This leave request has already been processed.";
                } else {
                    $staff_name = display_name($leave);
                    $year = intval(date('Y', strtotime($leave['start_date'])));
                    
                    if ($action === 'approve_leave') {
                        $pdo->beginTransaction();
                        
                        // Check / Create Quota for the staff member for that year
                        $quota_stmt = $pdo->prepare("SELECT * FROM `leave_quotas` WHERE `staff_id` = ? AND `year` = ?");
                        $quota_stmt->execute([$leave['staff_id'], $year]);
                        $quota = $quota_stmt->fetch();
                        
                        if (!$quota) {
                            $default_allocated = intval(get_setting('default_annual_leave_quota', 30));
                            $insert_quota = $pdo->prepare("INSERT INTO `leave_quotas` (`staff_id`, `year`, `allocated`, `used`, `remaining`) VALUES (?, ?, ?, 0, ?)");
                            $insert_quota->execute([$leave['staff_id'], $year, $default_allocated, $default_allocated]);
                            
                            $quota = [
                                'allocated' => $default_allocated,
                                'used' => 0,
                                'remaining' => $default_allocated
                            ];
                        }
                        
                        // Update leave status to Approved
                        $update_leave = $pdo->prepare("UPDATE `leave_requests` SET `status` = 'Approved', `hr_remarks` = ?, `approved_by` = ? WHERE `id` = ?");
                        $update_leave->execute([$hr_remarks, $user_id, $leave_id]);
                        
                        // Recalculate Quota
                        $new_used = $quota['used'] + $leave['duration'];
                        $new_remaining = $quota['allocated'] - $new_used;
                        
                        $update_quota = $pdo->prepare("UPDATE `leave_quotas` SET `used` = ?, `remaining` = ? WHERE `staff_id` = ? AND `year` = ?");
                        $update_quota->execute([$new_used, $new_remaining, $leave['staff_id'], $year]);
                        
                        $pdo->commit();
                        
                        log_activity($user_id, 'LEAVE_APPROVED', "Approved {$leave['duration']} days leave for $staff_name");
                        
                        // Send Email Notification
                        $subject = "Leave Request Approved - UMZA Aviation Services Ltd";
                        $body = "
                            <p>Your request for <strong>{$leave['leave_type']}</strong> has been approved by the HR department.</p>
                            <ul>
                                <li><strong>Duration:</strong> {$leave['duration']} Days</li>
                                <li><strong>Start Date:</strong> " . format_date($leave['start_date']) . "</li>
                                <li><strong>End Date:</strong> " . format_date($leave['end_date']) . "</li>
                                <li><strong>Remarks:</strong> " . ($hr_remarks ?: 'None') . "</li>
                            </ul>
                            <p>Your official leave approval letter (on company letterhead) is ready.</p>
                            <p><a href='" . get_base_url() . "/staff/print-leave.php?id=" . (int)$leave['id'] . "' class='btn'>Open Approval Letter</a></p>";
                        send_email($leave['email'], $staff_name, $subject, $body);
                        
                        $message = "Leave request for $staff_name approved successfully.";
                    } 
                    else {
                        // Reject Leave
                        $update_leave = $pdo->prepare("UPDATE `leave_requests` SET `status` = 'Rejected', `hr_remarks` = ?, `approved_by` = ? WHERE `id` = ?");
                        $update_leave->execute([$hr_remarks, $user_id, $leave_id]);
                        
                        log_activity($user_id, 'LEAVE_REJECTED', "Rejected leave request for $staff_name. Reason: $hr_remarks");
                        
                        // Send Email Notification
                        $subject = "Leave Request Declined - UMZA Aviation Services Ltd";
                        $body = "
                            <p>Please be informed that your request for <strong>{$leave['leave_type']}</strong> has been rejected by the HR department.</p>
                            <ul>
                                <li><strong>Duration:</strong> {$leave['duration']} Days</li>
                                <li><strong>Start Date:</strong> " . format_date($leave['start_date']) . "</li>
                                <li><strong>End Date:</strong> " . format_date($leave['end_date']) . "</li>
                                <li><strong>HR Remarks / Reason:</strong> " . ($hr_remarks ?: 'No reason specified') . "</li>
                            </ul>
                            <p>If you need further clarification, please contact the HR department or your Department Head.</p>";
                        send_email($leave['email'], $staff_name, $subject, $body);

                        $message = "Leave request for $staff_name rejected successfully.";
                    }
                }
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = "Database operation failed: " . $e->getMessage();
            }
        }
        // Set / Modify Quota Action
        elseif ($action === 'set_quota') {
            $staff_id_target = intval($_POST['staff_id'] ?? 0);
            $year = intval($_POST['year'] ?? date('Y'));
            $allocated = intval($_POST['allocated'] ?? 30);
            
            if ($staff_id_target <= 0 || $allocated < 0) {
                $error = "Please fill in valid details.";
            } else {
                try {
                    // Fetch existing quota
                    $stmt = $pdo->prepare("SELECT * FROM `leave_quotas` WHERE `staff_id` = ? AND `year` = ?");
                    $stmt->execute([$staff_id_target, $year]);
                    $existing = $stmt->fetch();
                    
                    if ($existing) {
                        $new_remaining = $allocated - $existing['used'];
                        $update = $pdo->prepare("UPDATE `leave_quotas` SET `allocated` = ?, `remaining` = ? WHERE `staff_id` = ? AND `year` = ?");
                        $update->execute([$allocated, $new_remaining, $staff_id_target, $year]);
                    } else {
                        $insert = $pdo->prepare("INSERT INTO `leave_quotas` (`staff_id`, `year`, `allocated`, `used`, `remaining`) VALUES (?, ?, ?, 0, ?)");
                        $insert->execute([$staff_id_target, $year, $allocated, $allocated]);
                    }
                    
                    log_activity($user_id, 'LEAVE_QUOTA_ADJUSTED', "Adjusted leave quota for staff ID $staff_id_target in Year $year to $allocated days");
                    $message = "Leave quota updated successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to update leave quota: " . $e->getMessage();
                }
            }
        }
    }
    
    // Redirect to clear form resubmissions
    $redir_url = "leave.php?" . (empty($error) ? "success=" . urlencode($message) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Retrieve details
try {
    // 1. Fetch pending leaves
    if ($_SESSION['role'] === 'Department Head') {
        // Only fetch pending leaves for their department
        $pending_stmt = $pdo->prepare("SELECT lr.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, d.name as department 
                                       FROM `leave_requests` lr 
                                       JOIN `staff` s ON lr.staff_id = s.id 
                                       JOIN `departments` d ON s.department_id = d.id 
                                       WHERE lr.status = 'Pending' AND s.department_id = (SELECT department_id FROM staff WHERE id = ?) 
                                       ORDER BY lr.id ASC");
        $pending_stmt->execute([$user_id]);
    } else {
        $pending_stmt = $pdo->query("SELECT lr.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, d.name as department 
                                     FROM `leave_requests` lr 
                                     JOIN `staff` s ON lr.staff_id = s.id 
                                     JOIN `departments` d ON s.department_id = d.id 
                                     WHERE lr.status = 'Pending' 
                                     ORDER BY lr.id ASC");
    }
    $pending_leaves = $pending_stmt->fetchAll();

    // 2. Fetch completed leaves (Last 50)
    if ($_SESSION['role'] === 'Department Head') {
        $history_stmt = $pdo->prepare("SELECT lr.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code 
                                       FROM `leave_requests` lr 
                                       JOIN `staff` s ON lr.staff_id = s.id 
                                       WHERE lr.status != 'Pending' AND s.department_id = (SELECT department_id FROM staff WHERE id = ?) 
                                       ORDER BY lr.id DESC LIMIT 50");
        $history_stmt->execute([$user_id]);
    } else {
        $history_stmt = $pdo->query("SELECT lr.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code 
                                     FROM `leave_requests` lr 
                                     JOIN `staff` s ON lr.staff_id = s.id 
                                     WHERE lr.status != 'Pending' 
                                     ORDER BY lr.id DESC LIMIT 50");
    }
    $leaves_history = $history_stmt->fetchAll();

    // 3. Load active staff list for Quota allocator (Exclude pending/suspended)
    $staff_list = $pdo->query("SELECT `id`, `first_name`, `last_name`, `display_name`, `staff_id` FROM `staff` WHERE `status` = 'Active' ORDER BY `first_name` ASC")->fetchAll();

} catch (PDOException $e) {
    die("Error fetching leave requests: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-calendar-check me-2"></i>Leave Management</h2>
        <p class="text-muted">Review leave requests, verify allowances, and adjust annual quotas.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Area: Pending Requests list -->
    <div class="col-xl-8 col-lg-7">
        <div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px; overflow: hidden;">
            <div class="card-header bg-aviation p-3">
                <h5 class="fw-bold text-white mb-0"><i class="fa-solid fa-clock me-2"></i>Pending Requests</h5>
            </div>
            
            <div class="table-responsive">
                <table class="table table-custom align-middle mb-0" style="font-size:0.85rem;">
                    <thead>
                        <tr>
                            <th>Staff Name</th>
                            <th>Leave Category</th>
                            <th>Duration</th>
                            <th>Date Range</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($pending_leaves) > 0): ?>
                            <?php foreach ($pending_leaves as $request): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars(display_name($request)); ?></strong>
                                        <br><small class="text-muted">ID: <?php echo htmlspecialchars($request['staff_code']); ?> | <?php echo htmlspecialchars($request['department']); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-success border border-success-subtle"><?php echo htmlspecialchars($request['leave_type']); ?></span>
                                    </td>
                                    <td>
                                        <strong><?php echo $request['duration']; ?> Days</strong>
                                    </td>
                                    <td>
                                        <?php echo format_date($request['start_date']); ?> to <?php echo format_date($request['end_date']); ?>
                                        <br><small class="text-secondary italic">Reason: <?php echo htmlspecialchars($request['reason']); ?></small>
                                         <?php if (!empty($request['attachment_path'])): ?>
                                             <?php $file_name = basename($request['attachment_path']); ?>
                                             <div class="mt-1">
                                                 <div class="btn-group btn-group-sm">
                                                     <a href="<?php echo get_base_url() . '/' . $request['attachment_path']; ?>" target="_blank" class="btn btn-xs btn-outline-aviation py-0 px-2 text-decoration-none" style="font-size:0.7rem;">
                                                         <i class="fa-solid fa-eye"></i> View
                                                     </a>
                                                     <a href="<?php echo get_base_url() . '/' . $request['attachment_path']; ?>" download="<?php echo htmlspecialchars($file_name); ?>" class="btn btn-xs btn-aviation py-0 px-2 text-decoration-none" style="font-size:0.7rem;">
                                                         <i class="fa-solid fa-download"></i>
                                                     </a>
                                                 </div>
                                             </div>
                                         <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#actionModal<?php echo $request['id']; ?>">
                                            <i class="fa-solid fa-clipboard-check"></i> Process
                                        </button>
                                        
                                        <!-- PROCESS MODAL -->
                                        <div class="modal fade" id="actionModal<?php echo $request['id']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-aviation text-white">
                                                        <h5 class="modal-title fw-bold">Process Leave Request</h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <form method="POST" action="leave.php">
                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                        <input type="hidden" name="leave_id" value="<?php echo $request['id']; ?>">
                                                        <div class="modal-body">
                                                            <div class="mb-3 text-start">
                                                                <h6><strong>Employee:</strong> <?php echo htmlspecialchars(display_name($request)); ?></h6>
                                                                <h6><strong>Category:</strong> <?php echo htmlspecialchars($request['leave_type']); ?></h6>
                                                                <h6><strong>Duration:</strong> <?php echo $request['duration']; ?> Days</h6>
                                                                <h6><strong>Range:</strong> <?php echo format_date($request['start_date']) . ' to ' . format_date($request['end_date']); ?></h6>
                                                                <p class="text-muted bg-light p-2 rounded mb-0 mt-2" style="font-size:0.8rem;"><strong>Reason:</strong> <?php echo htmlspecialchars($request['reason']); ?></p>
                                                                 <?php if (!empty($request['attachment_path'])): ?>
                                                                     <?php $file_name = basename($request['attachment_path']); ?>
                                                                     <div class="mt-2 text-start">
                                                                         <span class="d-block small text-muted mb-1">Attached Document:</span>
                                                                         <div class="btn-group btn-group-sm">
                                                                             <a href="<?php echo get_base_url() . '/' . $request['attachment_path']; ?>" target="_blank" class="btn btn-outline-aviation btn-sm">
                                                                                 <i class="fa-solid fa-eye"></i> View Document
                                                                             </a>
                                                                             <a href="<?php echo get_base_url() . '/' . $request['attachment_path']; ?>" download="<?php echo htmlspecialchars($file_name); ?>" class="btn btn-aviation btn-sm">
                                                                                 <i class="fa-solid fa-download"></i> Download
                                                                             </a>
                                                                         </div>
                                                                     </div>
                                                                 <?php endif; ?>
                                                            </div>
                                                            
                                                            <div class="mb-3 text-start">
                                                                <label class="form-label fw-bold" for="remarks">HR Remarks / Admin Feedback</label>
                                                                <textarea class="form-control" name="hr_remarks" id="remarks" rows="3" placeholder="Enter reason for approval or rejection..."></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer bg-light">
                                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" name="action" value="reject_leave" class="btn btn-danger btn-sm"><i class="fa-solid fa-circle-xmark"></i> Decline Request</button>
                                                            <button type="submit" name="action" value="approve_leave" class="btn btn-success btn-sm"><i class="fa-solid fa-circle-check"></i> Approve Request</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted p-4">
                                    <i class="fa-solid fa-circle-check fa-2x mb-2 text-success d-block"></i>
                                    No pending leave requests found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- History Table -->
        <div class="card shadow-sm border-0 bg-white" style="border-radius: 12px; overflow: hidden;">
            <div class="card-header bg-secondary p-3">
                <h5 class="fw-bold text-white mb-0"><i class="fa-solid fa-clock-rotate-left me-2"></i>Recent Leave Actions</h5>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0" style="font-size:0.85rem;">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Leave Category</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Processed Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($leaves_history) > 0): ?>
                            <?php foreach ($leaves_history as $history): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars(display_name($history)); ?></strong>
                                        <br><small class="text-muted">ID: <?php echo htmlspecialchars($history['staff_code']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($history['leave_type']); ?></td>
                                    <td><?php echo $history['duration']; ?> Days</td>
                                    <td>
                                        <span class="badge bg-<?php echo $history['status'] === 'Approved' ? 'success' : 'danger'; ?>">
                                            <?php echo $history['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo format_datetime($history['created_at']); ?>
                                        <?php if (!empty($history['hr_remarks'])): ?>
                                            <br><small class="text-muted">Remarks: <?php echo htmlspecialchars($history['hr_remarks']); ?></small>
                                        <?php endif; ?>
                                        <?php if (!empty($history['attachment_path'])): ?>
                                            <br><a href="<?php echo get_base_url() . '/' . $history['attachment_path']; ?>" target="_blank" class="badge bg-secondary text-decoration-none mt-1">
                                                <i class="fa-solid fa-paperclip me-1"></i> View Document
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted p-4">No leave history found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Right Area: Leave Quota Allocator -->
    <div class="col-xl-4 col-lg-5">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-sliders me-2"></i>Set Staff Leave Quota</h5>
            <form method="POST" action="leave.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="set_quota">
                
                <div class="mb-3">
                    <label class="form-label" for="staff_id">Select Employee *</label>
                    <select class="form-select" id="staff_id" name="staff_id" required>
                        <option value="">Choose Employee</option>
                        <?php foreach ($staff_list as $staff): ?>
                            <option value="<?php echo $staff['id']; ?>"><?php echo htmlspecialchars(display_name($staff)) . " (" . htmlspecialchars($staff['staff_id']) . ")"; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label" for="year">Year *</label>
                    <select class="form-select" id="year" name="year" required>
                        <option value="<?php echo date('Y'); ?>"><?php echo date('Y'); ?> (Current)</option>
                        <option value="<?php echo date('Y', strtotime('+1 year')); ?>"><?php echo date('Y', strtotime('+1 year')); ?></option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label" for="allocated">Allocated Annual Leave (Days) *</label>
                    <input type="number" class="form-control" id="allocated" name="allocated" min="0" max="100" value="30" required>
                    <div class="form-text" style="font-size:0.75rem;">Standard company policy defaults to 30 days.</div>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2">
                    <i class="fa-solid fa-save me-1"></i>Save Quota Allocation
                </button>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
