<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Detailed Employee Profile & Information Editor
 */

require_once '../includes/auth.php';

// Force HR Admin roles
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer', 'Finance Officer']);

$staff_id_param = intval($_GET['id'] ?? 0);
if ($staff_id_param <= 0) {
    header("Location: staff.php?error=Invalid+employee+selected.");
    exit;
}

$error = '';
$success = '';

// Handle actions (Edit details, qualification, experience, assets, transfer, exit, aviation records)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF Token validation failed.";
    } else {
        // 1. Edit Profile Details Action
        if ($action === 'edit_profile') {
            $first_name = trim($_POST['first_name'] ?? '');
            $other_name = trim($_POST['other_name'] ?? '');
            $last_name = trim($_POST['last_name'] ?? '');
            $name_format = $_POST['name_display_format'] ?? 'first_last';
            if (!array_key_exists($name_format, name_display_formats())) $name_format = 'first_last';
            $gender = $_POST['gender'] ?? 'Male';
            $dob = $_POST['dob'] ?? '';
            $department_id = intval($_POST['department'] ?? 0) ?: null;
            $position_id = intval($_POST['position'] ?? 0) ?: null;
            $email = trim(strtolower($_POST['email'] ?? ''));
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $employment_date = $_POST['employment_date'] ?? '';
            $emergency_contact = trim($_POST['emergency_contact'] ?? '');
            $role = $_POST['role'] ?? 'Staff';
            $new_password = trim($_POST['new_password'] ?? '');
            $valid_roles = ['Staff', 'Department Head', 'Finance Officer', 'HR Officer', 'HR Manager', 'HR Director', 'Managing Director', 'Super Admin'];

            // Current values (to protect Super Admin role changes)
            $cur = $pdo->prepare("SELECT `role`, `passport_photo` FROM `staff` WHERE `id` = ?");
            $cur->execute([$staff_id_param]);
            $current_row = $cur->fetch() ?: ['role' => 'Staff', 'passport_photo' => null];

            if (empty($first_name) || empty($last_name) || empty($email)) {
                $error = "Name and email are required fields.";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = "Please enter a valid email address.";
            } elseif (!in_array($role, $valid_roles, true)) {
                $error = "Invalid portal role.";
            } elseif ($_SESSION['role'] !== 'Super Admin' && ($role === 'Super Admin' || $current_row['role'] === 'Super Admin') && $role !== $current_row['role']) {
                $error = "Only a Super Admin can give or remove the Super Admin role.";
            } elseif (!empty($new_password) && strlen($new_password) < 8) {
                $error = "New password must be at least 8 characters.";
            } else {
                $dupe = $pdo->prepare("SELECT id FROM `staff` WHERE `email` = ? AND `id` <> ?");
                $dupe->execute([$email, $staff_id_param]);
                if ($dupe->fetch()) {
                    $error = "Another staff member already uses this email address.";
                }
                // New passport photo uploaded by HR
                [$new_photo, $photo_err] = save_uploaded_image('passport_photo', 'passports', 'photo');
                if ($photo_err) {
                    $error = $photo_err;
                }
            }
            if (empty($error)) {
                try {
                    $sql_update = "UPDATE `staff` SET 
                        `first_name` = ?, `other_name` = ?, `last_name` = ?, `name_display_format` = ?, `gender` = ?, `dob` = ?, 
                        `department_id` = ?, `position_id` = ?, `email` = ?, `phone` = ?, 
                        `address` = ?, `employment_date` = ?, `emergency_contact` = ?, `role` = ?";
                    
                    $params = [
                        $first_name, $other_name !== '' ? $other_name : null, $last_name, $name_format, $gender, $dob, 
                        $department_id, $position_id, $email, $phone, 
                        $address, $employment_date, $emergency_contact, $role
                    ];
                    if (!empty($new_photo)) {
                        $sql_update .= ", `passport_photo` = ?";
                        $params[] = $new_photo;
                    }
                    
                    if (!empty($new_password)) {
                        $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
                        $sql_update .= ", `password_hash` = ?";
                        $params[] = $new_hash;
                    }
                    
                    $sql_update .= " WHERE `id` = ?";
                    $params[] = $staff_id_param;
                    
                    $stmt = $pdo->prepare($sql_update);
                    $stmt->execute($params);
                    $shown_name = refresh_display_name($staff_id_param);

                    // Work station(s) for GPS attendance
                    if (isset($_POST['stations_submitted'])) {
                        $pdo->prepare("DELETE FROM `staff_locations` WHERE `staff_id` = ?")->execute([$staff_id_param]);
                        $ins_loc = $pdo->prepare("INSERT IGNORE INTO `staff_locations` (`staff_id`, `location_id`) VALUES (?, ?)");
                        foreach ((array)($_POST['station_ids'] ?? []) as $lid) {
                            if (intval($lid) > 0) $ins_loc->execute([$staff_id_param, intval($lid)]);
                        }
                    }
                    // Clear face registration so the staff member registers again at next clock-in
                    if (!empty($_POST['reset_face'])) {
                        $pdo->prepare("UPDATE `staff` SET `face_descriptor` = NULL, `face_source` = NULL, `face_descriptor_photo` = NULL WHERE `id` = ?")->execute([$staff_id_param]);
                        log_activity($_SESSION['user_id'], 'FACE_RESET', "Reset face registration for staff #$staff_id_param");
                    }
                    if (!empty($new_photo) && !empty($current_row['passport_photo']) && $current_row['passport_photo'] !== $new_photo) {
                        delete_upload($current_row['passport_photo']);
                    }

                    log_activity($_SESSION['user_id'], 'STAFF_PROFILE_UPDATED', "Edited profile for: $shown_name (ID: $staff_id_param)" . (!empty($new_photo) ? ' - new passport photo' : ''));
                    $success = "Employee profile updated successfully.";
                } catch (PDOException $e) {
                    $error = "A database error occurred: " . $e->getMessage();
                    if (!empty($new_photo)) delete_upload($new_photo);
                }
            } elseif (!empty($new_photo)) {
                delete_upload($new_photo);
            }
        }
        
        // 2. Add Qualification
        elseif ($action === 'add_qualification') {
            $inst = trim($_POST['institution']);
            $q_name = trim($_POST['qualification_name']);
            $field = trim($_POST['field_of_study'] ?? '');
            $year = intval($_POST['year_obtained']);
            
            if (empty($inst) || empty($q_name) || $year <= 0) {
                $error = "Institution, qualification name, and year are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `qualifications` (`staff_id`, `institution`, `qualification_name`, `field_of_study`, `year_obtained`) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$staff_id_param, $inst, $q_name, $field, $year]);
                    log_activity($_SESSION['user_id'], 'QUALIFICATION_ADDED', "Added qualification: $q_name for staff ID $staff_id_param");
                    $success = "Qualification added successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to add qualification.";
                }
            }
        }
        
        // 3. Delete Qualification
        elseif ($action === 'delete_qualification') {
            $q_id = intval($_POST['q_id'] ?? 0);
            try {
                $stmt = $pdo->prepare("DELETE FROM `qualifications` WHERE `id` = ? AND `staff_id` = ?");
                $stmt->execute([$q_id, $staff_id_param]);
                log_activity($_SESSION['user_id'], 'QUALIFICATION_DELETED', "Deleted qualification ID $q_id for staff $staff_id_param");
                $success = "Qualification deleted.";
            } catch (PDOException $e) {
                $error = "Failed to delete qualification.";
            }
        }

        // 4. Add Employment History
        elseif ($action === 'add_experience') {
            $company = trim($_POST['company_name']);
            $pos = trim($_POST['position']);
            $start = $_POST['start_date'];
            $end = $_POST['end_date'] ?: null;
            $resp = trim($_POST['responsibilities'] ?? '');
            
            if (empty($company) || empty($pos) || empty($start)) {
                $error = "Company, position, and start date are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `employment_history` (`staff_id`, `company_name`, `position`, `start_date`, `end_date`, `responsibilities`) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$staff_id_param, $company, $pos, $start, $end, $resp]);
                    log_activity($_SESSION['user_id'], 'EXPERIENCE_ADDED', "Added work history: $pos at $company for staff ID $staff_id_param");
                    $success = "Work history added.";
                } catch (PDOException $e) {
                    $error = "Failed to add work history.";
                }
            }
        }

        // 5. Delete Experience
        elseif ($action === 'delete_experience') {
            $exp_id = intval($_POST['exp_id'] ?? 0);
            try {
                $stmt = $pdo->prepare("DELETE FROM `employment_history` WHERE `id` = ? AND `staff_id` = ?");
                $stmt->execute([$exp_id, $staff_id_param]);
                log_activity($_SESSION['user_id'], 'EXPERIENCE_DELETED', "Deleted work history ID $exp_id for staff $staff_id_param");
                $success = "Work history deleted.";
            } catch (PDOException $e) {
                $error = "Failed to delete work history.";
            }
        }

        // 6. Assign Asset
        elseif ($action === 'assign_asset') {
            $name = trim($_POST['asset_name']);
            $code = trim($_POST['asset_code']);
            $cat = trim($_POST['category'] ?? '');
            $serial = trim($_POST['serial_number'] ?? '');
            $assigned = $_POST['assigned_date'];
            
            if (empty($name) || empty($code) || empty($assigned)) {
                $error = "Asset name, code, and assigned date are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `asset_assignments` (`staff_id`, `asset_name`, `asset_code`, `category`, `serial_number`, `assigned_date`, `status`) VALUES (?, ?, ?, ?, ?, ?, 'Assigned')");
                    $stmt->execute([$staff_id_param, $name, $code, $cat, $serial, $assigned]);
                    log_activity($_SESSION['user_id'], 'ASSET_ASSIGNED', "Assigned asset $name ($code) to staff ID $staff_id_param");
                    $success = "Asset assigned successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to assign asset. Make sure code is unique.";
                }
            }
        }

        // 7. Return Asset
        elseif ($action === 'return_asset') {
            $asset_id = intval($_POST['asset_id'] ?? 0);
            $ret_date = date('Y-m-d');
            try {
                $stmt = $pdo->prepare("UPDATE `asset_assignments` SET `returned_date` = ?, `status` = 'Returned' WHERE `id` = ? AND `staff_id` = ?");
                $stmt->execute([$ret_date, $asset_id, $staff_id_param]);
                log_activity($_SESSION['user_id'], 'ASSET_RETURNED', "Asset returned for assignment ID $asset_id for staff $staff_id_param");
                $success = "Asset returned successfully.";
            } catch (PDOException $e) {
                $error = "Failed to return asset.";
            }
        }

        // 8. Department Transfer
        elseif ($action === 'transfer_dept') {
            $from_dept = intval($_POST['from_dept_id'] ?: 0);
            $to_dept = intval($_POST['to_dept_id']);
            $date = $_POST['transfer_date'];
            $reason = trim($_POST['reason'] ?? '');
            
            if ($to_dept <= 0 || empty($date)) {
                $error = "Destination department and transfer date are required.";
            } else {
                try {
                    $pdo->beginTransaction();
                    // Log transfer
                    $stmt = $pdo->prepare("INSERT INTO `department_transfers` (`staff_id`, `from_department_id`, `to_department_id`, `transfer_date`, `reason`, `approved_by`) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$staff_id_param, $from_dept ?: null, $to_dept, $date, $reason, $_SESSION['user_id']]);
                    
                    // Update staff table
                    $upd = $pdo->prepare("UPDATE `staff` SET `department_id` = ?, `position_id` = NULL WHERE `id` = ?");
                    $upd->execute([$to_dept, $staff_id_param]);
                    
                    // Add notification
                    add_notification($staff_id_param, "Department Transfer", "You have been transferred to a new department. Please verify your profile.");
                    
                    $pdo->commit();
                    log_activity($_SESSION['user_id'], 'DEPARTMENT_TRANSFERRED', "Transferred staff $staff_id_param to department ID $to_dept");
                    $success = "Department transfer processed successfully. Note that position is reset; please reassign.";
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $error = "Failed to transfer department: " . $e->getMessage();
                }
            }
        }

        // 9. Process Staff Exit
        elseif ($action === 'process_exit') {
            $exit_date = $_POST['exit_date'];
            $type = $_POST['exit_type'];
            $reason = trim($_POST['reason'] ?? '');
            $clearance = $_POST['clearance_status'];
            $remarks = trim($_POST['remarks'] ?? '');
            
            if (empty($exit_date) || empty($type)) {
                $error = "Exit date and exit type are required.";
            } else {
                try {
                    $pdo->beginTransaction();
                    
                    $stmt = $pdo->prepare("INSERT INTO `exit_records` (`staff_id`, `exit_date`, `exit_type`, `reason`, `clearance_status`, `remarks`, `processed_by`) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE `exit_date` = VALUES(`exit_date`), `exit_type` = VALUES(`exit_type`), `reason` = VALUES(`reason`), `clearance_status` = VALUES(`clearance_status`), `remarks` = VALUES(`remarks`), `processed_by` = VALUES(`processed_by`)");
                    $stmt->execute([$staff_id_param, $exit_date, $type, $reason, $clearance, $remarks, $_SESSION['user_id']]);
                    
                    // Suspend staff account upon exit
                    $upd = $pdo->prepare("UPDATE `staff` SET `status` = 'Suspended' WHERE `id` = ?");
                    $upd->execute([$staff_id_param]);
                    
                    $pdo->commit();
                    log_activity($_SESSION['user_id'], 'STAFF_EXIT_PROCESSED', "Processed exit for staff member $staff_id_param (Type: $type)");
                    $success = "Exit records updated successfully. Staff status is set to Suspended.";
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $error = "Failed to process exit: " . $e->getMessage();
                }
            }
        }

        // 10. Update Aviation Records
        elseif ($action === 'update_aviation_records') {
            $passport_no = trim($_POST['passport_number'] ?? '');
            $passport_expiry = $_POST['passport_expiry'] ?: null;
            $visa_details = trim($_POST['visa_details'] ?? '');
            $visa_expiry = $_POST['visa_expiry'] ?: null;
            $license_no = trim($_POST['license_number'] ?? '');
            $license_type = $_POST['license_type'] ?: null;
            $license_expiry = $_POST['license_expiry'] ?: null;
            $medical_class = $_POST['medical_class'] ?: null;
            $medical_expiry = $_POST['medical_expiry'] ?: null;
            $access_card = trim($_POST['airport_access_card_no'] ?? '');
            $access_expiry = $_POST['airport_access_card_expiry'] ?: null;
            
            try {
                $stmt = $pdo->prepare("INSERT INTO `aviation_records` 
                    (`staff_id`, `license_number`, `license_type`, `license_expiry`, `medical_class`, `medical_expiry`, `passport_number`, `passport_expiry`, `visa_details`, `visa_expiry`, `airport_access_card_no`, `airport_access_card_expiry`) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
                    ON DUPLICATE KEY UPDATE 
                    `license_number` = VALUES(`license_number`),
                    `license_type` = VALUES(`license_type`),
                    `license_expiry` = VALUES(`license_expiry`),
                    `medical_class` = VALUES(`medical_class`),
                    `medical_expiry` = VALUES(`medical_expiry`),
                    `passport_number` = VALUES(`passport_number`),
                    `passport_expiry` = VALUES(`passport_expiry`),
                    `visa_details` = VALUES(`visa_details`),
                    `visa_expiry` = VALUES(`visa_expiry`),
                    `airport_access_card_no` = VALUES(`airport_access_card_no`),
                    `airport_access_card_expiry` = VALUES(`airport_access_card_expiry`)");
                
                $stmt->execute([
                    $staff_id_param, $license_no ?: null, $license_type ?: null, $license_expiry ?: null,
                    $medical_class ?: null, $medical_expiry ?: null, $passport_no ?: null, $passport_expiry ?: null,
                    $visa_details ?: null, $visa_expiry ?: null, $access_card ?: null, $access_expiry ?: null
                ]);
                
                log_activity($_SESSION['user_id'], 'AVIATION_RECORDS_UPDATED_BY_HR', "Updated aviation logs for staff ID $staff_id_param");
                $success = "Aviation records updated successfully.";
            } catch (PDOException $e) {
                $error = "Failed to update aviation records: " . $e->getMessage();
            }
        }
    }
    
    // Redirect
    $redir_url = "staff-profile.php?id=$staff_id_param&" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch Staff Profile Details
try {
    $stmt = $pdo->prepare("SELECT s.*, d.name as department_name, p.title as position_title 
                           FROM `staff` s 
                           LEFT JOIN `departments` d ON s.department_id = d.id 
                           LEFT JOIN `positions` p ON s.position_id = p.id 
                           WHERE s.id = ?");
    $stmt->execute([$staff_id_param]);
    $staff = $stmt->fetch();
    
    if (!$staff) {
        header("Location: staff.php?error=Employee+not+found.");
        exit;
    }
    
    // Load lists for editor
    $departments = $pdo->query("SELECT * FROM `departments` ORDER BY `name` ASC")->fetchAll();
    $raw_positions = $pdo->query("SELECT * FROM `positions` ORDER BY `title` ASC")->fetchAll();
    
    $positions_map = [];
    foreach ($raw_positions as $pos) {
        $positions_map[$pos['department_id']][] = [
            'id' => $pos['id'],
            'title' => $pos['title']
        ];
    }
    
    // Fetch employee documents
    $docs_stmt = $pdo->prepare("SELECT * FROM `documents` WHERE `staff_id` = ? ORDER BY `id` DESC");
    $docs_stmt->execute([$staff_id_param]);
    $documents = $docs_stmt->fetchAll();
    
    // Fetch employee performance & promotions history
    $perf_stmt = $pdo->prepare("SELECT pr.*, s.first_name, s.last_name, s.display_name FROM `performance_reports` pr JOIN `staff` s ON pr.created_by = s.id WHERE pr.staff_id = ? ORDER BY pr.id DESC");
    $perf_stmt->execute([$staff_id_param]);
    $performance_history = $perf_stmt->fetchAll();

    // Fetch employee leaves history
    $leaves_stmt = $pdo->prepare("SELECT * FROM `leave_requests` WHERE `staff_id` = ? ORDER BY `id` DESC");
    $leaves_stmt->execute([$staff_id_param]);
    $leaves_history = $leaves_stmt->fetchAll();

    // Fetch employee disciplinary queries
    $queries_stmt = $pdo->prepare("SELECT * FROM `queries` WHERE `staff_id` = ? ORDER BY `id` DESC");
    $queries_stmt->execute([$staff_id_param]);
    $queries_history = $queries_stmt->fetchAll();

    // Fetch qualifications
    $qual_stmt = $pdo->prepare("SELECT * FROM `qualifications` WHERE `staff_id` = ? ORDER BY `year_obtained` DESC");
    $qual_stmt->execute([$staff_id_param]);
    $qualifications = $qual_stmt->fetchAll();

    // Fetch employment history
    $hist_stmt = $pdo->prepare("SELECT * FROM `employment_history` WHERE `staff_id` = ? ORDER BY `start_date` DESC");
    $hist_stmt->execute([$staff_id_param]);
    $employment_history = $hist_stmt->fetchAll();

    // Fetch assets assigned
    $asset_stmt = $pdo->prepare("SELECT * FROM `asset_assignments` WHERE `staff_id` = ? ORDER BY `assigned_date` DESC");
    $asset_stmt->execute([$staff_id_param]);
    $assets = $asset_stmt->fetchAll();

    // Fetch department transfers
    $trans_stmt = $pdo->prepare("SELECT dt.*, fd.name as from_dept, td.name as to_dept, s.first_name, s.last_name, s.display_name 
                                 FROM `department_transfers` dt 
                                 LEFT JOIN `departments` fd ON dt.from_department_id = fd.id
                                 JOIN `departments` td ON dt.to_department_id = td.id
                                 LEFT JOIN `staff` s ON dt.approved_by = s.id 
                                 WHERE dt.staff_id = ? ORDER BY dt.transfer_date DESC");
    $trans_stmt->execute([$staff_id_param]);
    $transfers = $trans_stmt->fetchAll();

    // Fetch exit record
    $exit_stmt = $pdo->prepare("SELECT er.*, s.first_name, s.last_name, s.display_name 
                                FROM `exit_records` er 
                                LEFT JOIN `staff` s ON er.processed_by = s.id 
                                WHERE er.staff_id = ?");
    $exit_stmt->execute([$staff_id_param]);
    $exit_record = $exit_stmt->fetch();

    // Fetch aviation record details
    $rec_stmt = $pdo->prepare("SELECT * FROM `aviation_records` WHERE `staff_id` = ?");
    $rec_stmt->execute([$staff_id_param]);
    $aviation_record = $rec_stmt->fetch();

    // Fetch active flight schedules (future ones)
    $flights_stmt = $pdo->prepare("SELECT * FROM `flight_schedules` WHERE `staff_id` = ? ORDER BY `departure_time` DESC");
    $flights_stmt->execute([$staff_id_param]);
    $flight_schedules = $flights_stmt->fetchAll();

    // Fetch employee activity logs (Last 20)
    $logs_stmt = $pdo->prepare("SELECT * FROM `activity_logs` WHERE `user_id` = ? ORDER BY `id` DESC LIMIT 20");
    $logs_stmt->execute([$staff_id_param]);
    $activity_history = $logs_stmt->fetchAll();

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-id-card-clip me-2"></i>Staff Profile File</h2>
        <p class="text-muted">Viewing: <strong><?php echo htmlspecialchars(display_name($staff)); ?></strong> (<?php echo htmlspecialchars($staff['staff_id']); ?>)</p>
    </div>
    <div class="col-md-6 text-md-end">
        <a href="staff.php" class="btn btn-outline-aviation me-1">
            <i class="fa-solid fa-arrow-left me-1"></i>Back to Directory
        </a>
        <a href="print-id.php?id=<?php echo $staff['id']; ?>" target="_blank" class="btn btn-aviation">
            <i class="fa-solid fa-print me-1"></i>Print Digital ID Card
        </a>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Quick Profile Info Card -->
    <div class="col-lg-4 col-md-5">
        <div class="card shadow-sm border-0 bg-white text-center p-4 mb-4" style="border-radius: 12px;">
            <div class="position-relative d-inline-block mx-auto mb-3">
                <img src="<?php echo photo_url($staff['passport_photo'] ?? ''); ?>" 
                     class="img-thumbnail shadow" 
                     style="width: 140px; height: 170px; object-fit: cover; border-radius: 10px;" 
                     alt="Passport Photo">
                <span class="position-absolute bottom-0 end-0 badge rounded-pill bg-<?php echo $staff['status'] === 'Active' ? 'success' : ($staff['status'] === 'Suspended' ? 'danger' : 'warning'); ?> p-2 border border-light">
                    <span class="visually-hidden">Status</span>
                </span>
            </div>
            
            <h4 class="fw-bold text-aviation mb-1"><?php echo htmlspecialchars(display_name($staff)); ?></h4>
            <p class="text-uppercase text-secondary fw-semibold mb-3" style="font-size: 0.8rem; letter-spacing: 0.5px;"><?php echo htmlspecialchars($staff['position_title'] ?? 'No Position Assigned'); ?></p>
            
            <hr class="my-3">
            
            <div class="text-start">
                <p class="mb-2"><strong class="text-muted">Staff Number:</strong> <code class="fw-bold fs-6 float-end text-dark"><?php echo htmlspecialchars($staff['staff_id']); ?></code></p>
                <p class="mb-2"><strong class="text-muted">Department:</strong> <span class="float-end text-dark"><?php echo htmlspecialchars($staff['department_name'] ?? 'Unassigned'); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Role:</strong> <span class="badge bg-light text-success border border-success-subtle float-end"><?php echo htmlspecialchars($staff['role']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Status:</strong> <span class="badge bg-light text-<?php echo $staff['status'] === 'Active' ? 'success' : ($staff['status'] === 'Suspended' ? 'danger' : 'warning'); ?> border float-end"><?php echo htmlspecialchars($staff['status']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Employment Date:</strong> <span class="float-end text-dark"><?php echo format_date($staff['employment_date']); ?></span></p>
            </div>
        </div>
        
        <!-- Document Uploads Management Card -->
        <div class="card shadow-sm border-0 bg-white p-3" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-folder-open me-2"></i>Credentials & Documents</h5>
            <?php if (count($documents) > 0): ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($documents as $doc): ?>
                        <li class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="mb-0 fw-semibold" style="font-size:0.85rem;"><?php echo htmlspecialchars($doc['name']); ?></h6>
                                <small class="text-muted"><?php echo htmlspecialchars($doc['type']); ?> | Status: </small>
                                <span class="badge bg-<?php echo $doc['status'] === 'Approved' ? 'success-subtle text-success' : ($doc['status'] === 'Rejected' ? 'danger-subtle text-danger' : 'warning-subtle text-warning'); ?> p-1" style="font-size:0.6rem;">
                                    <?php echo $doc['status']; ?>
                                </span>
                            </div>
                            <div class="d-flex gap-1">
                                <a href="<?php echo get_base_url() . '/' . $doc['file_path']; ?>" target="_blank" class="btn btn-sm btn-light border" title="Download">
                                    <i class="fa-solid fa-file-arrow-down"></i>
                                </a>
                                <?php if ($doc['status'] === 'Pending'): ?>
                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="d-inline">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="doc_id" value="<?php echo $doc['id']; ?>">
                                        <input type="hidden" name="action" value="approve_doc">
                                        <button type="submit" class="btn btn-sm btn-success text-white" title="Approve"><i class="fa-solid fa-check"></i></button>
                                    </form>
                                <?php endif; ?>
                                <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="d-inline" onsubmit="return confirm('Delete this credential? This cannot be undone.');">
                                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                    <input type="hidden" name="doc_id" value="<?php echo $doc['id']; ?>">
                                    <input type="hidden" name="action" value="delete_doc">
                                    <button type="submit" class="btn btn-sm btn-danger text-white" title="Delete"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="text-muted text-center py-3 mb-0" style="font-size:0.85rem;"><i class="fa-solid fa-circle-info me-1"></i>No credentials uploaded yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Interactive Tabs for Edits/History -->
    <div class="col-lg-8 col-md-7">
        <div class="card shadow-sm border-0 bg-white" style="border-radius: 12px; overflow: hidden;">
            <div class="card-header bg-aviation p-0">
                <nav class="nav nav-tabs border-0" id="profileTabs" role="tablist">
                    <button class="nav-link active text-white border-0 py-3 px-3 rounded-0" id="edit-tab" data-bs-toggle="tab" data-bs-target="#edit" type="button" role="tab">
                        <i class="fa-solid fa-user-pen"></i> Edit Profile
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="av-tab" data-bs-toggle="tab" data-bs-target="#aviation" type="button" role="tab">
                        <i class="fa-solid fa-plane"></i> Aviation Logs
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="qual-tab" data-bs-toggle="tab" data-bs-target="#qual" type="button" role="tab">
                        <i class="fa-solid fa-graduation-cap"></i> Qualifications & Assets
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="perf-tab" data-bs-toggle="tab" data-bs-target="#perf" type="button" role="tab">
                        <i class="fa-solid fa-award"></i> Appraisals (<?php echo count($performance_history); ?>)
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="leave-tab" data-bs-toggle="tab" data-bs-target="#leave" type="button" role="tab">
                        <i class="fa-solid fa-clock-rotate-left"></i> Leaves (<?php echo count($leaves_history); ?>)
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="query-tab" data-bs-toggle="tab" data-bs-target="#query" type="button" role="tab">
                        <i class="fa-solid fa-circle-question"></i> Queries
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="trans-tab" data-bs-toggle="tab" data-bs-target="#trans" type="button" role="tab">
                        <i class="fa-solid fa-shuffle"></i> Transfers & Exits
                    </button>
                    <button class="nav-link text-white border-0 py-3 px-3 rounded-0" id="logs-tab" data-bs-toggle="tab" data-bs-target="#logs" type="button" role="tab">
                        <i class="fa-solid fa-timeline"></i> Audit Trail
                    </button>
                </nav>
            </div>
            
            <div class="card-body p-4">
                <div class="tab-content" id="profileTabsContent">
                    
                    <!-- TAB 1: EDIT PROFILE FORM -->
                    <div class="tab-pane fade show active" id="edit" role="tabpanel">
                        <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" enctype="multipart/form-data">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="edit_profile">
                            
                            <h5 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-user me-2"></i>Personal Particulars</h5>
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label" for="first_name">First Name</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($staff['first_name']); ?>" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label" for="other_name">Other Name</label>
                                    <input type="text" class="form-control" id="other_name" name="other_name" value="<?php echo htmlspecialchars($staff['other_name'] ?? ''); ?>" placeholder="Middle name">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label" for="last_name">Last Name</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($staff['last_name']); ?>" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label" for="admin_name_format">Name to Display</label>
                                    <select class="form-select" id="admin_name_format" name="name_display_format">
                                        <?php echo name_format_options($staff['first_name'], $staff['other_name'] ?? '', $staff['last_name'], $staff['name_display_format'] ?? 'first_last'); ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" for="admin_passport_photo">Change Passport Photo (ID card)</label>
                                    <input type="file" class="form-control" id="admin_passport_photo" name="passport_photo" accept="image/jpeg,image/png,image/webp">
                                    <div class="form-text">JPG, PNG or WebP up to 5MB. Used on the ID card.</div>
                                </div>
                            </div>
                            <?php
                            $all_stations = $pdo->query("SELECT `id`, `name`, `type`, `code` FROM `attendance_locations` ORDER BY (`type` = 'Head Office') DESC, `name`")->fetchAll();
                            $my_st = $pdo->prepare("SELECT `location_id` FROM `staff_locations` WHERE `staff_id` = ?");
                            $my_st->execute([$staff['id']]);
                            $my_stations = array_map('intval', $my_st->fetchAll(PDO::FETCH_COLUMN));
                            ?>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <input type="hidden" name="stations_submitted" value="1">
                                    <label class="form-label">Work Station(s) for Attendance</label>
                                    <select class="form-select" name="station_ids[]" multiple size="4">
                                        <?php foreach ($all_stations as $as): ?>
                                            <option value="<?php echo $as['id']; ?>" <?php echo in_array((int)$as['id'], $my_stations, true) ? 'selected' : ''; ?>><?php echo htmlspecialchars($as['name'] . ($as['code'] ? ' (' . $as['code'] . ')' : '')); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">Ctrl/Cmd-click for several. None selected = may clock in at any location.</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Face Registration</label>
                                    <div class="d-flex align-items-center gap-2">
                                        <?php if (!empty($staff['face_photo'])): ?><img src="<?php echo photo_url($staff['face_photo']); ?>" class="rounded border" style="width:56px;height:56px;object-fit:cover;" alt="Registered face"><?php endif; ?>
                                        <div class="small">
                                            <?php if (!empty($staff['face_descriptor'])): ?>
                                                <span class="badge bg-success">Registered</span> <?php echo htmlspecialchars(['registration' => 'at sign-up', 'capture' => 'at first clock-in', 'passport' => 'from passport photo'][$staff['face_source'] ?? ''] ?? ''); ?>
                                                <?php echo $staff['face_enrolled_at'] ? '<br>' . format_datetime($staff['face_enrolled_at']) : ''; ?>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Not registered</span><br>Will register at next clock-in.
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if (!empty($staff['face_descriptor'])): ?>
                                    <div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="reset_face" value="1" id="resetFace"><label class="form-check-label small" for="resetFace">Reset face (staff registers again at next clock-in)</label></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label" for="gender">Gender</label>
                                    <select class="form-select" id="gender" name="gender">
                                        <option value="Male" <?php echo $staff['gender'] === 'Male' ? 'selected' : ''; ?>>Male</option>
                                        <option value="Female" <?php echo $staff['gender'] === 'Female' ? 'selected' : ''; ?>>Female</option>
                                        <option value="Other" <?php echo $staff['gender'] === 'Other' ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" for="dob">Date of Birth</label>
                                    <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $staff['dob']; ?>" required>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label" for="phone">Phone Number</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($staff['phone']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" for="email">Official Email Address</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($staff['email']); ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="address">Residential Address</label>
                                <textarea class="form-control" id="address" name="address" rows="2" required><?php echo htmlspecialchars($staff['address']); ?></textarea>
                            </div>

                            <h5 class="fw-bold text-aviation mb-3 mt-4"><i class="fa-solid fa-briefcase me-2"></i>Employment Profile</h5>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label" for="department">Department</label>
                                    <select class="form-select" id="department" name="department" required>
                                        <option value="">Select Department</option>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?php echo $dept['id']; ?>" <?php echo $staff['department_id'] == $dept['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($dept['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" for="position">Position</label>
                                    <select class="form-select" id="position" name="position" required>
                                        <option value="">Select Department First</option>
                                        <?php 
                                        if ($staff['department_id'] && isset($positions_map[$staff['department_id']])) {
                                            foreach ($positions_map[$staff['department_id']] as $pos) {
                                                $selected = ($staff['position_id'] == $pos['id']) ? 'selected' : '';
                                                echo "<option value='{$pos['id']}' $selected>" . htmlspecialchars($pos['title']) . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label" for="employment_date">Employment Date</label>
                                    <input type="date" class="form-control" id="employment_date" name="employment_date" value="<?php echo $staff['employment_date']; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" for="role">User Role</label>
                                    <select class="form-select" id="role" name="role" required>
                                        <option value="Staff" <?php echo $staff['role'] === 'Staff' ? 'selected' : ''; ?>>Staff</option>
                                        <option value="Department Head" <?php echo $staff['role'] === 'Department Head' ? 'selected' : ''; ?>>Department Head</option>
                                        <option value="HR Officer" <?php echo $staff['role'] === 'HR Officer' ? 'selected' : ''; ?>>HR Officer</option>
                                        <option value="HR Manager" <?php echo $staff['role'] === 'HR Manager' ? 'selected' : ''; ?>>HR Manager</option>
                                        <option value="HR Director" <?php echo $staff['role'] === 'HR Director' ? 'selected' : ''; ?>>HR Director</option>
                                        <option value="Managing Director" <?php echo $staff['role'] === 'Managing Director' ? 'selected' : ''; ?>>Managing Director</option>
                                        <option value="Finance Officer" <?php echo $staff['role'] === 'Finance Officer' ? 'selected' : ''; ?>>Finance Officer</option>
                                        <option value="Super Admin" <?php echo $staff['role'] === 'Super Admin' ? 'selected' : ''; ?>>Super Admin</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="emergency_contact">Emergency Contact Info</label>
                                <textarea class="form-control" id="emergency_contact" name="emergency_contact" rows="2" required><?php echo htmlspecialchars($staff['emergency_contact']); ?></textarea>
                            </div>

                            <h5 class="fw-bold text-aviation mb-3 mt-4"><i class="fa-solid fa-key me-2"></i>Account Security</h5>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold" for="new_password">Change Password</label>
                                    <input type="text" class="form-control" id="new_password" name="new_password" placeholder="Enter new password to change">
                                </div>
                            </div>
                            
                            <hr class="my-4">
                            <div class="text-end">
                                <button type="submit" class="btn btn-aviation"><i class="fa-solid fa-floppy-disk me-1"></i>Save All Changes</button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- TAB 2: AVIATION RECORDS & FLIGHT TIMELINE -->
                    <div class="tab-pane fade" id="aviation" role="tabpanel">
                        <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="mb-4">
                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                            <input type="hidden" name="action" value="update_aviation_records">
                            
                            <h5 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-passport me-2"></i>Aviation Credentials Dashboard</h5>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Passport Number</label>
                                    <input type="text" class="form-control" name="passport_number" value="<?php echo htmlspecialchars($aviation_record['passport_number'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Passport Expiry</label>
                                    <input type="date" class="form-control" name="passport_expiry" value="<?php echo $aviation_record['passport_expiry'] ?? ''; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Visa Details</label>
                                    <input type="text" class="form-control" name="visa_details" value="<?php echo htmlspecialchars($aviation_record['visa_details'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Visa Expiry</label>
                                    <input type="date" class="form-control" name="visa_expiry" value="<?php echo $aviation_record['visa_expiry'] ?? ''; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label">License Number</label>
                                    <input type="text" class="form-control" name="license_number" value="<?php echo htmlspecialchars($aviation_record['license_number'] ?? ''); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">License Type</label>
                                    <select class="form-select" name="license_type">
                                        <option value="">Choose Licence</option>
                                        <option value="ATPL" <?php echo ($aviation_record && $aviation_record['license_type'] === 'ATPL') ? 'selected' : ''; ?>>ATPL (Airline Transport Pilot)</option>
                                        <option value="CPL" <?php echo ($aviation_record && $aviation_record['license_type'] === 'CPL') ? 'selected' : ''; ?>>CPL (Commercial Pilot)</option>
                                        <option value="Cabin Crew Licence" <?php echo ($aviation_record && $aviation_record['license_type'] === 'Cabin Crew Licence') ? 'selected' : ''; ?>>Cabin Crew Licence</option>
                                        <option value="Dispatcher Licence" <?php echo ($aviation_record && $aviation_record['license_type'] === 'Dispatcher Licence') ? 'selected' : ''; ?>>Dispatcher Licence</option>
                                        <option value="Other" <?php echo ($aviation_record && $aviation_record['license_type'] === 'Other') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">License Expiry</label>
                                    <input type="date" class="form-control" name="license_expiry" value="<?php echo $aviation_record['license_expiry'] ?? ''; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Medical Class</label>
                                    <select class="form-select" name="medical_class">
                                        <option value="">Select Medical Class</option>
                                        <option value="Class 1" <?php echo ($aviation_record && $aviation_record['medical_class'] === 'Class 1') ? 'selected' : ''; ?>>Class 1 (Pilot)</option>
                                        <option value="Class 2" <?php echo ($aviation_record && $aviation_record['medical_class'] === 'Class 2') ? 'selected' : ''; ?>>Class 2 (Cabin Crew)</option>
                                        <option value="Class 3" <?php echo ($aviation_record && $aviation_record['medical_class'] === 'Class 3') ? 'selected' : ''; ?>>Class 3 (ATC/Dispatch)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Medical Expiry</label>
                                    <input type="date" class="form-control" name="medical_expiry" value="<?php echo $aviation_record['medical_expiry'] ?? ''; ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Airport Access Card No</label>
                                    <input type="text" class="form-control" name="airport_access_card_no" value="<?php echo htmlspecialchars($aviation_record['airport_access_card_no'] ?? ''); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Airport Access Card Expiry</label>
                                    <input type="date" class="form-control" name="airport_access_card_expiry" value="<?php echo $aviation_record['airport_access_card_expiry'] ?? ''; ?>">
                                </div>
                            </div>
                            
                            <div class="text-end">
                                <button type="submit" class="btn btn-sm btn-aviation"><i class="fa-solid fa-floppy-disk me-1"></i>Save Aviation Data</button>
                            </div>
                        </form>
                        
                        <h6 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-plane-departure me-1"></i>Flight Roster & Logs</h6>
                        <?php if (count($flight_schedules) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover mb-0" style="font-size:0.85rem;">
                                    <thead>
                                        <tr>
                                            <th>Flight No</th>
                                            <th>Route</th>
                                            <th>Departure</th>
                                            <th>Arrival</th>
                                            <th>Roster Role</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($flight_schedules as $f): ?>
                                            <tr>
                                                <td class="fw-bold"><code><?php echo htmlspecialchars($f['flight_number']); ?></code></td>
                                                <td><code><?php echo htmlspecialchars($f['departure_airport']); ?></code> -> <code><?php echo htmlspecialchars($f['arrival_airport']); ?></code></td>
                                                <td><?php echo format_datetime($f['departure_time']); ?></td>
                                                <td><?php echo format_datetime($f['arrival_time']); ?></td>
                                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($f['role_on_flight'] ?: 'Crew Member'); ?></span></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $f['status'] === 'Completed' ? 'success' : ($f['status'] === 'Cancelled' ? 'danger' : 'warning'); ?>">
                                                        <?php echo $f['status']; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted small text-center py-3 mb-0">No flight logs on schedule for this crew member.</p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- TAB 3: QUALIFICATIONS, EXPERIENCE & ASSETS -->
                    <div class="tab-pane fade" id="qual" role="tabpanel">
                        <!-- Add qualification form -->
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="p-3 bg-light rounded border mb-3">
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3">Add Academic / Qualification</h6>
                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="action" value="add_qualification">
                                        <div class="mb-2">
                                            <input type="text" class="form-control form-control-sm" name="qualification_name" placeholder="Qualification (e.g. B.Sc Aviation)" required>
                                        </div>
                                        <div class="mb-2">
                                            <input type="text" class="form-control form-control-sm" name="institution" placeholder="Institution/Academy" required>
                                        </div>
                                        <div class="row g-2 mb-2">
                                            <div class="col-8">
                                                <input type="text" class="form-control form-control-sm" name="field_of_study" placeholder="Field of Study">
                                            </div>
                                            <div class="col-4">
                                                <input type="number" class="form-control form-control-sm" name="year_obtained" placeholder="Year" required>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-aviation w-100 py-1"><i class="fa-solid fa-plus me-1"></i>Add Qualification</button>
                                    </form>
                                    
                                    <div class="mt-3" style="max-height: 200px; overflow-y: auto;">
                                        <?php if (count($qualifications) > 0): ?>
                                            <div class="list-group list-group-flush small">
                                                <?php foreach ($qualifications as $q): ?>
                                                    <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <strong class="text-dark"><?php echo htmlspecialchars($q['qualification_name']); ?></strong>
                                                            <br><small class="text-secondary"><?php echo htmlspecialchars($q['institution']); ?> | <?php echo $q['year_obtained']; ?></small>
                                                        </div>
                                                        <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="d-inline" onsubmit="return confirm('Delete qualification?');">
                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                            <input type="hidden" name="q_id" value="<?php echo $q['id']; ?>">
                                                            <input type="hidden" name="action" value="delete_qualification">
                                                            <button type="submit" class="btn btn-sm btn-link text-danger p-0"><i class="fa-solid fa-trash"></i></button>
                                                        </form>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-muted small text-center mb-0 py-2">No qualifications logged.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Experience History -->
                                <div class="p-3 bg-light rounded border">
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3">Add Employment History</h6>
                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="action" value="add_experience">
                                        <div class="mb-2">
                                            <input type="text" class="form-control form-control-sm" name="company_name" placeholder="Company Name" required>
                                        </div>
                                        <div class="mb-2">
                                            <input type="text" class="form-control form-control-sm" name="position" placeholder="Job Title / Position" required>
                                        </div>
                                        <div class="row g-2 mb-2">
                                            <div class="col-6">
                                                <input type="date" class="form-control form-control-sm" name="start_date" placeholder="Start Date" required>
                                            </div>
                                            <div class="col-6">
                                                <input type="date" class="form-control form-control-sm" name="end_date" placeholder="End Date (Optional)">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-aviation w-100 py-1"><i class="fa-solid fa-plus me-1"></i>Add Experience</button>
                                    </form>
                                    
                                    <div class="mt-3" style="max-height: 200px; overflow-y: auto;">
                                        <?php if (count($employment_history) > 0): ?>
                                            <div class="list-group list-group-flush small">
                                                <?php foreach ($employment_history as $h): ?>
                                                    <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <strong class="text-dark"><?php echo htmlspecialchars($h['position']); ?></strong> at <strong class="text-aviation"><?php echo htmlspecialchars($h['company_name']); ?></strong>
                                                            <br><small class="text-secondary"><?php echo format_date($h['start_date']); ?> - <?php echo $h['end_date'] ? format_date($h['end_date']) : 'Present'; ?></small>
                                                        </div>
                                                        <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="d-inline" onsubmit="return confirm('Delete history?');">
                                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                            <input type="hidden" name="exp_id" value="<?php echo $h['id']; ?>">
                                                            <input type="hidden" name="action" value="delete_experience">
                                                            <button type="submit" class="btn btn-sm btn-link text-danger p-0"><i class="fa-solid fa-trash"></i></button>
                                                        </form>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <p class="text-muted small text-center mb-0 py-2">No work history logged.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Assets Assignment -->
                            <div class="col-md-6">
                                <div class="p-3 bg-light rounded border h-100">
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3"><i class="fa-solid fa-laptop-medical me-1"></i>Assign Company Asset</h6>
                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="mb-3">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="action" value="assign_asset">
                                        <div class="row g-2 mb-2">
                                            <div class="col-6">
                                                <input type="text" class="form-control form-control-sm" name="asset_name" placeholder="Asset Name (e.g. Laptop)" required>
                                            </div>
                                            <div class="col-6">
                                                <input type="text" class="form-control form-control-sm" name="asset_code" placeholder="Asset Code / ID" required>
                                            </div>
                                        </div>
                                        <div class="row g-2 mb-2">
                                            <div class="col-6">
                                                <input type="text" class="form-control form-control-sm" name="category" placeholder="Category (e.g. IT)">
                                            </div>
                                            <div class="col-6">
                                                <input type="text" class="form-control form-control-sm" name="serial_number" placeholder="Serial Number">
                                            </div>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Assigned Date</label>
                                            <input type="date" class="form-control form-control-sm" name="assigned_date" value="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-aviation w-100 py-1"><i class="fa-solid fa-plus me-1"></i>Assign Asset</button>
                                    </form>
                                    
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-2">Assigned Asset Inventory</h6>
                                    <?php if (count($assets) > 0): ?>
                                        <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                                            <table class="table table-striped table-hover table-sm mb-0" style="font-size:0.75rem;">
                                                <thead>
                                                    <tr>
                                                        <th>Asset</th>
                                                        <th>Code</th>
                                                        <th>Assigned</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($assets as $ast): ?>
                                                        <tr>
                                                            <td><strong><?php echo htmlspecialchars($ast['asset_name']); ?></strong></td>
                                                            <td><code><?php echo htmlspecialchars($ast['asset_code']); ?></code></td>
                                                            <td><?php echo format_date($ast['assigned_date']); ?></td>
                                                            <td>
                                                                <span class="badge bg-<?php echo $ast['status'] === 'Assigned' ? 'success' : 'secondary'; ?>">
                                                                    <?php echo $ast['status']; ?>
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <?php if ($ast['status'] === 'Assigned'): ?>
                                                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>" class="d-inline">
                                                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                                                        <input type="hidden" name="asset_id" value="<?php echo $ast['id']; ?>">
                                                                        <input type="hidden" name="action" value="return_asset">
                                                                        <button type="submit" class="btn btn-sm btn-outline-success py-0 px-1" title="Mark Returned"><i class="fa-solid fa-rotate-left"></i></button>
                                                                    </form>
                                                                <?php else: ?>
                                                                    <small class="text-muted">Returned</small>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted small text-center mb-0">No assets currently assigned.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- TAB 4: PERFORMANCE & APPRAISAL HISTORY -->
                    <div class="tab-pane fade" id="perf" role="tabpanel">
                        <h5 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-award me-2"></i>Performance History & Appraisals</h5>
                        <?php if (count($performance_history) > 0): ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($performance_history as $perf): ?>
                                    <div class="list-group-item px-0 py-3">
                                        <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                                            <h6 class="mb-0 fw-bold text-aviation"><?php echo htmlspecialchars($perf['title']); ?></h6>
                                            <small class="text-muted"><?php echo format_date($perf['created_at']); ?></small>
                                        </div>
                                        <div class="mb-2">
                                            <span class="badge bg-success"><?php echo $perf['type']; ?></span>
                                            <?php if ($perf['rating']): ?>
                                                <span class="text-warning ms-2">
                                                    <?php echo str_repeat('<i class="fa-solid fa-star text-warning"></i>', $perf['rating']); ?>
                                                    <?php echo str_repeat('<i class="fa-regular fa-star"></i>', 5 - $perf['rating']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="text-muted small mb-1"><?php echo nl2br(htmlspecialchars($perf['details'])); ?></p>
                                        <small class="text-secondary">Issued by: <?php echo htmlspecialchars(display_name($perf)); ?></small>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">No performance records or appraisals found.</p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- TAB 5: LEAVE HISTORY -->
                    <div class="tab-pane fade" id="leave" role="tabpanel">
                        <h5 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-calendar-days me-2"></i>Leave Records</h5>
                        <?php if (count($leaves_history) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover mb-0" style="font-size:0.85rem;">
                                    <thead>
                                        <tr>
                                            <th>Type</th>
                                            <th>Duration</th>
                                            <th>Start</th>
                                            <th>End</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($leaves_history as $l_rec): ?>
                                            <tr>
                                                <td><strong><?php echo $l_rec['leave_type']; ?></strong></td>
                                                <td><?php echo $l_rec['duration']; ?> Days</td>
                                                <td><?php echo format_date($l_rec['start_date']); ?></td>
                                                <td><?php echo format_date($l_rec['end_date']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $l_rec['status'] === 'Approved' ? 'success' : ($l_rec['status'] === 'Rejected' ? 'danger' : 'warning'); ?>">
                                                        <?php echo $l_rec['status']; ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">No leave history found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- TAB 6: DISCIPLINARY QUERIES -->
                    <div class="tab-pane fade" id="query" role="tabpanel">
                        <h5 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-triangle-exclamation me-2"></i>Issued Queries & Warnings</h5>
                        <?php if (count($queries_history) > 0): ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($queries_history as $q): ?>
                                    <div class="list-group-item px-0 py-3">
                                        <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                                            <h6 class="mb-0 fw-bold text-danger"><?php echo htmlspecialchars($q['title']); ?></h6>
                                            <span class="badge bg-<?php echo $q['status'] === 'Resolved' ? 'success' : ($q['status'] === 'Replied' ? 'info' : ($q['status'] === 'Escalated' ? 'danger' : 'warning')); ?>">
                                                <?php echo $q['status']; ?>
                                            </span>
                                        </div>
                                        <p class="text-muted small mb-1"><strong>Reason:</strong> <?php echo htmlspecialchars($q['reason']); ?></p>
                                        <p class="text-muted small mb-2"><?php echo nl2br(htmlspecialchars($q['description'])); ?></p>
                                        <small class="text-secondary">Deadline: <span class="text-danger fw-bold"><?php echo format_date($q['deadline']); ?></span></small>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">No disciplinary queries issued.</p>
                        <?php endif; ?>
                    </div>

                    <!-- TAB 7: TRANSFERS & EXITS -->
                    <div class="tab-pane fade" id="trans" role="tabpanel">
                        <div class="row g-3">
                            <!-- Department Transfer -->
                            <div class="col-md-6">
                                <div class="p-3 bg-light rounded border mb-3">
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3"><i class="fa-solid fa-arrows-left-right me-1"></i>Process Department Transfer</h6>
                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="action" value="transfer_dept">
                                        <input type="hidden" name="from_dept_id" value="<?php echo $staff['department_id']; ?>">
                                        
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Current Department</label>
                                            <input type="text" class="form-control form-control-sm bg-light" value="<?php echo htmlspecialchars($staff['department_name'] ?? 'Unassigned'); ?>" readonly>
                                        </div>
                                        
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Transfer to *</label>
                                            <select class="form-select form-select-sm" name="to_dept_id" required>
                                                <option value="">Choose Department</option>
                                                <?php foreach ($departments as $d): ?>
                                                    <?php if ($d['id'] != $staff['department_id']): ?>
                                                        <option value="<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Transfer Effective Date *</label>
                                            <input type="date" class="form-control form-control-sm" name="transfer_date" value="<?php echo date('Y-m-d'); ?>" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Transfer Reasons</label>
                                            <textarea class="form-control form-control-sm" name="reason" rows="2" placeholder="Transfer rationale..."></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-aviation w-100 py-1"><i class="fa-solid fa-shuffle me-1"></i>Transfer Staff Member</button>
                                    </form>
                                    
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-2 mt-3">Transfer Logs</h6>
                                    <?php if (count($transfers) > 0): ?>
                                        <ul class="list-group list-group-flush small" style="max-height: 150px; overflow-y: auto;">
                                            <?php foreach ($transfers as $t): ?>
                                                <li class="list-group-item px-0 py-2">
                                                    <strong><?php echo htmlspecialchars($t['from_dept'] ?: 'Unassigned'); ?></strong> <i class="fa-solid fa-right-long text-success mx-1"></i> <strong><?php echo htmlspecialchars($t['to_dept']); ?></strong>
                                                    <br><small class="text-muted">Date: <?php echo format_date($t['transfer_date']); ?> | By: <?php echo htmlspecialchars(display_name($t)); ?></small>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-muted small text-center mb-0">No historical department transfers logged.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Exit Record Clearance -->
                            <div class="col-md-6">
                                <div class="p-3 bg-light rounded border h-100">
                                    <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3"><i class="fa-solid fa-door-open me-1"></i>Process Staff Exit Clearance</h6>
                                    <form method="POST" action="staff-profile.php?id=<?php echo $staff['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="action" value="process_exit">
                                        
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Exit Date *</label>
                                            <input type="date" class="form-control form-control-sm" name="exit_date" value="<?php echo $exit_record ? $exit_record['exit_date'] : date('Y-m-d'); ?>" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Exit Type *</label>
                                            <select class="form-select form-select-sm" name="exit_type" required>
                                                <option value="Resigned" <?php echo ($exit_record && $exit_record['exit_type'] === 'Resigned') ? 'selected' : ''; ?>>Resigned</option>
                                                <option value="Terminated" <?php echo ($exit_record && $exit_record['exit_type'] === 'Terminated') ? 'selected' : ''; ?>>Terminated</option>
                                                <option value="Retired" <?php echo ($exit_record && $exit_record['exit_type'] === 'Retired') ? 'selected' : ''; ?>>Retired</option>
                                                <option value="Deceased" <?php echo ($exit_record && $exit_record['exit_type'] === 'Deceased') ? 'selected' : ''; ?>>Deceased</option>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Clearance Status</label>
                                            <select class="form-select form-select-sm" name="clearance_status">
                                                <option value="Pending" <?php echo ($exit_record && $exit_record['clearance_status'] === 'Pending') ? 'selected' : ''; ?>>Pending Clearance</option>
                                                <option value="Cleared" <?php echo ($exit_record && $exit_record['clearance_status'] === 'Cleared') ? 'selected' : ''; ?>>Cleared (No Liability)</option>
                                                <option value="Rejected" <?php echo ($exit_record && $exit_record['clearance_status'] === 'Rejected') ? 'selected' : ''; ?>>Rejected / Holds Asset Liability</option>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Clearance Remarks</label>
                                            <textarea class="form-control form-control-sm" name="remarks" rows="2" placeholder="Clearance details, assets checklist..."><?php echo $exit_record ? htmlspecialchars($exit_record['remarks']) : ''; ?></textarea>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label small mb-0">Reason for Exit</label>
                                            <textarea class="form-control form-control-sm" name="reason" rows="2" placeholder="Reason..."><?php echo $exit_record ? htmlspecialchars($exit_record['reason']) : ''; ?></textarea>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-sm btn-danger w-100 py-1"><i class="fa-solid fa-user-xmark me-1"></i>Process Exit File</button>
                                    </form>
                                    
                                    <?php if ($exit_record): ?>
                                        <div class="mt-3 p-2 bg-warning-subtle text-warning-emphasis border rounded small">
                                            <i class="fa-solid fa-info me-1"></i> Staff exit cleared by: <strong><?php echo htmlspecialchars(display_name($exit_record)); ?></strong> on <?php echo format_date($exit_record['created_at']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 8: AUDIT TIMELINE -->
                    <div class="tab-pane fade" id="logs" role="tabpanel">
                        <h5 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-timeline me-2"></i>Audit Timeline</h5>
                        <?php if (count($activity_history) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover mb-0" style="font-size:0.85rem;">
                                    <thead>
                                        <tr>
                                            <th>Timestamp</th>
                                            <th>Action</th>
                                            <th>Details</th>
                                            <th>IP Address</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($activity_history as $log): ?>
                                            <tr>
                                                <td><?php echo format_datetime($log['created_at']); ?></td>
                                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($log['action']); ?></span></td>
                                                <td><?php echo htmlspecialchars($log['details']); ?></td>
                                                <td><code><?php echo htmlspecialchars($log['ip_address']); ?></code></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted text-center py-4 mb-0">No activity logs found for this staff member.</p>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Inject dynamic positions map in JS -->
<script>
    const positionsMap = <?php echo json_encode($positions_map); ?>;
    
    document.getElementById('department').addEventListener('change', function() {
        const deptId = this.value;
        const positionSelect = document.getElementById('position');
        
        positionSelect.innerHTML = '';
        
        if (deptId && positionsMap[deptId]) {
            // Add default select option
            const defaultOpt = document.createElement('option');
            defaultOpt.value = '';
            defaultOpt.textContent = 'Select Position';
            positionSelect.appendChild(defaultOpt);
            
            positionsMap[deptId].forEach(pos => {
                const opt = document.createElement('option');
                opt.value = pos.id;
                opt.textContent = pos.title;
                positionSelect.appendChild(opt);
            });
        } else {
            const defaultOpt = document.createElement('option');
            defaultOpt.value = '';
            defaultOpt.textContent = 'Select Department First';
            positionSelect.appendChild(defaultOpt);
        }
    });
</script>

<?php require_once '../includes/footer.php'; ?>
