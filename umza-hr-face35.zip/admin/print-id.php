<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff ID Card Print View & Generator
 */

require_once '../includes/auth.php';
require_feature('id_card');

// Get and validate requested employee ID
$staff_id_param = intval($_GET['id'] ?? 0);
if ($staff_id_param <= 0) {
    die("Error: Invalid employee selected.");
}

// Allow HR Admin roles OR the staff member printing their own card
require_login();
$current_user_id = $_SESSION['user_id'];
$current_user_role = $_SESSION['role'];

if (!is_hr_role($current_user_role) && (int)$current_user_id !== $staff_id_param) {
    header("Location: " . get_base_url() . "/index.php?error=unauthorized");
    exit;
}

try {
    // 1. Fetch staff details and ID credentials
    $stmt = $pdo->prepare("SELECT s.*, d.name as department_name, p.title as position_title, 
                                  sid.verification_token, sid.issue_date, sid.expiry_date, sid.status as id_status 
                           FROM `staff` s 
                           LEFT JOIN `staff_ids` sid ON s.id = sid.staff_id 
                           LEFT JOIN `departments` d ON s.department_id = d.id 
                           LEFT JOIN `positions` p ON s.position_id = p.id 
                           WHERE s.id = ?");
    $stmt->execute([$staff_id_param]);
    $staff = $stmt->fetch();
    
    if (!$staff) {
        die("Error: Employee not found.");
    }
    
    // 2. Generate ID Card Token dynamically if not exists (lazy initialization for safety)
    if (empty($staff['verification_token'])) {
        $verify_token = bin2hex(random_bytes(16));
        $issue_date = date('Y-m-d');
        $validity_years = intval(get_setting('id_card_validity_years', 3));
        $expiry_date = date('Y-m-d', strtotime("+$validity_years years"));
        
        $id_stmt = $pdo->prepare("INSERT INTO `staff_ids` (`staff_id`, `verification_token`, `issue_date`, `expiry_date`, `status`) 
                                  VALUES (?, ?, ?, ?, 'Active')");
        $id_stmt->execute([$staff_id_param, $verify_token, $issue_date, $expiry_date]);
        
        // Re-fetch staff details
        $stmt->execute([$staff_id_param]);
        $staff = $stmt->fetch();
    }
    
    // 3. Construct the verification link
    $verify_url = get_base_url() . "/verify-id.php?token=" . $staff['verification_token'];

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print ID Card - <?php echo htmlspecialchars(display_name($staff)); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
    <!-- QR Code Script -->
    <script src="../libs/qrcode/qrcode.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<script src="../assets/js/id-card-save.js?v=<?php echo get_asset_version('assets/js/id-card-save.js'); ?>"></script>
    <style>
        body {
            background-color: #f0f2f5;
            padding: 2rem 0;
        }
        .control-panel {
            max-width: 380px;
            margin: 0 auto 1.5rem auto;
        }
    </style>
</head>
<body>

    <!-- Print control panel (hidden on actual print) -->
    <div class="control-panel no-print">
        <div class="card shadow-sm p-3 bg-white text-center" style="border-radius:12px;">
            <h6 class="fw-bold text-aviation mb-3"><i class="fa-solid fa-print me-1"></i>ID Card Print Options</h6>
            <div class="d-flex gap-2">
                <button onclick="window.print();" class="btn btn-aviation w-100"><i class="fa-solid fa-print me-1"></i>Print</button>
                <button onclick="saveIdCards('<?php echo htmlspecialchars(preg_replace('/[^A-Za-z0-9_-]/', '', $staff['staff_id'])); ?>-id-card');" class="btn btn-success w-100"><i class="fa-solid fa-image me-1"></i>Save Image</button>
                <button onclick="window.close();" class="btn btn-outline-secondary w-100">Close Window</button>
            </div>
        </div>
    </div>

    <!-- ID Card Container -->
    <div class="id-card-print-container d-flex flex-wrap justify-content-center gap-4">
        <!-- FRONT CARD -->
        <div class="id-card my-3 shadow-lg">
            <!-- Header -->
            <div class="id-card-header">
                <img src="<?php echo get_base_url(); ?>/assets/images/logo.jpg" alt="Logo" class="id-card-logo">
                <div class="id-card-title-group">
                    <div class="id-card-company-name">UMZA</div>
                    <div class="id-card-company-sub">AVIATION SERVICES LTD.</div>
                </div>
            </div>
            
            <!-- Photo and details side-by-side row -->
            <div class="id-card-row">
                <!-- Photo Column -->
                <div class="id-card-col-left">
                    <img src="<?php echo photo_url($staff['passport_photo'] ?? ''); ?>" 
                         class="id-card-photo" 
                         alt="Passport Photo">
                </div>
                <!-- Details Column -->
                <div class="id-card-col-right">
                    <div class="id-card-name"><?php echo htmlspecialchars(display_name($staff)); ?></div>
                    <div class="id-card-role"><?php echo htmlspecialchars($staff['position_title'] ?? 'Crew Member'); ?></div>
                    
                    <table class="id-card-info-table">
                        <tr>
                            <td class="id-card-info-label">Staff No:</td>
                            <td class="id-card-info-val"><?php echo htmlspecialchars($staff['staff_id']); ?></td>
                        </tr>
                        <tr>
                            <td class="id-card-info-label">Department:</td>
                            <td class="id-card-info-val"><?php echo htmlspecialchars($staff['department_name'] ?? 'Operations'); ?></td>
                        </tr>
                        <tr>
                            <td class="id-card-info-label">Issue Date:</td>
                            <td class="id-card-info-val"><?php echo format_date($staff['issue_date']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- QR Code & Status area (bottom center) -->
            <div class="id-card-qr-area">
                <div id="qrcode" class="id-card-qr"></div>
                <div>
                    <span class="id-card-status-badge <?php echo strtolower($staff['id_status']) === 'active' ? 'status-active' : 'status-suspended'; ?>">
                        <?php echo htmlspecialchars($staff['id_status']); ?>
                    </span>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="id-card-footer">
                If found, please return to UMZA Aviation Services HQ.
                <br>Security Verification QR code protected.
            </div>
        </div>

        <!-- BACK CARD -->
        <div class="id-card id-card-back my-3 shadow-lg">
            <!-- Back Header -->
            <div class="id-card-header">
                <img src="<?php echo get_base_url(); ?>/assets/images/logo.jpg" alt="Logo" class="id-card-logo">
                <div class="id-card-title-group">
                    <div class="id-card-company-name">UMZA</div>
                    <div class="id-card-company-sub">AVIATION SERVICES LTD.</div>
                </div>
            </div>

            <div class="id-card-back-body">
                <!-- Return Address Block -->
                <div class="id-card-back-terms">
                    <strong>If found, return to:</strong>
                    <div class="address-text">Area 11, Suite D1, UYK HEXAHUB Building, Garki, FCT.</div>
                </div>

                <!-- Health & Emergency metadata card -->
                <div class="id-card-back-meta">
                    <?php
                    $em_contact = $staff['emergency_contact'] ?? '';
                    $em_name = $em_contact;
                    $em_phone = '07047000674';
                    
                    if (strpos($em_contact, ':') !== false) {
                        $parts = explode(':', $em_contact);
                        $em_name = trim($parts[0]);
                        $em_phone = trim($parts[1]);
                    } else {
                        if (preg_match('/^(.*?)\s*([\+\d\s-]+)$/', $em_contact, $matches)) {
                            $em_name = trim($matches[1]);
                            $em_phone = trim($matches[2]);
                        }
                    }
                    ?>
                    <table class="id-card-back-table">
                        <tr>
                            <td class="meta-label">Blood Group:</td>
                            <td class="meta-val"><?php echo htmlspecialchars($staff['blood_group'] ?: 'N/A'); ?></td>
                        </tr>
                        <tr>
                            <td class="meta-label">Allergies:</td>
                            <td class="meta-val text-danger fw-bold"><?php echo htmlspecialchars($staff['allergies'] ?: 'N/A'); ?></td>
                        </tr>
                        <tr>
                            <td class="meta-label">Emergency Contact:</td>
                            <td class="meta-val">
                                <strong><?php echo htmlspecialchars($em_name ?: 'HR Dept'); ?></strong>
                                <br>
                                <span class="small-text"><?php echo htmlspecialchars($em_phone); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td class="meta-label">Contact Phone:</td>
                            <td class="meta-val">07047000674</td>
                        </tr>
                    </table>
                </div>

                <!-- Barcode Area -->
                <div class="id-card-barcode-area">
                    <div class="barcode-lines"></div>
                    <div class="barcode-text"><?php echo htmlspecialchars($staff['staff_id']); ?></div>
                </div>

                <!-- Signature Area -->
                <div class="id-card-signature-area">
                    <?php 
                    $sig_img = get_setting('id_card_signature_image');
                    $sig_name = get_setting('id_card_signature_name', 'Abubakar M. Natiti');
                    $sig_title = get_setting('id_card_signature_title', 'HEAD HUMAN RESOURCES');
                    
                    if (!empty($sig_img)): 
                    ?>
                        <img src="<?php echo photo_url($sig_img); ?>" alt="Signature">
                    <?php else: ?>
                        <div class="signature-font"><?php echo htmlspecialchars($sig_name); ?></div>
                    <?php endif; ?>
                    <small class="block-text text-uppercase"><?php echo htmlspecialchars($sig_name) . ' (' . htmlspecialchars($sig_title) . ')'; ?></small>
                </div>
            </div>

            <!-- Back Footer -->
            <div class="id-card-footer mt-auto">
                Contact: contact@umzaair.com Tel: 07047000674
            </div>
        </div>
    </div>

    <!-- Initialize Client Side QR Code -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const qrcodeContainer = document.getElementById("qrcode");
            const verificationUrl = "<?php echo $verify_url; ?>";
            
            new QRCode(qrcodeContainer, {
                text: verificationUrl,
                width: 115,
                height: 115,
                colorDark : "#000000",
                colorLight : "#ffffff",
                correctLevel : QRCode.CorrectLevel.M
            });
        });
    </script>
</body>
</html>
