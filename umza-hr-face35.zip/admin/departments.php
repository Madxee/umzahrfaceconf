<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Departments & Positions Manager (add, rename, remove, assign Head of Department)
 */

require_once '../includes/auth.php';
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);

$user_id = $_SESSION['user_id'];

function back($ok, $msg, $anchor = '') {
    header("Location: departments.php?" . ($ok ? 'success=' : 'error=') . urlencode($msg) . ($anchor ? "#$anchor" : ''));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        back(false, 'Security validation failed. Please try again.');
    }
    $action = $_POST['action'] ?? '';
    $dept_id = intval($_POST['dept_id'] ?? 0);
    $pos_id = intval($_POST['pos_id'] ?? 0);

    try {
        switch ($action) {
            case 'add_department':
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                if ($name === '') back(false, 'Department name is required.');
                $chk = $pdo->prepare("SELECT id FROM `departments` WHERE `name` = ?");
                $chk->execute([$name]);
                if ($chk->fetch()) back(false, "A department called \"$name\" already exists.");
                $pdo->prepare("INSERT INTO `departments` (`name`, `description`) VALUES (?, ?)")->execute([$name, $desc ?: null]);
                $new_id = $pdo->lastInsertId();
                // Optional first positions, one per line or comma separated
                $titles = preg_split('/[\r\n,]+/', $_POST['positions'] ?? '');
                $ins = $pdo->prepare("INSERT INTO `positions` (`title`, `department_id`) VALUES (?, ?)");
                foreach (array_unique(array_filter(array_map('trim', $titles))) as $t) {
                    $ins->execute([$t, $new_id]);
                }
                log_activity($user_id, 'DEPARTMENT_CREATED', "Created department: $name");
                back(true, "Department \"$name\" created.", "dept-$new_id");

            case 'rename_department':
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                if ($name === '' || !$dept_id) back(false, 'Department name is required.');
                $chk = $pdo->prepare("SELECT id FROM `departments` WHERE `name` = ? AND id <> ?");
                $chk->execute([$name, $dept_id]);
                if ($chk->fetch()) back(false, "Another department is already called \"$name\".");
                $pdo->prepare("UPDATE `departments` SET `name` = ?, `description` = ? WHERE `id` = ?")->execute([$name, $desc ?: null, $dept_id]);
                log_activity($user_id, 'DEPARTMENT_UPDATED', "Updated department #$dept_id: $name");
                back(true, "Department updated.", "dept-$dept_id");

            case 'delete_department':
                $move_to = intval($_POST['move_to'] ?? 0);
                $cnt = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `department_id` = ?");
                $cnt->execute([$dept_id]);
                $staff_count = (int)$cnt->fetchColumn();
                if ($staff_count > 0 && (!$move_to || $move_to === $dept_id)) {
                    back(false, "This department still has $staff_count staff. Choose another department to move them to first.", "dept-$dept_id");
                }
                $pdo->beginTransaction();
                if ($staff_count > 0) {
                    // Staff keep their job title if a position with the same title exists in the new department
                    $pdo->prepare("UPDATE `staff` s LEFT JOIN `positions` op ON op.id = s.position_id
                                   LEFT JOIN `positions` np ON np.department_id = ? AND np.title = op.title
                                   SET s.department_id = ?, s.position_id = np.id
                                   WHERE s.department_id = ?")->execute([$move_to, $move_to, $dept_id]);
                }
                $name = $pdo->prepare("SELECT `name` FROM `departments` WHERE id = ?");
                $name->execute([$dept_id]);
                $dname = $name->fetchColumn();
                $pdo->prepare("UPDATE `memos` SET `department_id` = NULL, `audience` = 'All' WHERE `department_id` = ?")->execute([$dept_id]);
                $pdo->prepare("DELETE FROM `departments` WHERE `id` = ?")->execute([$dept_id]);
                $pdo->commit();
                log_activity($user_id, 'DEPARTMENT_DELETED', "Deleted department: $dname" . ($staff_count ? " (moved $staff_count staff to #$move_to)" : ''));
                back(true, "Department \"$dname\" removed." . ($staff_count ? " $staff_count staff were moved." : ''));

            case 'set_head':
                $head_id = intval($_POST['head_staff_id'] ?? 0);
                $old = $pdo->prepare("SELECT `head_staff_id` FROM `departments` WHERE id = ?");
                $old->execute([$dept_id]);
                $old_head = (int)$old->fetchColumn();
                $pdo->beginTransaction();
                // Previous head goes back to Staff role if they were only a Department Head
                if ($old_head && $old_head !== $head_id) {
                    $pdo->prepare("UPDATE `staff` SET `role` = 'Staff' WHERE `id` = ? AND `role` = 'Department Head'
                                   AND NOT EXISTS (SELECT 1 FROM (SELECT head_staff_id FROM departments WHERE id <> ?) x WHERE x.head_staff_id = ?)")
                        ->execute([$old_head, $dept_id, $old_head]);
                }
                if ($head_id) {
                    $st = $pdo->prepare("SELECT `id`, `role`, `department_id` FROM `staff` WHERE `id` = ?");
                    $st->execute([$head_id]);
                    $h = $st->fetch();
                    if (!$h) { $pdo->rollBack(); back(false, 'Staff member not found.'); }
                    // A head belongs to the department they lead
                    $pdo->prepare("UPDATE `staff` SET `department_id` = ? WHERE `id` = ?")->execute([$dept_id, $head_id]);
                    if ($h['role'] === 'Staff') {
                        $pdo->prepare("UPDATE `staff` SET `role` = 'Department Head' WHERE `id` = ?")->execute([$head_id]);
                    }
                }
                $pdo->prepare("UPDATE `departments` SET `head_staff_id` = ? WHERE `id` = ?")->execute([$head_id ?: null, $dept_id]);
                $pdo->commit();
                log_activity($user_id, 'DEPARTMENT_HEAD_SET', "Department #$dept_id head set to staff #$head_id");
                back(true, $head_id ? 'Head of Department assigned. They can now send memos to their department.' : 'Head of Department removed.', "dept-$dept_id");

            case 'add_position':
                $titles = preg_split('/[\r\n,]+/', $_POST['title'] ?? '');
                $titles = array_unique(array_filter(array_map('trim', $titles)));
                if (!$dept_id || !$titles) back(false, 'Enter a position title.', "dept-$dept_id");
                $chk = $pdo->prepare("SELECT id FROM `positions` WHERE `department_id` = ? AND `title` = ?");
                $ins = $pdo->prepare("INSERT INTO `positions` (`title`, `department_id`) VALUES (?, ?)");
                $added = 0;
                foreach ($titles as $t) {
                    $chk->execute([$dept_id, $t]);
                    if (!$chk->fetch()) { $ins->execute([$t, $dept_id]); $added++; }
                }
                log_activity($user_id, 'POSITION_CREATED', "Added $added position(s) to department #$dept_id");
                back(true, "$added position(s) added.", "dept-$dept_id");

            case 'rename_position':
                $title = trim($_POST['title'] ?? '');
                if ($title === '' || !$pos_id) back(false, 'Position title is required.');
                $pdo->prepare("UPDATE `positions` SET `title` = ? WHERE `id` = ?")->execute([$title, $pos_id]);
                log_activity($user_id, 'POSITION_UPDATED', "Renamed position #$pos_id to $title");
                back(true, 'Position renamed.', "dept-$dept_id");

            case 'toggle_position':
                $pdo->prepare("UPDATE `positions` SET `is_active` = 1 - `is_active` WHERE `id` = ?")->execute([$pos_id]);
                back(true, 'Position visibility updated.', "dept-$dept_id");

            case 'delete_position':
                $cnt = $pdo->prepare("SELECT COUNT(*) FROM `staff` WHERE `position_id` = ?");
                $cnt->execute([$pos_id]);
                if ((int)$cnt->fetchColumn() > 0) {
                    $pdo->prepare("UPDATE `positions` SET `is_active` = 0 WHERE `id` = ?")->execute([$pos_id]);
                    back(true, 'Staff still hold this position, so it was hidden from new registrations instead of deleted.', "dept-$dept_id");
                }
                $pdo->prepare("DELETE FROM `positions` WHERE `id` = ?")->execute([$pos_id]);
                log_activity($user_id, 'POSITION_DELETED', "Deleted position #$pos_id");
                back(true, 'Position removed.', "dept-$dept_id");
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        back(false, 'Database error: ' . $e->getMessage());
    }
    back(false, 'Unknown action.');
}

// ---- Load data ----
$departments = $pdo->query("SELECT d.*, (SELECT COUNT(*) FROM staff s WHERE s.department_id = d.id) AS staff_count,
                                   h.first_name AS h_first, h.last_name AS h_last, h.display_name AS h_display
                            FROM `departments` d LEFT JOIN `staff` h ON h.id = d.head_staff_id
                            ORDER BY d.name")->fetchAll();
$positions = [];
foreach ($pdo->query("SELECT p.*, (SELECT COUNT(*) FROM staff s WHERE s.position_id = p.id) AS staff_count FROM `positions` p ORDER BY p.title")->fetchAll() as $p) {
    $positions[$p['department_id']][] = $p;
}
$staff_by_dept = [];
$all_staff = $pdo->query("SELECT id, first_name, last_name, display_name, staff_id, department_id, role FROM `staff` WHERE `status` = 'Active' ORDER BY first_name")->fetchAll();
foreach ($all_staff as $st) {
    $staff_by_dept[$st['department_id']][] = $st;
}

require_once '../includes/header.php';
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-sitemap me-2"></i>Departments &amp; Positions</h2>
        <p class="text-muted mb-0">Create, rename or remove departments and job positions, and assign each department's Head.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <button class="btn btn-aviation" data-bs-toggle="modal" data-bs-target="#addDeptModal"><i class="fa-solid fa-plus me-1"></i>New Department</button>
    </div>
</div>

<div class="row g-4">
<?php foreach ($departments as $d):
    $did = (int)$d['id'];
    $head_name = $d['head_staff_id'] ? display_name(['display_name' => $d['h_display'], 'first_name' => $d['h_first'], 'last_name' => $d['h_last']]) : null; ?>
    <div class="col-xl-6" id="dept-<?php echo $did; ?>">
        <div class="card shadow-sm border-0 h-100" style="border-radius:12px;">
            <div class="card-header bg-light d-flex justify-content-between align-items-start p-3">
                <div>
                    <h5 class="fw-bold text-aviation mb-1"><?php echo htmlspecialchars($d['name']); ?></h5>
                    <?php if (!empty($d['description'])): ?><div class="small text-muted"><?php echo htmlspecialchars($d['description']); ?></div><?php endif; ?>
                    <span class="badge bg-secondary mt-1"><?php echo (int)$d['staff_count']; ?> staff</span>
                    <span class="badge <?php echo $head_name ? 'bg-success' : 'bg-warning text-dark'; ?> mt-1">
                        <i class="fa-solid fa-user-tie me-1"></i><?php echo $head_name ? 'Head: ' . htmlspecialchars($head_name) : 'No Head assigned'; ?>
                    </span>
                </div>
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#edit-<?php echo $did; ?>" title="Edit"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn-outline-danger" data-bs-toggle="collapse" data-bs-target="#del-<?php echo $did; ?>" title="Remove"><i class="fa-solid fa-trash-can"></i></button>
                </div>
            </div>
            <div class="card-body p-3">
                <!-- Rename -->
                <div class="collapse mb-3" id="edit-<?php echo $did; ?>">
                    <form method="POST" class="border rounded p-2 bg-light">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        <input type="hidden" name="action" value="rename_department">
                        <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                        <input class="form-control form-control-sm mb-2" name="name" value="<?php echo htmlspecialchars($d['name']); ?>" required>
                        <input class="form-control form-control-sm mb-2" name="description" value="<?php echo htmlspecialchars($d['description'] ?? ''); ?>" placeholder="Short description (optional)">
                        <button class="btn btn-sm btn-aviation">Save</button>
                    </form>
                </div>
                <!-- Delete -->
                <div class="collapse mb-3" id="del-<?php echo $did; ?>">
                    <form method="POST" class="border border-danger rounded p-2" onsubmit="return confirm('Remove this department?');">
                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                        <input type="hidden" name="action" value="delete_department">
                        <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                        <?php if ($d['staff_count'] > 0): ?>
                            <label class="small fw-bold text-danger">Move its <?php echo (int)$d['staff_count']; ?> staff to:</label>
                            <select class="form-select form-select-sm mb-2" name="move_to" required>
                                <option value="">Select department</option>
                                <?php foreach ($departments as $o): if ((int)$o['id'] === $did) continue; ?>
                                    <option value="<?php echo $o['id']; ?>"><?php echo htmlspecialchars($o['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-danger">Remove Department</button>
                    </form>
                </div>

                <!-- Head of Department -->
                <form method="POST" class="d-flex gap-2 mb-3">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="set_head">
                    <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                    <select class="form-select form-select-sm" name="head_staff_id">
                        <option value="0">— No Head of Department —</option>
                        <?php $listed = false; foreach ($staff_by_dept[$did] ?? [] as $st): $listed = true; ?>
                            <option value="<?php echo $st['id']; ?>" <?php echo (int)$d['head_staff_id'] === (int)$st['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars(display_name($st) . ' (' . $st['staff_id'] . ')'); ?></option>
                        <?php endforeach; ?>
                        <optgroup label="Other departments">
                            <?php foreach ($all_staff as $st): if ((int)$st['department_id'] === $did) continue; ?>
                                <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars(display_name($st) . ' (' . $st['staff_id'] . ')'); ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                    </select>
                    <button class="btn btn-sm btn-outline-aviation text-nowrap"><i class="fa-solid fa-user-check me-1"></i>Set Head</button>
                </form>

                <!-- Positions -->
                <h6 class="fw-bold small text-uppercase text-secondary mb-2">Positions</h6>
                <ul class="list-group list-group-flush mb-2">
                    <?php foreach ($positions[$did] ?? [] as $p): ?>
                        <li class="list-group-item px-0 py-1 d-flex align-items-center gap-2">
                            <form method="POST" class="d-flex flex-grow-1 gap-1">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="rename_position">
                                <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                                <input type="hidden" name="pos_id" value="<?php echo $p['id']; ?>">
                                <input class="form-control form-control-sm border-0 <?php echo $p['is_active'] ? '' : 'text-decoration-line-through text-muted'; ?>" name="title" value="<?php echo htmlspecialchars($p['title']); ?>" onchange="this.form.submit()">
                            </form>
                            <span class="badge bg-light text-dark border" title="Staff in this position"><?php echo (int)$p['staff_count']; ?></span>
                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="toggle_position">
                                <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                                <input type="hidden" name="pos_id" value="<?php echo $p['id']; ?>">
                                <button class="btn btn-sm btn-link p-0 text-secondary" title="<?php echo $p['is_active'] ? 'Hide from registration' : 'Show on registration'; ?>"><i class="fa-solid <?php echo $p['is_active'] ? 'fa-eye' : 'fa-eye-slash'; ?>"></i></button>
                            </form>
                            <form method="POST" onsubmit="return confirm('Remove this position?');">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="action" value="delete_position">
                                <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                                <input type="hidden" name="pos_id" value="<?php echo $p['id']; ?>">
                                <button class="btn btn-sm btn-link p-0 text-danger" title="Remove"><i class="fa-solid fa-xmark"></i></button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                    <?php if (empty($positions[$did])): ?><li class="list-group-item px-0 small text-muted">No positions yet.</li><?php endif; ?>
                </ul>
                <form method="POST" class="d-flex gap-2">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="add_position">
                    <input type="hidden" name="dept_id" value="<?php echo $did; ?>">
                    <input class="form-control form-control-sm" name="title" placeholder="New position (separate several with commas)" required>
                    <button class="btn btn-sm btn-aviation text-nowrap"><i class="fa-solid fa-plus me-1"></i>Add</button>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>
</div>

<!-- New Department Modal -->
<div class="modal fade" id="addDeptModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-aviation text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-sitemap me-2"></i>New Department</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="add_department">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Department Name *</label>
                        <input class="form-control" name="name" placeholder="e.g. Legal & Compliance" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Description</label>
                        <input class="form-control" name="description" placeholder="Optional">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Positions</label>
                        <textarea class="form-control" name="positions" rows="4" placeholder="One per line, e.g.&#10;Head of Legal&#10;Legal Officer"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-aviation btn-sm"><i class="fa-solid fa-plus me-1"></i>Create</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
