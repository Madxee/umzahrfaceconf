<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Aviation Training & Safety Certifications Manager
 */

require_once '../includes/auth.php';
require_feature('training');
require_login();
require_role(['Super Admin', 'HR Director', 'HR Manager', 'HR Officer']);

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

// Handle actions (Create Training Program, Record Staff Training Completion)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        // 1. Create Training Program
        if ($action === 'create_program') {
            $name = trim($_POST['name']);
            $desc = trim($_POST['description']);
            $cat = $_POST['category'];
            $validity = intval($_POST['validity_months']);
            
            if (empty($name) || empty($cat) || $validity <= 0) {
                $error = "Program name, category, and validity in months are required.";
            } else {
                try {
                    $stmt = $pdo->prepare("INSERT INTO `training_programs` (`name`, `description`, `category`, `validity_months`) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$name, $desc ?: null, $cat, $validity]);
                    log_activity($_SESSION['user_id'], 'TRAINING_PROGRAM_CREATED', "Created new training program: $name (Validity: $validity mos)");
                    $success = "Training program created successfully.";
                } catch (PDOException $e) {
                    $error = "Failed to create program.";
                }
            }
        }
        
        // 2. Record Staff Training Completion
        elseif ($action === 'record_completion') {
            $staff_id = intval($_POST['staff_id']);
            $prog_id = intval($_POST['program_id']);
            $comp_date = $_POST['completion_date'];
            
            if ($staff_id <= 0 || $prog_id <= 0 || empty($comp_date)) {
                $error = "Staff member, training program, and completion date are required.";
            } else {
                try {
                    // Fetch program validity to calculate expiry
                    $p_stmt = $pdo->prepare("SELECT `validity_months` FROM `training_programs` WHERE `id` = ?");
                    $p_stmt->execute([$prog_id]);
                    $validity_months = intval($p_stmt->fetchColumn());
                    
                    $expiry_date = date('Y-m-d', strtotime("$comp_date +$validity_months months"));
                    
                    // Upload scan if provided
                    $db_cert_path = null;
                    if (isset($_FILES['certificate']) && $_FILES['certificate']['error'] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['certificate']['tmp_name'];
                        $file_name = $_FILES['certificate']['name'];
                        $file_size = $_FILES['certificate']['size'];
                        
                        $file_mime = get_file_mime($file_tmp, $_FILES['certificate']['type'] ?? '');
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        
                        if ($file_size > UPLOAD_MAX_SIZE) {
                            $error = "Certificate file size exceeds 5MB limit.";
                        } elseif (!in_array($file_ext, ALLOWED_EXTENSIONS) || !in_array($file_mime, ALLOWED_MIMES)) {
                            $error = "Invalid file type. Upload PDF, JPG or PNG certificates.";
                        } else {
                            $new_filename = 'cert_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                            $upload_dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . 'certificates';
                            
                            if (!is_dir($upload_dir)) {
                                mkdir($upload_dir, 0755, true);
                            }
                            
                            $dest_path = $upload_dir . DIRECTORY_SEPARATOR . $new_filename;
                            
                            if (move_uploaded_file($file_tmp, $dest_path)) {
                                $db_cert_path = 'uploads/certificates/' . $new_filename;
                            }
                        }
                    }
                    
                    if (empty($error)) {
                        $stmt = $pdo->prepare("INSERT INTO `staff_trainings` (`staff_id`, `training_program_id`, `completion_date`, `expiry_date`, `certificate_path`, `status`) VALUES (?, ?, ?, ?, ?, 'Passed')");
                        $stmt->execute([$staff_id, $prog_id, $comp_date, $expiry_date, $db_cert_path]);
                        
                        // Add notification
                        add_notification($staff_id, "Training Certificate Completed", "HR has recorded your completion of training program: " . $prog_id);
                        
                        log_activity($_SESSION['user_id'], 'STAFF_TRAINING_RECORDED', "Recorded training ID $prog_id for staff member $staff_id");
                        $success = "Staff training completion recorded successfully.";
                    }
                } catch (PDOException $e) {
                    $error = "Failed to record training: " . $e->getMessage();
                }
            }
        }
    }
    
    $redir_url = "training.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch training programs
try {
    $programs = $pdo->query("SELECT * FROM `training_programs` ORDER BY `category` ASC, `name` ASC")->fetchAll();
} catch (PDOException $e) {
    $programs = [];
}

// Fetch staff training logs
try {
    $training_logs = $pdo->query("SELECT st.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, tp.name as program_name, tp.category 
                                  FROM `staff_trainings` st 
                                  JOIN `staff` s ON st.staff_id = s.id 
                                  JOIN `training_programs` tp ON st.training_program_id = tp.id 
                                  ORDER BY st.expiry_date ASC, st.id DESC")->fetchAll();
} catch (PDOException $e) {
    $training_logs = [];
}

// Fetch list of active staff for completion form
$staff_members = $pdo->query("SELECT id, first_name, last_name, display_name, staff_id FROM `staff` WHERE `status` = 'Active' ORDER BY `first_name` ASC")->fetchAll();

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-graduation-cap me-2"></i>Aviation Training & Certifications</h2>
        <p class="text-muted">Register pilot simulation certifications, safety training compliance, ground dispatch logs, and track expirations.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Training Logs -->
    <div class="col-lg-8 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i>Staff Certification & Validity Roster</h5>
            
            <?php if (count($training_logs) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Staff Name</th>
                                <th>Training Program</th>
                                <th>Category</th>
                                <th>Completed</th>
                                <th>Expiration</th>
                                <th>Certificate</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($training_logs as $log): 
                                $is_expired = ($log['expiry_date'] && $log['expiry_date'] < date('Y-m-d'));
                                $is_near_expiry = ($log['expiry_date'] && !$is_expired && strtotime($log['expiry_date']) < strtotime('+30 days'));
                                $status_badge = $is_expired ? 'bg-danger' : ($is_near_expiry ? 'bg-warning text-dark' : 'bg-success');
                                $status_text = $is_expired ? 'Expired' : ($is_near_expiry ? 'Due soon' : 'Valid');
                            ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars(display_name($log)); ?></strong>
                                        <br><small class="text-secondary">No: <code><?php echo htmlspecialchars($log['staff_code']); ?></code></small>
                                    </td>
                                    <td><strong class="text-aviation"><?php echo htmlspecialchars($log['program_name']); ?></strong></td>
                                    <td><span class="badge bg-light text-secondary border"><?php echo $log['category']; ?></span></td>
                                    <td><?php echo format_date($log['completion_date']); ?></td>
                                    <td class="<?php echo $is_expired ? 'text-danger fw-bold' : ''; ?>"><?php echo format_date($log['expiry_date']); ?></td>
                                    <td>
                                        <?php if (!empty($log['certificate_path'])): ?>
                                            <a href="<?php echo get_base_url() . '/' . $log['certificate_path']; ?>" target="_blank" class="btn btn-sm btn-light border py-1" style="font-size:0.75rem;">
                                                <i class="fa-solid fa-file-pdf text-danger me-1"></i>View Scanned
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">No file</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $status_badge; ?>"><?php echo $status_text; ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0 small">No staff training completions recorded yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Record completions / Add program -->
    <div class="col-lg-4 col-md-12">
        <!-- Card 1: Record completion -->
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-file-signature me-2"></i>Record Course Completion</h5>
            <form method="POST" action="training.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="record_completion">
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Select Employee *</label>
                    <select class="form-select" name="staff_id" required>
                        <option value="">Choose Staff</option>
                        <?php foreach ($staff_members as $sm): ?>
                            <option value="<?php echo $sm['id']; ?>">
                                <?php echo htmlspecialchars(display_name($sm)); ?> (<?php echo htmlspecialchars($sm['staff_id']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Training Program *</label>
                    <select class="form-select" name="program_id" required>
                        <option value="">Choose Program</option>
                        <?php foreach ($programs as $prog): ?>
                            <option value="<?php echo $prog['id']; ?>">
                                <?php echo htmlspecialchars($prog['name']); ?> (Valid: <?php echo $prog['validity_months']; ?> mos)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Completion Date *</label>
                    <input type="date" class="form-control" name="completion_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Scanned Certificate File (PDF/Image)</label>
                    <input type="file" class="form-control" name="certificate" accept=".pdf,.jpg,.jpeg,.png">
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-plus me-1"></i>Save Completion Record</button>
            </form>
        </div>

        <!-- Card 2: Create Program -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-list-ol me-2"></i>Create Course Program</h5>
            <form method="POST" action="training.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="create_program">
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Program Name *</label>
                    <input type="text" class="form-control form-control-sm" name="name" placeholder="e.g. Flight Simulator Recurrent Test" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Category *</label>
                    <select class="form-select form-select-sm" name="category" required>
                        <option value="Aviation">Aviation General</option>
                        <option value="Safety">Safety Management</option>
                        <option value="Cabin Crew">Cabin Crew Specific</option>
                        <option value="Ground Staff">Ground Crew Specific</option>
                        <option value="Pilot Certification">Pilot Certification Recurrent</option>
                        <option value="General">General / Inductions</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Validity Period (Months) *</label>
                    <input type="number" class="form-control form-control-sm" name="validity_months" value="12" min="1" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">Program Description</label>
                    <textarea class="form-control form-control-sm" name="description" rows="2" placeholder="Course outline..."></textarea>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-floppy-disk me-1"></i>Save Program Course</button>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
