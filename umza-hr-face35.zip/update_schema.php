<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Database upgrade runner.
 *
 * Upgrades now run automatically (includes/migrations.php) and never delete data.
 * This page simply forces the upgrade to run and reports the result.
 * Allowed from the command line, or in the browser for a logged-in Super Admin.
 *
 * NOTE: the old version of this file emptied the departments/positions tables.
 * That has been removed.
 */

require_once __DIR__ . '/includes/auth.php';

if (php_sapi_name() !== 'cli') {
    header('Content-Type: text/plain');
    if (!is_logged_in() || ($_SESSION['role'] ?? '') !== 'Super Admin') {
        http_response_code(403);
        exit("Forbidden: log in as Super Admin first.\n");
    }
}

try {
    $pdo->exec("UPDATE `settings` SET `setting_value` = '0' WHERE `setting_key` = 'schema_version'");
    run_migrations($pdo);
    echo "Database is up to date (schema version " . get_setting('schema_version') . ").\n";
} catch (PDOException $e) {
    echo "Upgrade failed: " . $e->getMessage() . "\n";
}
