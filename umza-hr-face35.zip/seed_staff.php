<?php
// Developer script: command line only (blocked in the browser for security)
if (php_sapi_name() !== 'cli') { http_response_code(403); exit('Forbidden'); }
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Seed Test Staff Login Script
 */

if (php_sapi_name() !== 'cli') {
    header("Content-Type: text/plain");
}

require_once __DIR__ . '/includes/config.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage() . "\n");
}

try {
    // Helper function for settings
    function get_setting_local($pdo, $key, $default = '') {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE `setting_key` = ?");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return $val !== false ? $val : $default;
    }

    // 1. Fetch Department ID for 'Flight Operations'
    $dept_stmt = $pdo->prepare("SELECT id FROM departments WHERE name = ?");
    $dept_stmt->execute(['Flight Operations']);
    $dept_id = $dept_stmt->fetchColumn();
    
    if (!$dept_id) {
        die("Error: Flight Operations department not found. Run update_schema.php first.\n");
    }
    
    // 2. Fetch Position ID for 'Pilot / First Officer'
    $pos_stmt = $pdo->prepare("SELECT id FROM positions WHERE title = ? AND department_id = ?");
    $pos_stmt->execute(['Pilot / First Officer', $dept_id]);
    $pos_id = $pos_stmt->fetchColumn();
    
    if (!$pos_id) {
        die("Error: First Officer position not found.\n");
    }
    
    // 3. Check if staff already exists by email
    $chk = $pdo->prepare("SELECT id FROM staff WHERE email = 'david.adeboye@umzaair.com'");
    $chk->execute();
    $existing = $chk->fetch();
    
    $pwd_hash = password_hash('StaffPass123!', PASSWORD_DEFAULT);
    
    if ($existing) {
        // Update existing record
        $upd = $pdo->prepare("UPDATE staff SET 
            staff_id = 'UMZA100', 
            first_name = 'David', 
            last_name = 'Adeboye', 
            gender = 'Male', 
            dob = '1990-05-15', 
            department_id = ?, 
            position_id = ?, 
            phone = '+2348011223344', 
            address = 'Plot 20, Airport Road, Lagos, Nigeria', 
            employment_date = '2022-01-10', 
            emergency_contact = 'Sarah Adeboye (Wife): +2348099887766', 
            password_hash = ?, 
            role = 'Staff', 
            status = 'Active', 
            email_verified = 1 
            WHERE id = ?");
        $upd->execute([$dept_id, $pos_id, $pwd_hash, $existing['id']]);
        $staff_record_id = $existing['id'];
        echo "Staff login david.adeboye@umzaair.com updated successfully with role 'Staff'.\n";
    } else {
        // Create new active staff record
        $ins = $pdo->prepare("INSERT INTO staff 
            (staff_id, first_name, last_name, gender, dob, department_id, position_id, email, phone, address, employment_date, emergency_contact, password_hash, role, status, email_verified) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $ins->execute([
            'UMZA100', 'David', 'Adeboye', 'Male', '1990-05-15', $dept_id, $pos_id,
            'david.adeboye@umzaair.com', '+2348011223344', 'Plot 20, Airport Road, Lagos, Nigeria', '2022-01-10', 'Sarah Adeboye (Wife): +2348099887766',
            $pwd_hash, 'Staff', 'Active', 1
        ]);
        
        $staff_record_id = $pdo->lastInsertId();
        echo "Staff login david.adeboye@umzaair.com created successfully with role 'Staff'.\n";
    }
    
    // Clean up any other duplicate ID card records for this staff member
    $pdo->prepare("DELETE FROM `staff_ids` WHERE `staff_id` = ?")->execute([$staff_record_id]);
    
    // Add ID card
    $verify_token = bin2hex(random_bytes(16));
    $issue_date = date('Y-m-d');
    $validity_years = intval(get_setting_local($pdo, 'id_card_validity_years', 3));
    $expiry_date = date('Y-m-d', strtotime("+$validity_years years"));
    
    $id_stmt = $pdo->prepare("INSERT INTO `staff_ids` (`staff_id`, `verification_token`, `issue_date`, `expiry_date`, `status`) 
                              VALUES (?, ?, ?, ?, 'Active')");
    $id_stmt->execute([$staff_record_id, $verify_token, $issue_date, $expiry_date]);
    
    // Seed default training completion for David (DGR and Safety)
    // Clean up first to avoid duplicates
    $pdo->prepare("DELETE FROM staff_trainings WHERE staff_id = ?")->execute([$staff_record_id]);
    $prog_sms = $pdo->query("SELECT id FROM training_programs WHERE name LIKE '%Safety%'")->fetchColumn();
    if ($prog_sms) {
        $t_stmt = $pdo->prepare("INSERT INTO staff_trainings (staff_id, training_program_id, completion_date, expiry_date, status) VALUES (?, ?, ?, ?, 'Passed')");
        $t_stmt->execute([$staff_record_id, $prog_sms, '2025-06-01', '2027-06-01']);
    }
    
    // Seed next flight schedule for David
    // Clean up first to avoid duplicates
    $pdo->prepare("DELETE FROM flight_schedules WHERE staff_id = ?")->execute([$staff_record_id]);
    $f_stmt = $pdo->prepare("INSERT INTO flight_schedules (staff_id, flight_number, departure_airport, arrival_airport, departure_time, arrival_time, role_on_flight, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Scheduled')");
    $f_stmt->execute([$staff_record_id, 'UMS102', 'LOS', 'ABV', date('Y-m-d 10:00:00', strtotime('+1 day')), date('Y-m-d 11:15:00', strtotime('+1 day')), 'Pilot / First Officer']);
    
    echo "ID Card and flight schedules seeded successfully for David Adeboye.\n";
    
} catch (PDOException $e) {
    die("Database seeding failed: " . $e->getMessage() . "\n");
}
