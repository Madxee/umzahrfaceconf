<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Email Verification Processor
 */

require_once 'includes/auth.php';

$title = "Verify Email";
$error = '';
$success = '';

if (isset($_GET['token']) && !empty($_GET['token'])) {
    $token = trim($_GET['token']);
    
    try {
        // Find staff member with this token
        $stmt = $pdo->prepare("SELECT `id`, `first_name`, `last_name`, `display_name`, `email` FROM `staff` WHERE `verification_token` = ? AND `email_verified` = 0");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Update staff to email verified and remove token
            $update = $pdo->prepare("UPDATE `staff` SET `email_verified` = 1, `verification_token` = NULL WHERE `id` = ?");
            $update->execute([$user['id']]);
            
            // Log activity
            log_activity($user['id'], 'EMAIL_VERIFIED', 'Staff email address verified successfully.');
            
            $success = "Thank you, <strong>" . htmlspecialchars(display_name($user)) . "</strong>! Your email (" . htmlspecialchars($user['email']) . ") has been verified successfully.<br><br>Your registration is now pending HR approval. You will receive an email notification once your profile has been approved.";
        } else {
            $error = "Invalid or expired email verification token. If you have already verified your email, please try logging in.";
        }
    } catch (PDOException $e) {
        $error = "A database error occurred. Please try again later.";
    }
} else {
    $error = "No verification token provided. Please click the verification link in your email.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - Verify Email</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=2.2">
</head>
<body class="auth-wrapper">

    <div class="auth-card text-center">
        <div class="auth-header">
            <div class="id-card-logo-placeholder mx-auto">
                <i class="fa-solid fa-plane-departure"></i>
            </div>
            <h2 class="mt-2 fw-bold text-aviation">UMZA Aviation</h2>
            <p class="text-muted">Email Verification System</p>
        </div>
        
        <div class="auth-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-4">
                    <i class="fa-solid fa-circle-exclamation fa-2x mb-2 d-block"></i>
                    <p class="mb-0"><?php echo $error; ?></p>
                </div>
                <a href="index.php" class="btn btn-aviation w-100 py-2">Go to Login</a>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success border-0 shadow-sm mb-4">
                    <i class="fa-solid fa-circle-check fa-2x mb-2 d-block text-success"></i>
                    <p class="mb-0 text-dark"><?php echo $success; ?></p>
                </div>
                <a href="index.php" class="btn btn-aviation w-100 py-2">Return to Login</a>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
