<?php
// Developer script: command line only (blocked in the browser for security)
if (php_sapi_name() !== 'cli') { http_response_code(403); exit('Forbidden'); }
require_once __DIR__ . '/includes/config.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    echo "CONNECTION SUCCESSFUL.\n\n";
    
    // Show tables
    echo "TABLES IN DATABASE:\n";
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        echo "- $table\n";
    }
    echo "\n";
    
    // Show staff records
    echo "STAFF RECORDS:\n";
    $staff = $pdo->query("SELECT id, staff_id, first_name, last_name, email, role, status, email_verified FROM staff")->fetchAll();
    foreach ($staff as $s) {
        echo "- ID: {$s['id']} | StaffID: {$s['staff_id']} | Name: {$s['first_name']} {$s['last_name']} | Email: {$s['email']} | Role: {$s['role']} | Status: {$s['status']} | Verified: {$s['email_verified']}\n";
    }
    echo "\n";
    
    // Check if any errors exist in the schemas of leave_requests or complaints
    echo "COLUMNS IN STAFF:\n";
    $cols = $pdo->query("DESCRIBE staff")->fetchAll();
    foreach ($cols as $col) {
        echo "  - {$col['Field']} ({$col['Type']}) - Null: {$col['Null']}\n";
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
