<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Public Staff ID Card QR Code Verification Gateway
 */

require_once 'includes/db.php';
require_once 'includes/auth.php'; // For get_base_url() and format_date()

$token = trim($_GET['token'] ?? '');
$staff = null;
$error = '';

if (empty($token)) {
    $error = "No verification token provided. Please scan a valid UMZA Aviation staff ID card QR code.";
} else {
    try {
        // Query card status and details
        $stmt = $pdo->prepare("SELECT sid.status as card_status, sid.issue_date, sid.expiry_date, 
                                      s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, s.passport_photo, s.status as staff_status,
                                      d.name as department_name, p.title as position_title 
                               FROM `staff_ids` sid 
                               JOIN `staff` s ON sid.staff_id = s.id 
                               LEFT JOIN `departments` d ON s.department_id = d.id 
                               LEFT JOIN `positions` p ON s.position_id = p.id 
                               WHERE sid.verification_token = ?");
        $stmt->execute([$token]);
        $staff = $stmt->fetch();
        
        if (!$staff) {
            $error = "CRITICAL WARNING: Invalid ID Card token! This QR code does not match any registered employee credential in the UMZA Aviation database. Access Denied.";
        } else {
            // Determine final card verification status (taking expiration into account)
            $today = date('Y-m-d');
            if ($staff['card_status'] === 'Suspended' || $staff['staff_status'] === 'Suspended') {
                $status = 'SUSPENDED';
                $status_color = 'danger';
            } elseif ($today > $staff['expiry_date']) {
                $status = 'EXPIRED';
                $status_color = 'warning';
            } elseif ($staff['staff_status'] !== 'Active') {
                $status = 'INACTIVE';
                $status_color = 'secondary';
            } else {
                $status = 'ACTIVE / VALID';
                $status_color = 'success';
            }
        }
    } catch (PDOException $e) {
        $error = "A database error occurred. Please try again later.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID Verification - UMZA Aviation Services Ltd</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=2.2">
    <style>
        body {
            background-color: #f0f3f2;
        }
        .verify-card {
            max-width: 480px;
            margin: 3rem auto;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: none;
            background: #ffffff;
            overflow: hidden;
        }
        .verify-header {
            background: linear-gradient(135deg, #1b4332 0%, #2d6a4f 100%);
            color: #ffffff;
            padding: 2.5rem 1.5rem;
            text-align: center;
        }
        .status-badge-lg {
            padding: 0.8rem 1.5rem;
            font-size: 1.1rem;
            font-weight: 700;
            border-radius: 50px;
            letter-spacing: 1px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

    <div class="container px-3">
        <div class="card verify-card">
            <div class="verify-header">
                <div class="id-card-logo-placeholder mx-auto mb-2" style="background: white; padding: 2px; display: flex; align-items: center; justify-content: center;">
                    <img src="<?php echo get_base_url(); ?>/assets/images/logo.jpg" alt="UAS Logo" style="max-width: 100%; max-height: 100%; border-radius: 50%;">
                </div>
                <h4 class="fw-bold mb-0 text-white">UMZA Aviation Services Ltd</h4>
                <small class="text-white-50 text-uppercase tracking-wider">Public Credentials Verification Gateway</small>
            </div>
            
            <div class="card-body p-4 text-center">
                <?php if (!empty($error)): ?>
                    <!-- Red warning screen for invalid scans -->
                    <div class="alert alert-danger border-0 shadow-sm p-4 mb-0">
                        <i class="fa-solid fa-triangle-exclamation fa-3x mb-3 text-danger"></i>
                        <h5 class="fw-bold mb-2">Verification Failed</h5>
                        <p class="mb-0 small text-start"><?php echo $error; ?></p>
                    </div>
                <?php else: ?>
                    <!-- Verified Employee screen -->
                    <div class="position-relative d-inline-block mx-auto mb-3">
                        <img src="<?php echo photo_url($staff['passport_photo'] ?? ''); ?>" 
                             class="img-thumbnail shadow" 
                             style="width: 140px; height: 175px; object-fit: cover; border-radius: 10px;" 
                             alt="Passport Photo">
                    </div>
                    
                    <h3 class="fw-bold text-aviation mb-1"><?php echo htmlspecialchars(display_name($staff)); ?></h3>
                    <p class="text-uppercase text-secondary fw-bold mb-4" style="font-size: 0.85rem; letter-spacing: 0.5px;"><?php echo htmlspecialchars($staff['position_title']); ?></p>
                    
                    <div class="mb-4">
                        <span class="status-badge-lg badge bg-<?php echo $status_color; ?> text-uppercase">
                            <i class="fa-solid <?php echo $status === 'ACTIVE / VALID' ? 'fa-circle-check' : 'fa-circle-xmark'; ?> me-2"></i>
                            <?php echo $status; ?>
                        </span>
                    </div>

                    <table class="table table-striped table-bordered text-start mb-0" style="font-size: 0.9rem;">
                        <tbody>
                            <tr>
                                <th class="w-40 text-muted">Staff ID / Number</th>
                                <td class="fw-bold text-dark"><code><?php echo htmlspecialchars($staff['staff_code']); ?></code></td>
                            </tr>
                            <tr>
                                <th class="text-muted">Assigned Department</th>
                                <td><?php echo htmlspecialchars($staff['department_name']); ?></td>
                            </tr>
                            <tr>
                                <th class="text-muted">Issue Date</th>
                                <td><?php echo format_date($staff['issue_date']); ?></td>
                            </tr>
                            <tr>
                                <th class="text-muted">Expiration Date</th>
                                <td class="<?php echo $status === 'EXPIRED' ? 'text-danger fw-bold' : ''; ?>"><?php echo format_date($staff['expiry_date']); ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            
            <div class="card-footer bg-light p-3 text-center border-top text-secondary" style="font-size: 0.75rem;">
                &copy; <?php echo date('Y'); ?> UMZA Aviation Services Ltd. Security Protection Shield active.
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
