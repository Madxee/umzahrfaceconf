<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff View Appraisals & Performance Reports
 */

require_once '../includes/header.php';
require_feature('performance');

$user_id = $_SESSION['user_id'];

try {
    // Fetch appraisals, ratings, promotions and commendations for the logged-in staff member
    $stmt = $pdo->prepare("SELECT pr.*, s.first_name, s.last_name, s.display_name 
                           FROM `performance_reports` pr 
                           JOIN `staff` s ON pr.created_by = s.id 
                           WHERE pr.staff_id = ? 
                           ORDER BY pr.id DESC");
    $stmt->execute([$user_id]);
    $evaluations = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-award me-2"></i>My Appraisals & Performance history</h2>
        <p class="text-muted">Review your appraisal ratings, commendations, and promotion records.</p>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-4"><i class="fa-solid fa-clock-rotate-left me-2"></i>Evaluation Timeline</h5>
            <?php if (count($evaluations) > 0): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($evaluations as $report): ?>
                        <div class="list-group-item px-0 py-3">
                            <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                                <h6 class="mb-0 fw-bold text-aviation"><?php echo htmlspecialchars($report['title']); ?></h6>
                                <small class="text-muted">Effective Date: <?php echo $report['effective_date'] ? format_date($report['effective_date']) : format_date($report['created_at']); ?></small>
                            </div>
                            <div class="mb-2">
                                <?php 
                                $badge_class = 'bg-secondary';
                                if ($report['type'] === 'Promotion') $badge_class = 'bg-success';
                                if ($report['type'] === 'Commendation') $badge_class = 'bg-info';
                                if ($report['type'] === 'Appraisal') $badge_class = 'bg-primary';
                                ?>
                                <span class="badge <?php echo $badge_class; ?> p-2 text-white"><?php echo $report['type']; ?></span>
                                <?php if ($report['rating']): ?>
                                    <span class="text-warning ms-2" style="font-size:0.9rem;">
                                        <?php echo str_repeat('★', $report['rating']); ?>
                                        <?php echo str_repeat('☆', 5 - $report['rating']); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <p class="text-muted small mb-2 bg-light p-3 rounded" style="white-space: pre-wrap; font-size:0.9rem;"><?php echo htmlspecialchars($report['details']); ?></p>
                            <small class="text-secondary">Issued by HR Evaluator: <?php echo htmlspecialchars(display_name($report)); ?> | Date logged: <?php echo format_datetime($report['created_at']); ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">No performance records or appraisals logged in your profile file.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
