<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Printable Leave Approval Letter
 */

require_once '../includes/auth.php';
require_once '../includes/letterhead.php';
require_feature('leave');

// Force authentication
require_login();

$leave_id = intval($_GET['id'] ?? 0);
if ($leave_id <= 0) {
    die("Error: Invalid leave request selected.");
}

try {
    // Fetch leave details and employee data
    $stmt = $pdo->prepare("SELECT lr.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code, 
                                  d.name as department_name, p.title as position_title,
                                  hr.first_name as hr_first, hr.last_name as hr_last
                           FROM `leave_requests` lr 
                           JOIN `staff` s ON lr.staff_id = s.id
                           LEFT JOIN `departments` d ON s.department_id = d.id
                           LEFT JOIN `positions` p ON s.position_id = p.id
                           LEFT JOIN `staff` hr ON lr.approved_by = hr.id
                           WHERE lr.id = ?");
    $stmt->execute([$leave_id]);
    $leave = $stmt->fetch();
    
    if (!$leave) {
        die("Error: Leave record not found.");
    }
    
    // Security check: Only the employee themselves or HR Admins can view this letter
    if ($_SESSION['user_id'] != $leave['staff_id'] && !is_hr_role()) {
        log_activity($_SESSION['user_id'], 'UNAUTHORIZED_LEAVE_LETTER_ACCESS', "Attempted to view leave letter for staff ID: {$leave['staff_id']}");
        die("Error: Unauthorized access to this leave letter.");
    }
    
    // Safety check: Only approved leaves can render letters
    if ($leave['status'] !== 'Approved') {
        die("Error: Leave request has not been approved. Letters are only generated for approved leaves.");
    }

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Approval - <?php echo htmlspecialchars(display_name($leave)); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php letterhead_styles(); ?>
</head>
<body class="lh-body">
<?php letterhead_open(); ?>
    <div class="lh-ref">
        <div><strong>Ref:</strong> <?php echo htmlspecialchars(official_reference('HR', 'LV', $leave['id'], $leave['created_at'])); ?></div>
        <div><strong>Date:</strong> <?php echo date('jS F, Y', strtotime($leave['updated_at'] ?? $leave['created_at'])); ?></div>
    </div>

    <div class="lh-title">Internal Memo: Leave Approval</div>

    <table class="lh-memo-table">
        <tr><td>TO:</td><td><?php echo htmlspecialchars(display_name($leave)); ?> (Staff ID: <?php echo htmlspecialchars($leave['staff_code']); ?>)</td></tr>
        <tr><td>POSITION:</td><td><?php echo htmlspecialchars($leave['position_title'] ?? ''); ?><?php echo $leave['department_name'] ? ', ' . htmlspecialchars($leave['department_name']) : ''; ?></td></tr>
        <tr><td>FROM:</td><td>Human Resources Department</td></tr>
        <tr><td>SUBJECT:</td><td><strong>Approval of <?php echo htmlspecialchars($leave['leave_type']); ?></strong></td></tr>
    </table>
    <hr class="lh-rule">

    <p>We are pleased to inform you that your request for <strong><?php echo htmlspecialchars($leave['leave_type']); ?></strong> has been approved.</p>
    <p>Your leave starts on <strong><?php echo format_date($leave['start_date'], 'l, jS F Y'); ?></strong> and ends on <strong><?php echo format_date($leave['end_date'], 'l, jS F Y'); ?></strong> (inclusive), a total of <strong><?php echo (int)$leave['duration']; ?> day(s)</strong>.</p>
    <p>Please hand over your duties to your designated relief before you proceed, and resume duty on <strong><?php echo date('l, jS F Y', strtotime($leave['end_date'] . ' +1 day')); ?></strong>.</p>
    <?php if (!empty($leave['hr_remarks'])): ?><p><strong>Remarks:</strong> <?php echo nl2br(htmlspecialchars($leave['hr_remarks'])); ?></p><?php endif; ?>
    <p>We wish you a restful leave.</p>

    <div class="lh-sign lh-sign-row">
        <div>
            <?php $sig_img = get_setting('id_card_signature_image');
            if (!empty($sig_img)): ?><img src="<?php echo photo_url($sig_img); ?>" alt="Signature"><?php else: ?><div style="height:16mm;"></div><?php endif; ?>
            <div class="line">
                <strong><?php echo htmlspecialchars(get_setting('id_card_signature_name', trim(($leave['hr_first'] ?? '') . ' ' . ($leave['hr_last'] ?? '')))); ?></strong><br>
                <?php echo htmlspecialchars(get_setting('id_card_signature_title', 'Head, Human Resources')); ?><br>
                For: UMZA Aviation Services Ltd.
            </div>
        </div>
        <div style="text-align:right;">
            <div style="height:16mm;"></div>
            <div class="line" style="margin-left:auto;text-align:left;">
                <strong><?php echo htmlspecialchars(display_name($leave)); ?></strong><br>
                Employee / Date
            </div>
        </div>
    </div>
<?php letterhead_close(); ?>
</body>
</html>
