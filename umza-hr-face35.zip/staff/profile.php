<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Personal Profile & Document Center
 */

require_once '../includes/auth.php';
require_login();

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Handle uploads and updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        $action = $_POST['action'];
        
        // 1. UPDATE CONTACT, NAME & PASSWORD DETAILS
        if ($action === 'update_profile') {
            $first_name = trim($_POST['first_name'] ?? '');
            $other_name = trim($_POST['other_name'] ?? '');
            $last_name = trim($_POST['last_name'] ?? '');
            $name_format = $_POST['name_display_format'] ?? 'first_last';
            if (!array_key_exists($name_format, name_display_formats())) $name_format = 'first_last';
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $emergency_contact = trim($_POST['emergency_contact'] ?? '');
            $old_photo = null;
            $new_password = trim($_POST['new_password'] ?? '');
            
            if (empty($first_name) || empty($last_name) || empty($phone) || empty($address) || empty($emergency_contact)) {
                $error = "First name, last name, phone number, resident address, and emergency contacts are required.";
            } else {
                try {
                    $sql = "UPDATE `staff` SET `first_name` = ?, `other_name` = ?, `last_name` = ?, `name_display_format` = ?, `phone` = ?, `address` = ?, `emergency_contact` = ?";
                    $params = [$first_name, $other_name !== '' ? $other_name : null, $last_name, $name_format, $phone, $address, $emergency_contact];
                    
                    // Upload passport photo if provided (re-saved as a clean, resized JPEG)
                    [$new_photo, $upload_err] = save_uploaded_image('passport_photo', 'passports', 'photo');
                    if ($upload_err) {
                        $error = $upload_err;
                    } elseif ($new_photo) {
                        $old_stmt = $pdo->prepare("SELECT `passport_photo` FROM `staff` WHERE `id` = ?");
                        $old_stmt->execute([$user_id]);
                        $old_photo = $old_stmt->fetchColumn();
                        $sql .= ", `passport_photo` = ?";
                        $params[] = $new_photo;
                    }

                    // Update password if requested
                    if (empty($error) && !empty($new_password)) {
                        if (strlen($new_password) < 8) {
                            $error = "Password must be at least 8 characters.";
                        } else {
                            $sql .= ", `password_hash` = ?";
                            $params[] = password_hash($new_password, PASSWORD_DEFAULT);
                        }
                    }
                    
                    if (empty($error)) {
                        $sql .= " WHERE `id` = ?";
                        $params[] = $user_id;
                        
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute($params);

                        // Remove the previous photo only after the new one is saved in the database
                        if (!empty($new_photo)) {
                            if ($old_photo && $old_photo !== $new_photo) delete_upload($old_photo);
                            $_SESSION['passport'] = $new_photo;
                        }

                        // Update session name immediately
                        $_SESSION['name'] = refresh_display_name($user_id);
                        
                        log_activity($user_id, 'PROFILE_UPDATED', "Employee updated profile name, contact details and profile photo.");
                        $success = "Profile details updated successfully!";
                    }
                } catch (PDOException $e) {
                    $error = "Failed to update profile: " . $e->getMessage();
                }
            }
        }
        
        // 2. UPLOAD CREDENTIAL DOCUMENT
        elseif ($action === 'upload_doc') {
            $doc_name = trim($_POST['doc_name'] ?? '');
            $doc_type = $_POST['doc_type'] ?? '';
            
            if (empty($doc_name) || empty($doc_type)) {
                $error = "Please fill in all document fields.";
            } elseif (!isset($_FILES['attachment']) || $_FILES['attachment']['error'] !== UPLOAD_ERR_OK) {
                $error = "Please select a valid document file to upload.";
            } else {
                $file_tmp = $_FILES['attachment']['tmp_name'];
                $file_name = $_FILES['attachment']['name'];
                $file_size = $_FILES['attachment']['size'];
                
                $file_mime = get_file_mime($file_tmp, $_FILES['attachment']['type'] ?? '');
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                if ($file_size > UPLOAD_MAX_SIZE) {
                    $error = "Document exceeds 5MB size limit.";
                } elseif (!in_array($file_ext, ALLOWED_EXTENSIONS) || !in_array($file_mime, ALLOWED_MIMES)) {
                    $error = "Invalid file type. Only PDF, JPG, PNG, DOC, and DOCX documents are allowed.";
                } else {
                    $subfolder = ($doc_type === 'CV') ? 'cvs' : 'certificates';
                    $new_filename = 'doc_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                    $upload_dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . $subfolder;
                    
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }
                    
                    $dest_path = $upload_dir . DIRECTORY_SEPARATOR . $new_filename;
                    
                    if (move_uploaded_file($file_tmp, $dest_path)) {
                        $db_file_path = 'uploads/' . $subfolder . '/' . $new_filename;
                        
                        try {
                            $stmt = $pdo->prepare("INSERT INTO `documents` (`staff_id`, `name`, `type`, `file_path`, `status`) VALUES (?, ?, ?, ?, 'Pending')");
                            $stmt->execute([$user_id, $doc_name, $doc_type, $db_file_path]);
                            
                            log_activity($user_id, 'DOCUMENT_UPLOADED', "Uploaded a new credential document: $doc_name ($doc_type)");
                            
                            // Notify HR
                            $hr_stmt = $pdo->query("SELECT `email`, `first_name` FROM `staff` WHERE `role` IN ('Super Admin', 'HR Manager', 'HR Director')");
                            $hr_admins = $hr_stmt->fetchAll();
                            $employee_name = $_SESSION['name'];
                            
                            $hr_subject = "New Document Review Required - $employee_name";
                            $hr_body = "
                                <p>A new document has been uploaded by an employee for review:</p>
                                <ul>
                                    <li><strong>Employee:</strong> $employee_name</li>
                                    <li><strong>Document Title:</strong> " . htmlspecialchars($doc_name) . "</li>
                                    <li><strong>Category:</strong> $doc_type</li>
                                </ul>
                                <p>Log in to the HR Portal to approve or reject this document.</p>";
                            
                            foreach ($hr_admins as $admin) {
                                send_email($admin['email'], $admin['first_name'], $hr_subject, $hr_body);
                            }
                            
                            $success = "Document uploaded successfully! It is now pending HR verification.";
                        } catch (PDOException $e) {
                            $error = "Failed to register document in database.";
                        }
                    } else {
                        $error = "Failed to save file to uploads directory.";
                    }
                }
            }
        }
    }
    
    // Redirect to clear form
    $redir_url = "profile.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Retrieve details
try {
    $stmt = $pdo->prepare("SELECT s.*, d.name as department_name, p.title as position_title 
                           FROM `staff` s 
                           LEFT JOIN `departments` d ON s.department_id = d.id 
                           LEFT JOIN `positions` p ON s.position_id = p.id 
                           WHERE s.id = ?");
    $stmt->execute([$user_id]);
    $employee = $stmt->fetch();

    $docs_stmt = $pdo->prepare("SELECT * FROM `documents` WHERE `staff_id` = ? ORDER BY `id` DESC");
    $docs_stmt->execute([$user_id]);
    $documents = $docs_stmt->fetchAll();

    // Fetch qualifications
    $qual_stmt = $pdo->prepare("SELECT * FROM `qualifications` WHERE `staff_id` = ? ORDER BY `year_obtained` DESC");
    $qual_stmt->execute([$user_id]);
    $qualifications = $qual_stmt->fetchAll();

    // Fetch employment history
    $hist_stmt = $pdo->prepare("SELECT * FROM `employment_history` WHERE `staff_id` = ? ORDER BY `start_date` DESC");
    $hist_stmt->execute([$user_id]);
    $history = $hist_stmt->fetchAll();

    // Fetch assets assigned
    $asset_stmt = $pdo->prepare("SELECT * FROM `asset_assignments` WHERE `staff_id` = ? ORDER BY `assigned_date` DESC");
    $asset_stmt->execute([$user_id]);
    $assets = $asset_stmt->fetchAll();

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-user-gear me-2"></i>My Employee File</h2>
        <p class="text-muted">Review your employment dossier, update contact details, and submit qualifications.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Personal dossier overview -->
    <div class="col-lg-5 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4 text-center glass-card" style="border-radius:16px;">
            <img src="<?php echo photo_url($employee['passport_photo'] ?? ''); ?>" 
                 class="img-thumbnail shadow mx-auto mb-3" 
                 style="width: 140px; height: 170px; object-fit: cover; border-radius: 10px;" 
                 alt="Passport Photo">
                 
            <h4 class="fw-bold text-aviation mb-1"><?php echo htmlspecialchars(display_name($employee)); ?></h4>
            <p class="text-uppercase text-secondary fw-semibold mb-4" style="font-size: 0.8rem; letter-spacing: 0.5px;"><?php echo htmlspecialchars($employee['position_title']); ?></p>
            
            <div class="text-start" style="font-size:0.9rem;">
                <h6 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-circle-info me-1"></i>Dossier Details</h6>
                <p class="mb-2"><strong class="text-muted">Staff ID:</strong> <code class="fw-bold fs-6 float-end text-dark"><?php echo htmlspecialchars($employee['staff_id']); ?></code></p>
                <p class="mb-2"><strong class="text-muted">Department:</strong> <span class="float-end text-dark"><?php echo htmlspecialchars($employee['department_name']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Gender:</strong> <span class="float-end text-dark"><?php echo $employee['gender']; ?></span></p>
                <p class="mb-2"><strong class="text-muted">Date of Birth:</strong> <span class="float-end text-dark"><?php echo format_date($employee['dob']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Phone Number:</strong> <span class="float-end text-dark"><?php echo htmlspecialchars($employee['phone']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Email Address:</strong> <span class="float-end text-dark"><?php echo htmlspecialchars($employee['email']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Employment Date:</strong> <span class="float-end text-dark"><?php echo format_date($employee['employment_date']); ?></span></p>
                
                <hr class="my-3">
                <h6 class="fw-bold text-aviation mb-2"><i class="fa-solid fa-location-dot me-1"></i>Residential Address</h6>
                <p class="text-secondary small bg-light p-2 rounded mb-3"><?php echo htmlspecialchars($employee['address']); ?></p>

                <h6 class="fw-bold text-aviation mb-2"><i class="fa-solid fa-triangle-exclamation me-1"></i>Emergency Contact</h6>
                <p class="text-secondary small bg-light p-2 rounded mb-0"><?php echo htmlspecialchars($employee['emergency_contact']); ?></p>
            </div>
        </div>
        
        <!-- Tab: Qualifications, History, & Assets -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <nav class="nav nav-tabs nav-tabs-custom mb-3" id="profileSubTabs" role="tablist">
                <button class="nav-link active" id="quals-tab" data-bs-toggle="tab" data-bs-target="#quals" type="button" role="tab">Qualifications</button>
                <button class="nav-link" id="exp-tab" data-bs-toggle="tab" data-bs-target="#exp" type="button" role="tab">Experience</button>
                <button class="nav-link" id="assets-tab" data-bs-toggle="tab" data-bs-target="#assets" type="button" role="tab">Assets</button>
            </nav>
            <div class="tab-content" id="profileSubTabsContent">
                <!-- Qualifications -->
                <div class="tab-pane fade show active" id="quals" role="tabpanel">
                    <?php if (count($qualifications) > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($qualifications as $q): ?>
                                <div class="list-group-item px-0 py-2">
                                    <h6 class="mb-0 fw-bold text-aviation"><?php echo htmlspecialchars($q['qualification_name']); ?></h6>
                                    <small class="text-secondary"><?php echo htmlspecialchars($q['institution']); ?> | Year: <?php echo $q['year_obtained']; ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted small py-3 mb-0 text-center">No qualifications registered in your dossier.</p>
                    <?php endif; ?>
                </div>
                <!-- Experience -->
                <div class="tab-pane fade" id="exp" role="tabpanel">
                    <?php if (count($history) > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($history as $h): ?>
                                <div class="list-group-item px-0 py-2">
                                    <h6 class="mb-0 fw-bold text-dark"><?php echo htmlspecialchars($h['position']); ?></h6>
                                    <small class="text-aviation"><?php echo htmlspecialchars($h['company_name']); ?></small>
                                    <br><small class="text-muted"><?php echo format_date($h['start_date']); ?> - <?php echo $h['end_date'] ? format_date($h['end_date']) : 'Present'; ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted small py-3 mb-0 text-center">No career history records registered.</p>
                    <?php endif; ?>
                </div>
                <!-- Assets -->
                <div class="tab-pane fade" id="assets" role="tabpanel">
                    <?php if (count($assets) > 0): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($assets as $a): ?>
                                <div class="list-group-item px-0 py-2 d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="mb-0 fw-bold text-dark"><?php echo htmlspecialchars($a['asset_name']); ?></h6>
                                        <small class="text-muted">Code: <code><?php echo htmlspecialchars($a['asset_code']); ?></code> | Assigned: <?php echo format_date($a['assigned_date']); ?></small>
                                    </div>
                                    <span class="badge bg-<?php echo $a['status'] === 'Assigned' ? 'success' : 'secondary'; ?>"><?php echo $a['status']; ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted small py-3 mb-0 text-center">No company assets currently assigned to you.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Column: Document Center & Edit Form -->
    <div class="col-lg-7 col-md-12">
        <!-- Edit Profile form -->
        <div class="card shadow-sm border-0 bg-white p-4 mb-4 glass-card" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-user-pen me-2"></i>Update Personal Details</h5>
            <form method="POST" action="profile.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="update_profile">
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-bold" for="first_name">First Name *</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-bold" for="other_name">Other Name</label>
                        <input type="text" class="form-control" id="other_name" name="other_name" value="<?php echo htmlspecialchars($employee['other_name'] ?? ''); ?>" placeholder="Middle name">
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-bold" for="last_name">Last Name *</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold" for="profile_name_format">Name to display (portal, emails &amp; ID card)</label>
                    <select class="form-select" id="profile_name_format" name="name_display_format">
                        <?php echo name_format_options($employee['first_name'], $employee['other_name'] ?? '', $employee['last_name'], $employee['name_display_format'] ?? 'first_last'); ?>
                    </select>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="phone">Phone Number *</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="passport_photo">Change Passport Photo (JPG/PNG/WebP, max 5MB)</label>
                        <input type="file" class="form-control" id="passport_photo" name="passport_photo" accept="image/jpeg,image/png,image/webp">
                        <div class="form-text">Upload a clear passport photograph. This photo is used on your ID card.</div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="address">Residential Address *</label>
                    <textarea class="form-control" id="address" name="address" rows="2" required><?php echo htmlspecialchars($employee['address']); ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="emergency_contact">Emergency Contact Person & Number *</label>
                    <textarea class="form-control" id="emergency_contact" name="emergency_contact" rows="2" required><?php echo htmlspecialchars($employee['emergency_contact']); ?></textarea>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold" for="new_password">Change Password (Leave blank to keep current)</label>
                    <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New strong password">
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-floppy-disk me-1"></i>Save Contact Changes</button>
            </form>
        </div>

        <!-- Document Upload form -->
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-cloud-arrow-up me-2"></i>Upload Credentials / License Scan</h5>
            <form method="POST" action="profile.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="upload_doc">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="doc_name">Document Name *</label>
                        <input type="text" class="form-control" id="doc_name" name="doc_name" placeholder="e.g. Pilot Certificate / Medical Clearance" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="doc_type">Document Category *</label>
                        <select class="form-select" id="doc_type" name="doc_type" required>
                            <option value="">Choose Type</option>
                            <option value="CV">Curriculum Vitae (CV)</option>
                            <option value="Certificate">Certificate / License</option>
                            <option value="Employment Document">Employment Document</option>
                            <option value="Other">Other Document</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="attachment">Choose File (PDF, Word, JPG, PNG - Max 5MB) *</label>
                    <input type="file" class="form-control" id="attachment" name="attachment" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-upload me-1"></i>Upload Document</button>
            </form>
        </div>

        <!-- Document List -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-file-shield me-2"></i>My Uploaded Documents</h5>
            <?php if (count($documents) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($documents as $doc): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($doc['name']); ?></strong>
                                        <br><small class="text-secondary">Uploaded: <?php echo format_date($doc['uploaded_at']); ?></small>
                                    </td>
                                    <td><span class="badge bg-light text-secondary border"><?php echo $doc['type']; ?></span></td>
                                    <td>
                                        <?php 
                                        $badge_c = 'warning';
                                        if ($doc['status'] === 'Approved') $badge_c = 'success';
                                        if ($doc['status'] === 'Rejected') $badge_c = 'danger';
                                        ?>
                                        <span class="badge bg-<?php echo $badge_c; ?>"><?php echo $doc['status']; ?></span>
                                    </td>
                                    <td>
                                        <a href="<?php echo get_base_url() . '/' . $doc['file_path']; ?>" target="_blank" class="btn btn-sm btn-light border text-aviation">
                                            <i class="fa-solid fa-eye me-1"></i>View File
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">No documents uploaded yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
