<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Official memo on the company letterhead (HR circulars and Head-of-Department memos)
 */

require_once '../includes/auth.php';
require_once '../includes/letterhead.php';
require_feature('memos');
require_login();

$memo_id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT m.*, s.first_name, s.last_name, s.other_name, s.display_name, s.role AS sender_role,
                              p.title AS sender_position, sd.name AS sender_dept, td.name AS target_dept
                       FROM `memos` m
                       LEFT JOIN `staff` s ON s.id = m.created_by
                       LEFT JOIN `positions` p ON p.id = s.position_id
                       LEFT JOIN `departments` sd ON sd.id = s.department_id
                       LEFT JOIN `departments` td ON td.id = m.department_id
                       WHERE m.id = ?");
$stmt->execute([$memo_id]);
$memo = $stmt->fetch();
if (!$memo) {
    die("Memo not found.");
}

// Who may open it: everyone for company memos; for department memos the department, the sender and HR
$my_dept = (int)($_SESSION['department_id'] ?? get_user_department_id());
if (($memo['audience'] ?? 'All') === 'Department' && !is_hr_role()
    && (int)$memo['department_id'] !== $my_dept && (int)$memo['created_by'] !== (int)$_SESSION['user_id']) {
    die("You are not allowed to view this memo.");
}

if (($memo['status'] ?? 'Published') !== 'Published' && !is_hr_role() && !is_md() && (int)$memo['created_by'] !== (int)$_SESSION['user_id']) {
    die("This memo has not been approved yet.");
}
$from_hr = is_hr_role($memo['sender_role'] ?? '');
$unit = $from_hr ? 'HR' : department_code($memo['sender_dept'] ?? '');
$to = ($memo['audience'] ?? 'All') === 'Department' ? 'All Staff, ' . ($memo['target_dept'] ?? 'Department') : 'All Staff';
$sender = display_name($memo) ?: 'Human Resources';
$sender_title = $memo['sender_position'] ?: ($memo['sender_role'] ?? '');
if (!$from_hr && $memo['sender_role'] === 'Department Head') {
    $sender_title = 'Head, ' . ($memo['sender_dept'] ?? 'Department');
}
$from = $from_hr ? 'Human Resources Department' : ($sender_title ?: $sender);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($memo['title']); ?> - Memo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php letterhead_styles(); ?>
</head>
<body class="lh-body">
<?php letterhead_open(empty($_GET['embed'])); ?>
    <?php if (($memo['status'] ?? 'Published') !== 'Published'): ?>
        <div style="position:absolute;top:40%;left:0;right:0;text-align:center;transform:rotate(-30deg);font-size:72pt;color:rgba(200,0,0,0.12);font-weight:bold;pointer-events:none;z-index:5;">AWAITING MD</div>
    <?php endif; ?>
    <div class="lh-ref">
        <div><strong>Ref:</strong> <?php echo htmlspecialchars(official_reference($unit, 'MEMO', $memo['id'], $memo['created_at'])); ?></div>
        <div><strong>Date:</strong> <?php echo date('jS F, Y', strtotime($memo['created_at'])); ?></div>
    </div>

    <div class="lh-title"><?php echo htmlspecialchars(strtoupper($memo['type'] === 'Internal Memo' || $memo['type'] === 'Department Notice' ? 'Internal Memo' : $memo['type'])); ?></div>

    <table class="lh-memo-table">
        <tr><td>TO:</td><td><?php echo htmlspecialchars($to); ?></td></tr>
        <tr><td>FROM:</td><td><?php echo htmlspecialchars($from); ?></td></tr>
        <tr><td>SUBJECT:</td><td><strong><?php echo htmlspecialchars($memo['title']); ?></strong></td></tr>
    </table>
    <hr class="lh-rule">

    <div class="lh-text"><?php echo htmlspecialchars($memo['content']); ?></div>

    <?php if (!empty($memo['file_path'])): ?>
        <p class="mt-3"><em>Attachment: <?php echo htmlspecialchars(basename($memo['file_path'])); ?> (available on the HR portal).</em></p>
    <?php endif; ?>

    <div class="lh-sign">
        <?php
        $sig_img = get_setting('id_card_signature_image');
        $signatory = get_setting('id_card_signature_name', '');
        // The saved HR signature is used only when the HR signatory sent the memo
        if ($from_hr && !empty($sig_img) && strcasecmp(trim($signatory), trim($sender)) === 0): ?>
            <img src="<?php echo photo_url($sig_img); ?>" alt="Signature">
        <?php else: ?>
            <div style="height:16mm;"></div>
        <?php endif; ?>
        <div class="line">
            <strong><?php echo htmlspecialchars($sender); ?></strong><br>
            <?php echo htmlspecialchars($sender_title); ?><br>
            For: UMZA Aviation Services Ltd.
        </div>
    </div>
    <?php if (!empty($memo['md_id']) && $memo['status'] === 'Published'):
        $mdq = $pdo->prepare("SELECT `first_name`, `last_name`, `display_name` FROM `staff` WHERE `id` = ?");
        $mdq->execute([$memo['md_id']]);
        $mdr = $mdq->fetch() ?: [];
        $md_sig = get_setting('md_signature_image'); ?>
        <div class="lh-sign" style="margin-top:8mm;">
            <?php if (!empty($md_sig)): ?><img src="<?php echo photo_url($md_sig); ?>" alt="MD signature"><?php endif; ?>
            <div class="line">
                <strong>Approved: <?php echo htmlspecialchars(get_setting('md_name', '') ?: display_name($mdr)); ?></strong><br>
                <?php echo htmlspecialchars(get_setting('md_title', 'Managing Director / CEO')); ?> &middot; <?php echo date('d/m/Y', strtotime($memo['md_decision_at'])); ?>
            </div>
        </div>
    <?php endif; ?>
    <div class="lh-stamp">Issued through the UMZA Aviation HR Portal on <?php echo date('d/m/Y h:i A', strtotime($memo['created_at'])); ?>.</div>
<?php letterhead_close(); ?>
</body>
</html>
