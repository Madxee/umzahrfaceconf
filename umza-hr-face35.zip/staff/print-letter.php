<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Printable HR Letter
 */

require_once '../includes/auth.php';
require_once '../includes/letterhead.php';
require_feature('letters');

// Force authentication
require_login();

$letter_id = intval($_GET['id'] ?? 0);
if ($letter_id <= 0) {
    die("Error: Invalid letter selected.");
}

try {
    // Fetch letter details, employee details, and HR signature details
    $stmt = $pdo->prepare("SELECT l.*, s.first_name, s.last_name, s.display_name, s.staff_id as staff_code,
                                  d.name as department_name, p.title as position_title,
                                  hr.first_name as hr_first, hr.last_name as hr_last, hrp.title as hr_position,
                                  md.first_name AS md_first, md.last_name AS md_last, md.display_name AS md_display
                           FROM `staff_letters` l 
                           JOIN `staff` s ON l.staff_id = s.id
                           LEFT JOIN `departments` d ON s.department_id = d.id
                           LEFT JOIN `positions` p ON s.position_id = p.id
                           LEFT JOIN `staff` hr ON l.created_by = hr.id
                           LEFT JOIN `positions` hrp ON hr.position_id = hrp.id
                           LEFT JOIN `staff` md ON l.md_id = md.id
                           WHERE l.id = ?");
    $stmt->execute([$letter_id]);
    $letter = $stmt->fetch();
    
    if (!$letter) {
        die("Error: Letter record not found.");
    }
    
    // Security check: Only the employee themselves, HR Admins, or Finance (for salary letters) can view this letter
    $is_staff_owner = (int)$_SESSION['user_id'] === (int)$letter['staff_id'];
    $can_manage = is_hr_role() || is_md() || $_SESSION['role'] === 'Finance Officer';
    if ($is_staff_owner && !$can_manage && ($letter['status'] ?? 'Approved') !== 'Approved') {
        die("This letter has not been approved yet.");
    }
    if (!$is_staff_owner && !$can_manage) {
        log_activity($_SESSION['user_id'], 'UNAUTHORIZED_LETTER_ACCESS', "Attempted to view letter ID {$letter['id']} for staff ID: {$letter['staff_id']}");
        die("Error: Unauthorized access to this official letter.");
    }

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($letter['title']); ?> - <?php echo htmlspecialchars(display_name($letter)); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <?php letterhead_styles(); ?>
</head>
<body class="lh-body">
<?php letterhead_open(empty($_GET['embed'])); ?>
    <?php $approved = ($letter['status'] ?? 'Approved') === 'Approved'; ?>
    <?php if (!$approved): ?>
        <div style="position:absolute;top:40%;left:0;right:0;text-align:center;transform:rotate(-30deg);font-size:72pt;color:rgba(200,0,0,0.12);font-weight:bold;pointer-events:none;z-index:5;">
            <?php echo $letter['status'] === 'Pending MD' ? 'AWAITING MD' : 'DRAFT'; ?>
        </div>
    <?php endif; ?>
    <div class="lh-ref">
        <div><strong>Ref:</strong> <?php echo htmlspecialchars(official_reference('HR', 'LTR', $letter['id'], $letter['created_at'])); ?></div>
        <div><strong>Date:</strong> <?php echo date('jS F, Y', strtotime($letter['created_at'])); ?></div>
    </div>

    <div style="margin-bottom:5mm;">
        <strong><?php echo htmlspecialchars($letter['recipient_name'] ?: display_name($letter)); ?></strong><br>
        Staff ID: <?php echo htmlspecialchars($letter['staff_code']); ?><br>
        <?php if (!empty($letter['recipient_details'])): ?>
            <?php echo htmlspecialchars($letter['recipient_details']); ?><br>
        <?php else: ?>
            <?php if ($letter['position_title']): ?><?php echo htmlspecialchars($letter['position_title']); ?><br><?php endif; ?>
            <?php if ($letter['department_name']): ?><?php echo htmlspecialchars($letter['department_name']); ?><br><?php endif; ?>
        <?php endif; ?>
        UMZA Aviation Services Ltd.
    </div>

    <div class="lh-title"><?php echo htmlspecialchars($letter['title']); ?></div>

    <div class="lh-text"><?php echo htmlspecialchars($letter['content']); ?></div>

    <?php
    $hr_sig = get_setting('id_card_signature_image');
    $md_sig = get_setting('md_signature_image');
    $md_name = get_setting('md_name', '') ?: ($letter['md_id'] ? display_name(['display_name' => $letter['md_display'], 'first_name' => $letter['md_first'], 'last_name' => $letter['md_last']]) : '');
    $md_signed = $approved && !empty($letter['md_id']);
    ?>
    <div class="lh-sign lh-sign-row" style="page-break-inside:avoid;">
        <div>
            <?php if ($approved && !empty($hr_sig)): ?><img src="<?php echo photo_url($hr_sig); ?>" alt="HR signature"><?php else: ?><div style="height:16mm;"></div><?php endif; ?>
            <div class="line">
                <strong><?php echo htmlspecialchars(get_setting('id_card_signature_name', trim(($letter['hr_first'] ?? '') . ' ' . ($letter['hr_last'] ?? '')))); ?></strong><br>
                <?php echo htmlspecialchars(get_setting('id_card_signature_title', 'Head, Human Resources')); ?>
            </div>
        </div>
        <?php if ($md_signed || !empty($letter['requires_md'])): ?>
        <div>
            <?php if ($md_signed && !empty($md_sig)): ?><img src="<?php echo photo_url($md_sig); ?>" alt="MD signature"><?php else: ?><div style="height:16mm;"></div><?php endif; ?>
            <div class="line">
                <strong><?php echo htmlspecialchars($md_name ?: 'Managing Director'); ?></strong><br>
                <?php echo htmlspecialchars(get_setting('md_title', 'Managing Director / CEO')); ?>
                <?php if ($md_signed): ?><br><span style="font-size:9pt;color:#1b6b3a;">Approved <?php echo date('d/m/Y', strtotime($letter['md_decision_at'])); ?></span><?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div style="margin-top:10mm;font-size:10.5pt;page-break-inside:avoid;">
        <strong>Acknowledgement:</strong> I, <?php echo htmlspecialchars($letter['recipient_name'] ?: display_name($letter)); ?>, acknowledge receipt of this letter.
        <div style="display:flex;gap:12mm;margin-top:8mm;"><div class="line" style="border-top:1px solid #555;width:60mm;">Signature</div><div style="border-top:1px solid #555;width:40mm;">Date</div></div>
    </div>
<?php letterhead_close(); ?>
</body>
</html>
