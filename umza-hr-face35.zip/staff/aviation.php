<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff ESS - Aviation Crew Management Desk
 */

require_once '../includes/auth.php';
require_feature('aviation');
require_login();

$user_id = $_SESSION['user_id'];
$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';

// Handle updating passport/visa/license/medical certificates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_aviation_records') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } else {
        $passport_no = trim($_POST['passport_number'] ?? '');
        $passport_expiry = $_POST['passport_expiry'] ?? null;
        $visa_details = trim($_POST['visa_details'] ?? '');
        $visa_expiry = $_POST['visa_expiry'] ?? null;
        $license_no = trim($_POST['license_number'] ?? '');
        $license_type = $_POST['license_type'] ?? null;
        $license_expiry = $_POST['license_expiry'] ?? null;
        $medical_class = $_POST['medical_class'] ?? null;
        $medical_expiry = $_POST['medical_expiry'] ?? null;
        
        try {
            // Save or Update in aviation_records table
            $stmt = $pdo->prepare("INSERT INTO `aviation_records` 
                (`staff_id`, `license_number`, `license_type`, `license_expiry`, `medical_class`, `medical_expiry`, `passport_number`, `passport_expiry`, `visa_details`, `visa_expiry`) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
                ON DUPLICATE KEY UPDATE 
                `license_number` = VALUES(`license_number`),
                `license_type` = VALUES(`license_type`),
                `license_expiry` = VALUES(`license_expiry`),
                `medical_class` = VALUES(`medical_class`),
                `medical_expiry` = VALUES(`medical_expiry`),
                `passport_number` = VALUES(`passport_number`),
                `passport_expiry` = VALUES(`passport_expiry`),
                `visa_details` = VALUES(`visa_details`),
                `visa_expiry` = VALUES(`visa_expiry`)");
            
            $stmt->execute([
                $user_id, $license_no ?: null, $license_type ?: null, $license_expiry ?: null, 
                $medical_class ?: null, $medical_expiry ?: null, $passport_no ?: null, 
                $passport_expiry ?: null, $visa_details ?: null, $visa_expiry ?: null
            ]);
            
            log_activity($user_id, 'AVIATION_RECORDS_UPDATED', "Updated passport/visa/license/medical details.");
            $success = "Aviation records updated successfully.";
        } catch (PDOException $e) {
            $error = "Database update failed: " . $e->getMessage();
        }
    }
    
    $redir_url = "aviation.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch active flight schedules (last 10 & future ones)
try {
    $flights_stmt = $pdo->prepare("SELECT * FROM `flight_schedules` WHERE `staff_id` = ? ORDER BY `departure_time` DESC LIMIT 15");
    $flights_stmt->execute([$user_id]);
    $flight_schedules = $flights_stmt->fetchAll();
} catch (PDOException $e) {
    $flight_schedules = [];
}

// Fetch aviation records (licenses, passport, visa)
try {
    $rec_stmt = $pdo->prepare("SELECT * FROM `aviation_records` WHERE `staff_id` = ?");
    $rec_stmt->execute([$user_id]);
    $aviation_record = $rec_stmt->fetch();
} catch (PDOException $e) {
    $aviation_record = null;
}

// Fetch uniform issuances
try {
    $unif_stmt = $pdo->prepare("SELECT * FROM `uniform_issuance` WHERE `staff_id` = ? ORDER BY `issued_date` DESC");
    $unif_stmt->execute([$user_id]);
    $uniforms = $unif_stmt->fetchAll();
} catch (PDOException $e) {
    $uniforms = [];
}

// Calculate countdown alert flags
$today = date('Y-m-d');
$alerts = [];

if ($aviation_record) {
    if ($aviation_record['license_expiry'] && $aviation_record['license_expiry'] < $today) {
        $alerts[] = ['type' => 'danger', 'msg' => 'YOUR PILOT/CREW LICENSE HAS EXPIRED! Please upload your renewal immediately.'];
    } elseif ($aviation_record['license_expiry'] && strtotime($aviation_record['license_expiry']) < strtotime('+30 days')) {
        $alerts[] = ['type' => 'warning', 'msg' => 'Your flight crew license expires in less than 30 days.'];
    }
    
    if ($aviation_record['medical_expiry'] && $aviation_record['medical_expiry'] < $today) {
        $alerts[] = ['type' => 'danger', 'msg' => 'YOUR CLASS MEDICAL CERTIFICATE HAS EXPIRED! You are legally grounded.'];
    } elseif ($aviation_record['medical_expiry'] && strtotime($aviation_record['medical_expiry']) < strtotime('+30 days')) {
        $alerts[] = ['type' => 'warning', 'msg' => 'Your medical certificate expires in less than 30 days.'];
    }

    if ($aviation_record['passport_expiry'] && $aviation_record['passport_expiry'] < $today) {
        $alerts[] = ['type' => 'danger', 'msg' => 'Your Passport has expired. International flight roster disabled.'];
    }
}

require_once '../includes/header.php';
?>

<?php foreach ($alerts as $alt): ?>
    <div class="alert alert-<?php echo $alt['type']; ?> alert-dismissible fade show shadow-sm border-0 border-start border-4 border-<?php echo $alt['type']; ?> mb-3" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo $alt['msg']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endforeach; ?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-plane-arrival me-2"></i>Crew Operations & Aviation Desk</h2>
        <p class="text-muted">Track your upcoming flights, update licenses/medical clearance, and view uniform issuances.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Flight Schedules -->
    <div class="col-lg-7 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i>Flight Crew Roster & Schedule</h5>
            
            <?php if (count($flight_schedules) > 0): ?>
                <div class="roster-timeline mt-3">
                    <?php foreach ($flight_schedules as $flight): 
                        $is_active = (strtotime($flight['departure_time']) <= time() && strtotime($flight['arrival_time']) >= time());
                        $status_badge = 'flight-status-' . strtolower($flight['status']);
                    ?>
                        <div class="roster-item <?php echo $is_active ? 'active' : ''; ?>">
                            <div class="p-3 bg-light rounded border glass-card" style="margin-left:10px;">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="fw-bold text-aviation mb-0">
                                        <i class="fa-solid fa-plane me-2"></i>Flight No: <?php echo htmlspecialchars($flight['flight_number']); ?>
                                    </h6>
                                    <span class="badge <?php echo $status_badge; ?> py-1 px-2 text-uppercase" style="font-size:0.7rem;">
                                        <?php echo $flight['status']; ?>
                                    </span>
                                </div>
                                <div class="row small g-2 text-secondary">
                                    <div class="col-md-4">
                                        <strong>Route:</strong> <code><?php echo htmlspecialchars($flight['departure_airport']); ?></code> <i class="fa-solid fa-arrow-right-long mx-1"></i> <code><?php echo htmlspecialchars($flight['arrival_airport']); ?></code>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Departure:</strong> <?php echo format_datetime($flight['departure_time']); ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Arrival:</strong> <?php echo format_datetime($flight['arrival_time']); ?>
                                    </div>
                                    <div class="col-md-12 border-top pt-2 mt-2">
                                        <strong>Crew Role on Board:</strong> <span class="badge bg-secondary"><?php echo htmlspecialchars($flight['role_on_flight'] ?: 'Not Defined'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5 text-muted">
                    <i class="fa-solid fa-plane-slash fa-3x mb-3 text-secondary"></i>
                    <h5>No Flight Assignments Scheduled</h5>
                    <p class="small mb-0">You have no active flights assigned on the roster. Check with flight planning or OCC controllers if this is an error.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Uniform Issuance logs -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-shirt me-2"></i>Uniform & PPE Issuances</h5>
            <?php if (count($uniforms) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size: 0.85rem;">
                        <thead>
                            <tr>
                                <th>Item Issued</th>
                                <th>Size</th>
                                <th>Quantity</th>
                                <th>Date Issued</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($uniforms as $uni): ?>
                                <tr>
                                    <td class="fw-bold text-dark"><?php echo htmlspecialchars($uni['item_name']); ?></td>
                                    <td><code><?php echo htmlspecialchars($uni['size']); ?></code></td>
                                    <td><?php echo $uni['quantity']; ?></td>
                                    <td><?php echo format_date($uni['issued_date']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo $uni['status'] === 'New' ? 'success' : 'primary'; ?>">
                                            <?php echo $uni['status']; ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-3 mb-0 small">No uniforms or cabin crew gears registered as issued yet.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Right Column: Aviation records update form -->
    <div class="col-lg-5 col-md-12">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-id-card-clip me-2"></i>My Aviation Credentials</h5>
            
            <form method="POST" action="aviation.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="update_aviation_records">
                
                <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3"><i class="fa-solid fa-passport me-1"></i>Passport & Visa Particulars</h6>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="passport_number">Passport Number</label>
                        <input type="text" class="form-control form-control-sm" id="passport_number" name="passport_number" value="<?php echo htmlspecialchars($aviation_record['passport_number'] ?? ''); ?>" placeholder="e.g. A12345678">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="passport_expiry">Passport Expiration</label>
                        <input type="date" class="form-control form-control-sm" id="passport_expiry" name="passport_expiry" value="<?php echo $aviation_record['passport_expiry'] ?? ''; ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="visa_details">Visa Details / Country</label>
                        <input type="text" class="form-control form-control-sm" id="visa_details" name="visa_details" value="<?php echo htmlspecialchars($aviation_record['visa_details'] ?? ''); ?>" placeholder="e.g. US B1/B2 Visa / Schengen">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="visa_expiry">Visa Expiration Date</label>
                        <input type="date" class="form-control form-control-sm" id="visa_expiry" name="visa_expiry" value="<?php echo $aviation_record['visa_expiry'] ?? ''; ?>">
                    </div>
                </div>
                
                <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3 mt-3"><i class="fa-solid fa-address-card me-1"></i>Flight Crew License details</h6>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="license_number">License Number</label>
                        <input type="text" class="form-control form-control-sm" id="license_number" name="license_number" value="<?php echo htmlspecialchars($aviation_record['license_number'] ?? ''); ?>" placeholder="e.g. CAA/FCL/3482">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="license_type">License Type</label>
                        <select class="form-select form-select-sm" id="license_type" name="license_type">
                            <option value="">Choose License</option>
                            <option value="ATPL" <?php echo ($aviation_record && $aviation_record['license_type'] === 'ATPL') ? 'selected' : ''; ?>>ATPL (Airline Transport Pilot)</option>
                            <option value="CPL" <?php echo ($aviation_record && $aviation_record['license_type'] === 'CPL') ? 'selected' : ''; ?>>CPL (Commercial Pilot)</option>
                            <option value="PPL" <?php echo ($aviation_record && $aviation_record['license_type'] === 'PPL') ? 'selected' : ''; ?>>PPL (Private Pilot)</option>
                            <option value="Cabin Crew Licence" <?php echo ($aviation_record && $aviation_record['license_type'] === 'Cabin Crew Licence') ? 'selected' : ''; ?>>Cabin Crew Licence</option>
                            <option value="Dispatcher Licence" <?php echo ($aviation_record && $aviation_record['license_type'] === 'Dispatcher Licence') ? 'selected' : ''; ?>>Flight Dispatcher Licence</option>
                            <option value="Other" <?php echo ($aviation_record && $aviation_record['license_type'] === 'Other') ? 'selected' : ''; ?>>Other Licence Type</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold" for="license_expiry">License Expiration Date</label>
                    <input type="date" class="form-control form-control-sm" id="license_expiry" name="license_expiry" value="<?php echo $aviation_record['license_expiry'] ?? ''; ?>">
                </div>

                <h6 class="fw-bold text-aviation border-bottom pb-1 mb-3 mt-3"><i class="fa-solid fa-heart-pulse me-1"></i>Aviation Medical Certificate</h6>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="medical_class">Medical Class</label>
                        <select class="form-select form-select-sm" id="medical_class" name="medical_class">
                            <option value="">Choose Class</option>
                            <option value="Class 1" <?php echo ($aviation_record && $aviation_record['medical_class'] === 'Class 1') ? 'selected' : ''; ?>>Class 1 (Commercial/ATPL Pilots)</option>
                            <option value="Class 2" <?php echo ($aviation_record && $aviation_record['medical_class'] === 'Class 2') ? 'selected' : ''; ?>>Class 2 (Private Pilots/Cabin Crew)</option>
                            <option value="Class 3" <?php echo ($aviation_record && $aviation_record['medical_class'] === 'Class 3') ? 'selected' : ''; ?>>Class 3 (Air Traffic/Ground Dispatch)</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold" for="medical_expiry">Medical Clearance Expiry</label>
                        <input type="date" class="form-control form-control-sm" id="medical_expiry" name="medical_expiry" value="<?php echo $aviation_record['medical_expiry'] ?? ''; ?>">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2 mt-3"><i class="fa-solid fa-floppy-disk me-1"></i>Save Aviation Records</button>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
