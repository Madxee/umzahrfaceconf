<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Disciplinary Query Answers
 */

require_once '../includes/auth.php';
require_feature('queries');
require_once '../includes/mail.php';
require_login();

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Handle Query Reply Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reply_query') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $query_id = intval($_POST['query_id'] ?? 0);
    $reply_text = trim($_POST['reply_text'] ?? '');
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } elseif ($query_id <= 0 || empty($reply_text)) {
        $error = "Please fill in your reply text.";
    } else {
        try {
            // Fetch query details to ensure ownership
            $stmt = $pdo->prepare("SELECT q.*, s.first_name, s.last_name, s.display_name FROM `queries` q JOIN `staff` s ON q.staff_id = s.id WHERE q.id = ? AND q.staff_id = ?");
            $stmt->execute([$query_id, $user_id]);
            $query_row = $stmt->fetch();
            
            if (!$query_row) {
                $error = "Query record not found or access denied.";
            } elseif ($query_row['status'] === 'Resolved') {
                $error = "This disciplinary query has already been resolved and closed.";
            } else {
                // Handle optional supporting document attachment
                $pdf_path = '';
                if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                    $file_tmp = $_FILES['attachment']['tmp_name'];
                    $file_name = $_FILES['attachment']['name'];
                    $file_size = $_FILES['attachment']['size'];
                    $file_mime = get_file_mime($file_tmp, $_FILES['attachment']['type'] ?? '');
                    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                    
                    if ($file_size > UPLOAD_MAX_SIZE) {
                        $error = "Supporting document exceeds 5MB limit.";
                    } elseif (!in_array($file_ext, ALLOWED_EXTENSIONS) || !in_array($file_mime, ALLOWED_MIMES)) {
                        $error = "Only PDF, Word, and Image files are allowed as query defense attachments.";
                    } else {
                        $new_filename = 'defense_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                        $upload_dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . 'documents';
                        
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        
                        $dest_path = $upload_dir . DIRECTORY_SEPARATOR . $new_filename;
                        if (move_uploaded_file($file_tmp, $dest_path)) {
                            $pdf_path = 'uploads/documents/' . $new_filename;
                        } else {
                            $error = "Failed to save defense attachment file.";
                        }
                    }
                }

                if (empty($error)) {
                    $pdo->beginTransaction();
                    
                    // Insert reply
                    $insert = $pdo->prepare("INSERT INTO `query_replies` (`query_id`, `reply_text`, `file_path`) VALUES (?, ?, ?)");
                    $insert->execute([$query_id, $reply_text, $pdf_path]);
                    
                    // Update Query Status
                    $update = $pdo->prepare("UPDATE `queries` SET `status` = 'Replied' WHERE `id` = ?");
                    $update->execute([$query_id]);
                    
                    $pdo->commit();
                    
                    log_activity($user_id, 'QUERY_REPLIED', "Submitted defense statement for query ID: $query_id");
                    
                    // Send Email to HR Admins
                    $hr_stmt = $pdo->query("SELECT `email`, `first_name` FROM `staff` WHERE `role` IN ('Super Admin', 'HR Director', 'HR Manager') AND `status` = 'Active'");
                    $hr_admins = $hr_stmt->fetchAll();
                    $employee_name = $_SESSION['name'];
                    
                    $hr_subject = "Query Defense Reply Submitted - $employee_name";
                    $hr_body = "
                        <p>An employee has submitted a formal response statement for an issued disciplinary query:</p>
                        <ul>
                            <li><strong>Employee:</strong> $employee_name</li>
                            <li><strong>Query Subject:</strong> " . htmlspecialchars($query_row['title']) . "</li>
                            <li><strong>Submission Date:</strong> " . date('M d, Y') . "</li>
                        </ul>
                        <p><strong>Employee Reply Extract:</strong><br>" . nl2br(htmlspecialchars(substr($reply_text, 0, 400))) . "...</p>
                        <p>Please log in to the HR Portal Admin Panel to review the defense statement and attachment.</p>
                        <p><a href='" . get_base_url() . "/admin/queries.php' class='btn'>Review Query Replies</a></p>";
                    
                    foreach ($hr_admins as $admin) {
                        send_email($admin['email'], $admin['first_name'], $hr_subject, $hr_body);
                    }

                    $success = "Your query reply has been submitted successfully. HR has been notified.";
                }
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "A database error occurred: " . $e->getMessage();
        }
    }
    
    // Redirect
    $redir_url = "queries.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Fetch queries and replies
try {
    $queries = $pdo->prepare("SELECT q.*, s.first_name as hr_first, s.last_name as hr_last 
                              FROM `queries` q 
                              LEFT JOIN `staff` s ON q.issued_by = s.id 
                              WHERE q.staff_id = ? 
                              ORDER BY q.id DESC");
    $queries->execute([$user_id]);
    $queries_list = $queries->fetchAll();

    // Fetch replies map
    $query_ids = array_column($queries_list, 'id');
    $replies_map = [];
    if (count($query_ids) > 0) {
        $placeholders = implode(',', array_fill(0, count($query_ids), '?'));
        $replies_stmt = $pdo->prepare("SELECT * FROM `query_replies` WHERE `query_id` IN ($placeholders) ORDER BY `id` ASC");
        $replies_stmt->execute($query_ids);
        $replies = $replies_stmt->fetchAll();
        
        foreach ($replies as $rep) {
            $replies_map[$rep['query_id']][] = $rep;
        }
    }

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-envelope-open-text me-2"></i>My Queries & Warning Center</h2>
        <p class="text-muted">Review formal queries issued by HR and submit explanations or defense replies.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-12">
        <?php if (count($queries_list) > 0): ?>
            <?php foreach ($queries_list as $q): ?>
                <div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-header bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-danger text-white p-2 mb-1" style="font-size:0.7rem;"><?php echo htmlspecialchars($q['reason']); ?></span>
                            <h5 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars($q['title']); ?></h5>
                        </div>
                        <div class="text-end">
                            <span class="badge bg-<?php echo $q['status'] === 'Resolved' ? 'success' : ($q['status'] === 'Replied' ? 'info' : ($q['status'] === 'Escalated' ? 'danger' : 'warning')); ?> p-2 fs-6">
                                <?php echo $q['status']; ?>
                            </span>
                            <small class="text-danger fw-bold d-block mt-1">Reply Deadline: <?php echo format_date($q['deadline']); ?></small>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <div class="row">
                            <div class="col-md-8 border-end">
                                <p class="text-secondary small mb-2">Issued on <?php echo format_datetime($q['created_at']); ?> by: <strong><?php echo htmlspecialchars($q['hr_first'] . ' ' . $q['hr_last']); ?></strong></p>
                                
                                <div class="mt-2 p-3 bg-light rounded text-dark" style="white-space: pre-wrap; font-size:0.9rem;">
                                    <?php echo htmlspecialchars($q['description']); ?>
                                </div>
                                
                                <!-- Defense Responses -->
                                <h6 class="fw-bold text-aviation mt-4 mb-2"><i class="fa-solid fa-reply me-1"></i>My Defense statement:</h6>
                                <?php if (isset($replies_map[$q['id']])): ?>
                                    <?php foreach ($replies_map[$q['id']] as $rep): ?>
                                        <div class="p-3 bg-light border border-info-subtle rounded mb-2 text-dark" style="font-size:0.9rem;">
                                            <small class="text-muted float-end"><?php echo format_datetime($rep['created_at']); ?></small>
                                            <p class="mb-2"><?php echo nl2br(htmlspecialchars($rep['reply_text'])); ?></p>
                                            <?php if (!empty($rep['file_path'])): ?>
                                                <a href="<?php echo get_base_url() . '/' . $rep['file_path']; ?>" target="_blank" class="text-decoration-none text-aviation small fw-bold">
                                                    <i class="fa-solid fa-paperclip me-1"></i>Attached Defense Document
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted small">No defense replies submitted yet.</p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Reply action -->
                            <div class="col-md-4 ps-md-4 mt-3 mt-md-0 d-flex flex-column justify-content-end">
                                <?php if ($q['status'] !== 'Resolved'): ?>
                                    <button class="btn btn-aviation w-100 py-2" data-bs-toggle="modal" data-bs-target="#replyModal<?php echo $q['id']; ?>">
                                        <i class="fa-solid fa-pen-nib me-1"></i>Submit Defense Reply
                                    </button>
                                <?php else: ?>
                                    <div class="text-center text-success py-3">
                                        <i class="fa-solid fa-circle-check fa-2x mb-1 d-block"></i>
                                        <span class="small fw-bold">Resolved & Closed</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- REPLY MODAL -->
                <div class="modal fade" id="replyModal<?php echo $q['id']; ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header bg-aviation text-white">
                                <h5 class="modal-title fw-bold">Write Defense Statement: <?php echo htmlspecialchars($q['title']); ?></h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form method="POST" action="queries.php" enctype="multipart/form-data">
                                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                <input type="hidden" name="query_id" value="<?php echo $q['id']; ?>">
                                <div class="modal-body text-start">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold" for="defense_reply<?php echo $q['id']; ?>">Defense Reply Text *</label>
                                        <textarea class="form-control" id="defense_reply<?php echo $q['id']; ?>" name="reply_text" rows="6" placeholder="Provide complete facts, dates, and explanations in response to the allegations..." required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label fw-bold" for="attachment<?php echo $q['id']; ?>">Attach Evidence File (PDF, Image, Word - Max 5MB)</label>
                                        <input type="file" class="form-control" id="attachment<?php echo $q['id']; ?>" name="attachment" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                                        <div class="form-text" style="font-size:0.75rem;">Upload files to support your defense argument.</div>
                                    </div>
                                </div>
                                <div class="modal-footer bg-light">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" name="action" value="reply_query" class="btn btn-aviation btn-sm"><i class="fa-solid fa-paper-plane me-1"></i>Submit Defense</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card shadow-sm border-0 bg-white p-5 text-center" style="border-radius: 12px;">
                <i class="fa-solid fa-circle-check fa-4x text-success mb-3"></i>
                <h4 class="fw-bold text-aviation">No Disciplinary Queries active</h4>
                <p class="text-muted mb-0">Your record is clean. No warnings or queries have been issued to you.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
