<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff ESS - Clock In / Clock Out with GPS location check and face recognition
 */

require_once '../includes/auth.php';
require_feature('attendance');
require_login();

$user_id = (int)$_SESSION['user_id'];
$today = date('Y-m-d');
$now_time = date('H:i:s');
$success = '';
$error = '';

$require_gps = get_setting('require_gps', '1') === '1';
$require_face = get_setting('require_face_match', '1') === '1';
$require_photo = $require_face || get_setting('require_attendance_photo', '1') === '1';
$face_threshold = (float)get_setting('face_match_threshold', '0.45');
$allow_self_enrol = get_setting('allow_self_face_enrol', '1') === '1';

// Staff record (passport photo + face reference)
$me_stmt = $pdo->prepare("SELECT `id`, `passport_photo`, `face_photo`, `face_descriptor`, `face_descriptor_photo`, `face_source` FROM `staff` WHERE `id` = ?");
$me_stmt->execute([$user_id]);
$me = $me_stmt->fetch();
$reference = parse_face_descriptor($me['face_descriptor'] ?? '');
// A face captured live (registration / first clock-in) stays valid; one read from a passport photo only while that photo is unchanged
$reference_current = $reference && (in_array($me['face_source'] ?? '', ['registration', 'capture', 'hr-capture'], true)
    || ($me['face_descriptor_photo'] ?? '') === ($me['passport_photo'] ?? ''));
$auto_clock = get_setting('auto_clock_after_match', '1') === '1';

// ---- AJAX: build the face reference from the passport photo (done in the browser) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'enrol_face') {
    header('Content-Type: application/json');
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        echo json_encode(['ok' => false, 'error' => 'Security check failed. Reload the page.']);
        exit;
    }
    if (!$allow_self_enrol) {
        echo json_encode(['ok' => false, 'error' => 'Your face is not registered yet. Please ask HR to register it from your passport photo.']);
        exit;
    }
    if ($reference_current) {
        echo json_encode(['ok' => true, 'already' => true]);
        exit;
    }
    $desc = parse_face_descriptor($_POST['descriptor'] ?? '');
    $passport_desc = parse_face_descriptor($_POST['passport_descriptor'] ?? '');
    if (!$desc || !$passport_desc || empty($me['passport_photo'])) {
        echo json_encode(['ok' => false, 'error' => 'Could not read your face. Make sure you have a clear passport photo on your profile.']);
        exit;
    }
    if (face_distance($desc, $passport_desc) > FACE_PASSPORT_MAX) {
        log_activity($user_id, 'FACE_ENROL_REFUSED', 'First face registration refused: live face did not match passport photo');
        echo json_encode(['ok' => false, 'error' => 'Your face does not match your passport photo, so it cannot be registered. Please contact HR.']);
        exit;
    }
    [$fp, $fe] = save_data_url_image($_POST['photo'] ?? '', 'faces', 'face');
    $pdo->prepare("UPDATE `staff` SET `face_descriptor` = ?, `face_source` = 'capture', `face_photo` = ?, `face_descriptor_photo` = ?, `face_enrolled_by` = 'self', `face_enrolled_at` = NOW() WHERE `id` = ?")
        ->execute([json_encode($desc), $fp, $me['passport_photo'], $user_id]);
    log_activity($user_id, 'FACE_ENROLLED', 'Face registered from live camera (checked against passport photo)');
    echo json_encode(['ok' => true]);
    exit;
}

// Today's record
$stmt = $pdo->prepare("SELECT * FROM `attendance` WHERE `staff_id` = ? AND `date` = ?");
$stmt->execute([$user_id, $today]);
$attendance_record = $stmt->fetch();

// Standard office shift (or the first shift defined)
$shift = $pdo->query("SELECT * FROM `shifts` WHERE `name` LIKE '%Standard%' ORDER BY `id` LIMIT 1")->fetch();
if (!$shift) {
    $shift = $pdo->query("SELECT * FROM `shifts` ORDER BY `id` LIMIT 1")->fetch() ?: null;
}

$allowed_locations = staff_allowed_locations($user_id);

// ---- Clock in / out ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['action'] ?? '', ['clock_in', 'clock_out'], true)) {
    $action = $_POST['action'];
    $w = $action === 'clock_in' ? 'in' : 'out';
    $face_photo = null;
    $gps = ['location' => null, 'distance' => null];
    $lat = $_POST['gps_lat'] ?? '';
    $lng = $_POST['gps_lng'] ?? '';
    $acc = (float)($_POST['gps_accuracy'] ?? 99999);
    $face_score = null;

    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security check failed. Please reload the page.";
    } elseif ($action === 'clock_in' && $attendance_record) {
        $error = "You have already clocked in for today.";
    } elseif ($action === 'clock_out' && !$attendance_record) {
        $error = "You must clock in first before you can clock out.";
    } elseif ($action === 'clock_out' && !empty($attendance_record['clock_out'])) {
        $error = "You have already clocked out for today.";
    }

    // 1. GPS location
    if (!$error && ($require_gps || is_numeric($lat))) {
        $gps = check_gps_position($user_id, $lat, $lng, $acc);
        if (!$gps['ok'] && $require_gps) {
            $error = $gps['error'];
        }
    }

    // 2. Face recognition against the passport photo
    if (!$error && $require_face) {
        $live = parse_face_descriptor($_POST['face_descriptor'] ?? '');
        if (!$reference_current) {
            $error = "Your face is not registered yet. Reload this page and look at the camera to register it, or ask HR for help.";
        } elseif (!$live) {
            $error = "No face was detected in your photo. Look straight at the camera in good light and retake the photo.";
        } else {
            $face_score = face_distance($reference, $live);
            if ($face_score > $face_threshold) {
                log_activity($user_id, 'FACE_MISMATCH', sprintf("Clock-%s refused: face did not match passport photo (score %.3f > %.2f)", $w, $face_score, $face_threshold));
                $error = "Face not recognised: your photo does not match your passport photo. Retake it facing the camera in good light. If this keeps happening, ask HR to update your passport photo.";
            }
        }
    } elseif (!$error) {
        $live = parse_face_descriptor($_POST['face_descriptor'] ?? '');
        if ($live && $reference_current) $face_score = face_distance($reference, $live);
    }

    // 3. Save the captured photo
    if (!$error && ($require_photo || !empty($_POST['face_photo']))) {
        [$face_photo, $photo_err] = save_data_url_image($_POST['face_photo'] ?? '', 'attendance/' . date('Y-m'), "face_{$user_id}_{$w}");
        if ($photo_err) $error = $photo_err;
    }

    if (!$error) {
        $loc_id = $gps['location']['id'] ?? null;
        $loc_name = $gps['location']['name'] ?? 'no GPS';
        $gps_vals = [$loc_id, is_numeric($lat) ? $lat : null, is_numeric($lng) ? $lng : null, $acc < 99999 ? (int)round($acc) : null, $gps['distance'], $face_score];
        try {
            if ($action === 'clock_in') {
                $status = 'Present';
                if ($shift && strtotime($now_time) > strtotime($shift['start_time']) + 900) {
                    $status = 'Late';
                }
                $pdo->prepare("INSERT INTO `attendance` (`staff_id`, `date`, `clock_in`, `shift_id`, `status`, `ip_address`, `clock_in_photo`,
                               `clock_in_location_id`, `clock_in_lat`, `clock_in_lng`, `clock_in_accuracy`, `clock_in_distance`, `clock_in_face_score`)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
                    ->execute(array_merge([$user_id, $today, $now_time, $shift['id'] ?? null, $status, $_SERVER['REMOTE_ADDR'] ?? '', $face_photo], $gps_vals));
                log_activity($user_id, 'ATTENDANCE_CLOCK_IN', "Clocked in at $now_time at $loc_name" . ($face_score !== null ? sprintf(' (face %.3f)', $face_score) : ''));
                $success = "Clocked in at " . date('h:i A') . " - $loc_name. Status: $status";
            } else {
                $overtime = 0.00;
                if ($shift) {
                    $end = strtotime($shift['end_time']);
                    if ($end > strtotime($shift['start_time']) && strtotime($now_time) > $end) {
                        $overtime = round((strtotime($now_time) - $end) / 3600, 2);
                    }
                }
                $pdo->prepare("UPDATE `attendance` SET `clock_out` = ?, `overtime_hours` = ?, `clock_out_photo` = ?,
                               `clock_out_location_id` = ?, `clock_out_lat` = ?, `clock_out_lng` = ?, `clock_out_accuracy` = ?, `clock_out_distance` = ?, `clock_out_face_score` = ?
                               WHERE `staff_id` = ? AND `date` = ?")
                    ->execute(array_merge([$now_time, $overtime, $face_photo], $gps_vals, [$user_id, $today]));
                log_activity($user_id, 'ATTENDANCE_CLOCK_OUT', "Clocked out at $now_time at $loc_name (overtime $overtime h)");
                $success = "Clocked out at " . date('h:i A') . " - $loc_name. Overtime: $overtime hrs";
            }
        } catch (PDOException $e) {
            $error = "Could not save your attendance. Please try again.";
            error_log('Attendance save error: ' . $e->getMessage());
        }
    }

    if ($error && $face_photo) {
        delete_upload($face_photo);
    }
    header("Location: attendance.php?" . ($error ? "error=" . urlencode($error) : "success=" . urlencode($success)));
    exit;
}

// History (last 30 records)
$logs_stmt = $pdo->prepare("SELECT a.*, s.start_time AS shift_start, s.end_time AS shift_end, li.name AS in_loc, lo.name AS out_loc
                            FROM `attendance` a
                            LEFT JOIN `shifts` s ON a.shift_id = s.id
                            LEFT JOIN `attendance_locations` li ON li.id = a.clock_in_location_id
                            LEFT JOIN `attendance_locations` lo ON lo.id = a.clock_out_location_id
                            WHERE a.staff_id = ? ORDER BY a.date DESC LIMIT 30");
$logs_stmt->execute([$user_id]);
$history = $logs_stmt->fetchAll();

$needs_capture = !$attendance_record || empty($attendance_record['clock_out']);
$need_enrol = $require_face && !$reference_current;

require_once '../includes/header.php';
?>
<link rel="stylesheet" href="<?php echo get_base_url(); ?>/libs/leaflet/leaflet.css">

<div class="row mb-4">
    <div class="col-md-8">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-clock-rotate-left me-2"></i>Attendance Clock In/Out</h2>
        <p class="text-muted">Clock in at your work location. Your GPS position and face are checked automatically.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-5 col-md-6">
        <div class="card shadow-sm border-0 bg-white p-4 text-center glass-card" style="border-radius:16px;">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold text-aviation mb-0"><i class="fa-solid fa-business-time me-2"></i>Duty Clock</h5>
                <div class="text-end"><div id="liveTime" class="fw-bold text-aviation fs-4">00:00:00</div><div id="liveDate" class="text-secondary small"></div></div>
            </div>

            <?php if ($shift): ?>
                <div class="p-2 bg-light rounded text-start mb-3 border small">
                    <i class="fa-solid fa-calendar-day me-1 text-aviation"></i><strong><?php echo htmlspecialchars($shift['name']); ?></strong>
                    &middot; <?php echo date('H:i', strtotime($shift['start_time'])); ?> - <?php echo date('H:i', strtotime($shift['end_time'])); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="attendance.php" id="clockForm">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="face_photo" id="facePhoto">
                <input type="hidden" name="face_descriptor" id="faceDescriptor">
                <input type="hidden" name="gps_lat" id="gpsLat">
                <input type="hidden" name="gps_lng" id="gpsLng">
                <input type="hidden" name="gps_accuracy" id="gpsAcc">

                <?php if ($needs_capture): ?>
                <!-- Step 1: GPS -->
                <div class="text-start mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <label class="form-label fw-bold small mb-1"><i class="fa-solid fa-location-dot me-1"></i>1. Location <?php echo $require_gps ? '<span class="text-danger">*</span>' : '(optional)'; ?></label>
                        <button type="button" class="btn btn-link btn-sm p-0" id="btnGps"><i class="fa-solid fa-rotate me-1"></i>Refresh</button>
                    </div>
                    <div id="gpsStatus" class="alert alert-secondary py-2 small mb-2"><i class="fa-solid fa-spinner fa-spin me-1"></i>Getting your GPS location...</div>
                    <div id="gpsMap" class="border rounded" style="height:170px;"></div>
                </div>

                <!-- Step 2: Face -->
                <div class="mb-3 text-start">
                    <label class="form-label fw-bold small mb-1"><i class="fa-solid fa-face-smile me-1"></i>2. Face Recognition <?php echo $require_face ? '<span class="text-danger">*</span>' : ''; ?></label>
                    <div class="position-relative rounded overflow-hidden bg-dark mx-auto" style="max-width:320px;aspect-ratio:4/3;">
                        <video id="camVideo" autoplay playsinline muted style="width:100%;height:100%;object-fit:cover;transform:scaleX(-1);"></video>
                        <img id="camShot" class="d-none" style="width:100%;height:100%;object-fit:cover;transform:scaleX(-1);" alt="Captured face">
                        <div id="camMsg" class="position-absolute top-50 start-50 translate-middle text-white small text-center px-3">Starting camera...</div>
                        <div class="position-absolute top-50 start-50 translate-middle border border-2 border-light rounded-circle opacity-50" style="width:45%;aspect-ratio:3/4;pointer-events:none;" id="camGuide"></div>
                    </div>
                    <canvas id="camCanvas" class="d-none"></canvas>
                    <div class="d-flex gap-2 justify-content-center mt-2">
                        <button type="button" class="btn btn-sm btn-aviation" id="btnCapture" disabled><i class="fa-solid fa-camera me-1"></i>Capture</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary d-none" id="btnRetake"><i class="fa-solid fa-rotate me-1"></i>Retake</button>
                    </div>
                    <div id="faceStatus" class="small text-center mt-2 text-muted">Starting camera...</div>
                </div>
                <?php endif; ?>

                <?php if (!$attendance_record): ?>
                    <input type="hidden" name="action" value="clock_in">
                    <button type="submit" class="btn btn-aviation w-100 py-3 mb-2 fw-bold fs-5 shadow-sm clock-btn" id="clockBtn">
                        <i class="fa-solid fa-right-to-bracket me-2"></i>CLOCK IN
                    </button>
                <?php elseif (empty($attendance_record['clock_out'])): ?>
                    <div class="alert alert-success border-0 small text-start py-2 mb-3">
                        <i class="fa-solid fa-circle-check me-1"></i> On duty since <strong><?php echo date('h:i A', strtotime($attendance_record['clock_in'])); ?></strong>
                    </div>
                    <input type="hidden" name="action" value="clock_out">
                    <button type="submit" class="btn btn-danger w-100 py-3 mb-2 fw-bold fs-5 shadow-sm clock-btn" id="clockBtn">
                        <i class="fa-solid fa-right-from-bracket me-2"></i>CLOCK OUT
                    </button>
                <?php else: ?>
                    <div class="alert alert-secondary border-0 text-start py-3 mb-0">
                        <h6 class="fw-bold text-dark mb-2"><i class="fa-solid fa-circle-info me-1"></i>Completed Today</h6>
                        <p class="mb-1 small">Clock In: <strong><?php echo date('h:i A', strtotime($attendance_record['clock_in'])); ?></strong></p>
                        <p class="mb-1 small">Clock Out: <strong><?php echo date('h:i A', strtotime($attendance_record['clock_out'])); ?></strong></p>
                        <p class="mb-0 small">Overtime: <strong><?php echo $attendance_record['overtime_hours'] ?? '0.00'; ?> hrs</strong></p>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="col-lg-7 col-md-6">
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i>My Attendance Log</h5>
            <?php if ($history): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.82rem;vertical-align:middle;">
                        <thead><tr><th>Date</th><th>In</th><th>Out</th><th>Location</th><th>Status</th><th>Photos</th></tr></thead>
                        <tbody>
                        <?php foreach ($history as $row):
                            $badge = ['Late' => 'bg-warning text-dark', 'Absent' => 'bg-danger', 'Half Day' => 'bg-secondary'][$row['status']] ?? 'bg-success'; ?>
                            <tr>
                                <td class="fw-bold text-nowrap"><?php echo format_date($row['date']); ?></td>
                                <td><code><?php echo $row['clock_in'] ? date('H:i', strtotime($row['clock_in'])) : '--:--'; ?></code></td>
                                <td><code><?php echo $row['clock_out'] ? date('H:i', strtotime($row['clock_out'])) : '--:--'; ?></code></td>
                                <td class="small"><?php echo htmlspecialchars($row['in_loc'] ?? '—'); ?><?php echo ($row['out_loc'] && $row['out_loc'] !== $row['in_loc']) ? '<br><span class="text-muted">out: ' . htmlspecialchars($row['out_loc']) . '</span>' : ''; ?></td>
                                <td><span class="badge <?php echo $badge; ?>"><?php echo $row['status']; ?></span></td>
                                <td class="text-nowrap">
                                    <?php foreach (['clock_in_photo' => 'In', 'clock_out_photo' => 'Out'] as $col => $lbl): if (!empty($row[$col])): ?>
                                        <a href="<?php echo photo_url($row[$col]); ?>" target="_blank" title="<?php echo $lbl; ?>"><img src="<?php echo photo_url($row[$col]); ?>" class="rounded border" style="width:30px;height:30px;object-fit:cover;" alt="<?php echo $lbl; ?>"></a>
                                    <?php endif; endforeach; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">No attendance records yet.</p>
            <?php endif; ?>
        </div>
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:16px;">
            <h6 class="fw-bold text-aviation mb-2"><i class="fa-solid fa-map-location-dot me-2"></i>Where I can clock in (<?php echo count($allowed_locations); ?>)</h6>
            <?php if ($allowed_locations): ?>
                <div class="small" style="max-height:120px;overflow:auto;"><?php echo implode(' &middot; ', array_map(fn($l) => htmlspecialchars($l['name']) . ' <span class="text-muted">(' . number_format($l['radius_m']) . ' m)</span>', $allowed_locations)); ?></div>
            <?php else: ?>
                <div class="small text-danger">No work location is set up for you. Please contact HR.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="<?php echo get_base_url(); ?>/libs/leaflet/leaflet.js"></script>
<?php if ($needs_capture): ?>
<script src="<?php echo base_path(); ?>/libs/face-api/face-api.js"></script>
<script src="<?php echo base_path(); ?>/assets/js/face-detect.js?v=<?php echo get_asset_version('assets/js/face-detect.js'); ?>"></script>
<?php endif; ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    function tick() {
        const n = new Date();
        document.getElementById('liveTime').textContent = n.toTimeString().slice(0, 8);
        document.getElementById('liveDate').textContent = n.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    }
    tick(); setInterval(tick, 1000);
});

<?php if ($needs_capture): ?>
(function () {
    const CFG = {
        base: <?php echo json_encode(base_path()); ?>,
        csrf: <?php echo json_encode(generate_csrf_token()); ?>,
        requireGps: <?php echo $require_gps ? 'true' : 'false'; ?>,
        requireFace: <?php echo $require_face ? 'true' : 'false'; ?>,
        requirePhoto: <?php echo $require_photo ? 'true' : 'false'; ?>,
        threshold: <?php echo json_encode($face_threshold); ?>,
        needEnrol: <?php echo $need_enrol ? 'true' : 'false'; ?>,
        autoClock: <?php echo $auto_clock ? 'true' : 'false'; ?>,
        passportMax: <?php echo FACE_PASSPORT_MAX; ?>,
        selfEnrol: <?php echo $allow_self_enrol ? 'true' : 'false'; ?>,
        hasReference: <?php echo $reference_current ? 'true' : 'false'; ?>,
        reference: <?php echo $reference_current ? json_encode($reference) : 'null'; ?>,
        // Photo used to set up the face the first time: the registration capture if there is one, otherwise the passport
        passport: <?php echo json_encode(upload_path_url($me['face_photo'] ?? '') ?: upload_path_url($me['passport_photo'] ?? '')); ?>,
        maxAcc: <?php echo intval(get_setting('gps_max_accuracy', '1000')); ?>,
        locations: <?php echo json_encode(array_map(fn($l) => ['name' => $l['name'], 'lat' => (float)$l['latitude'], 'lng' => (float)$l['longitude'], 'r' => (int)$l['radius_m']], $allowed_locations)); ?>
    };
    const $ = (id) => document.getElementById(id);
    const state = { gpsOk: !CFG.requireGps, faceOk: !CFG.requireFace, modelsReady: false };

    function updateButton() {
        const btn = $('clockBtn');
        if (btn) btn.disabled = !(state.gpsOk && (state.faceOk || !CFG.requireFace));
    }

    // ---------------- GPS ----------------
    let map = null, meMarker = null, accCircle = null;
    function distance(a, b, c, d) {
        const R = 6371000, toR = Math.PI / 180;
        const x = Math.sin((c - a) * toR / 2) ** 2 + Math.cos(a * toR) * Math.cos(c * toR) * Math.sin((d - b) * toR / 2) ** 2;
        return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
    }
    function initMap(lat, lng) {
        if (typeof L === 'undefined') return;
        if (!map) {
            map = L.map('gpsMap', { zoomControl: false, attributionControl: false }).setView([lat, lng], 15);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
            CFG.locations.forEach(l => L.circle([l.lat, l.lng], { radius: l.r, color: '#2d6a4f', fillOpacity: 0.15 }).addTo(map).bindTooltip(l.name));
        }
        if (meMarker) { meMarker.setLatLng([lat, lng]); } else { meMarker = L.circleMarker([lat, lng], { radius: 7, color: '#0d6efd', fillOpacity: 1 }).addTo(map); }
        map.setView([lat, lng], 16);
    }
    function setGps(html, cls) { const el = $('gpsStatus'); el.className = 'alert py-2 small mb-2 ' + cls; el.innerHTML = html; }
    function readGps() {
        if (!navigator.geolocation) { setGps('This browser cannot read GPS location.', 'alert-danger'); return; }
        if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
            setGps('GPS only works on a secure (https://) address. Please ask the administrator to enable SSL.', 'alert-danger'); return;
        }
        setGps('<i class="fa-solid fa-spinner fa-spin me-1"></i>Getting your GPS location...', 'alert-secondary');
        navigator.geolocation.getCurrentPosition(function (p) {
            const lat = p.coords.latitude, lng = p.coords.longitude, acc = p.coords.accuracy;
            $('gpsLat').value = lat; $('gpsLng').value = lng; $('gpsAcc').value = Math.round(acc);
            initMap(lat, lng);
            if (accCircle) accCircle.setLatLng([lat, lng]).setRadius(acc); else if (map) accCircle = L.circle([lat, lng], { radius: acc, color: '#0d6efd', weight: 1, fillOpacity: 0.05 }).addTo(map);
            let best = null, bestD = Infinity, near = null, nearD = Infinity;
            CFG.locations.forEach(l => {
                const d = distance(lat, lng, l.lat, l.lng);
                if (d - Math.min(acc, 100) <= l.r && d < bestD) { best = l; bestD = d; }
                if (d < nearD) { near = l; nearD = d; }
            });
            const fmt = (m) => m >= 1000 ? (m / 1000).toFixed(1) + ' km' : Math.round(m) + ' m';
            if (acc > CFG.maxAcc) {
                state.gpsOk = !CFG.requireGps;
                setGps('<i class="fa-solid fa-triangle-exclamation me-1"></i>GPS signal too weak (about ' + fmt(acc) + '). Turn on precise location, move near a window, then press Refresh.', 'alert-warning');
            } else if (best) {
                state.gpsOk = true;
                setTimeout(maybeAutoClock, 50);
                setGps('<i class="fa-solid fa-circle-check me-1"></i>You are at <strong>' + best.name.replace(/</g, '&lt;') + '</strong> (' + fmt(bestD) + ' from centre, accuracy ' + fmt(acc) + ').', 'alert-success');
            } else {
                state.gpsOk = !CFG.requireGps;
                setGps('<i class="fa-solid fa-circle-xmark me-1"></i>You are not at an approved location.' + (near ? ' Nearest: <strong>' + near.name.replace(/</g, '&lt;') + '</strong>, ' + fmt(nearD) + ' away (allowed ' + near.r + ' m).' : ''), CFG.requireGps ? 'alert-danger' : 'alert-warning');
            }
            updateButton();
        }, function (err) {
            state.gpsOk = !CFG.requireGps;
            const tips = { 1: 'Location permission was denied. Allow location for this site in your browser settings, then press Refresh.', 2: 'Location is unavailable. Turn on GPS / Location Services.', 3: 'GPS took too long. Press Refresh.' };
            setGps('<i class="fa-solid fa-circle-xmark me-1"></i>' + (tips[err.code] || err.message), CFG.requireGps ? 'alert-danger' : 'alert-warning');
            updateButton();
        }, { enableHighAccuracy: true, timeout: 25000, maximumAge: 0 });
    }
    $('btnGps').addEventListener('click', readGps);

    // ---------------- Camera: press Capture, the still photo is recognised ----------------
    const video = $('camVideo'), shot = $('camShot'), canvas = $('camCanvas');
    const setFace = (t, cls) => { const el = $('faceStatus'); el.className = 'small text-center mt-2 ' + (cls || 'text-muted'); el.innerHTML = t; };
    let stream = null, reference = CFG.reference ? new Float32Array(CFG.reference) : null, passportDesc = null, autoTimer = null;

    function startCamera() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            $('camMsg').textContent = location.protocol !== 'https:' ? 'The camera needs a secure (https://) connection.' : 'This browser cannot use the camera.';
            return;
        }
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } }, audio: false })
            .then(s => { stream = s; video.srcObject = s; $('camMsg').textContent = ''; $('btnCapture').disabled = false;
                         setFace('Look straight at the camera and press <strong>Capture</strong>.', 'text-primary'); })
            .catch(() => { $('camMsg').textContent = 'Camera blocked or not found. Allow camera access, then reload the page.'; });
    }

    // Face recognition loads in the background
    const modelsReady = CFG.requireFace ? umzaFace.init(CFG.base + '/libs/face-api/model') : Promise.resolve();
    modelsReady.catch(() => {});

    async function getEnrolReference() {
        if (passportDesc) return passportDesc;
        if (!CFG.selfEnrol) throw new Error('Your face is not registered yet. Please ask HR to register it.');
        if (!CFG.passport) throw new Error('You have no passport photo on file. Upload one on your profile first.');
        await umzaFace.loadSsd().catch(() => {});
        const img = await faceapi.fetchImage(CFG.passport);
        const det = await umzaFace.detect(img);
        if (!det) throw new Error('No clear face was found in your registered photo. Please ask HR to update your passport photo.');
        passportDesc = det.descriptor;
        return passportDesc;
    }

    async function enrol(desc) {
        const body = new URLSearchParams({ action: 'enrol_face', csrf_token: CFG.csrf, descriptor: JSON.stringify(Array.from(desc)),
            passport_descriptor: JSON.stringify(Array.from(passportDesc)), photo: $('facePhoto').value });
        const r = await fetch('attendance.php', { method: 'POST', body, credentials: 'same-origin' }).then(x => x.json());
        if (!r.ok) throw new Error(r.error || 'Could not register your face.');
        reference = desc;
    }

    function showShot() {
        $('facePhoto').value = canvas.toDataURL('image/jpeg', 0.85);
        shot.src = $('facePhoto').value;
        shot.classList.remove('d-none'); video.classList.add('d-none'); $('camGuide').classList.add('d-none');
        $('btnCapture').classList.add('d-none'); $('btnRetake').classList.remove('d-none');
    }

    async function capture() {
        if (!stream || video.readyState < 2) { setFace('Camera is not ready yet. Allow camera access, wait a second and try again.', 'text-warning'); return; }
        const btn = $('btnCapture'); btn.disabled = true;
        umzaFace.grab(video, canvas);
        if (umzaFace.brightness(canvas) < 25) {
            setFace('<i class="fa-solid fa-triangle-exclamation me-1"></i>The picture is too dark (or the camera is not ready). Turn on a light and press Capture again.', 'text-danger');
            btn.disabled = false; return;
        }
        showShot();
        $('faceDescriptor').value = '';
        state.faceOk = !CFG.requireFace;
        if (!CFG.requireFace) { setFace('Photo taken.', 'text-success'); btn.disabled = false; updateButton(); maybeAutoClock(); return; }

        setFace('<i class="fa-solid fa-spinner fa-spin me-1"></i>Photo taken. Recognising your face...', 'text-primary');
        try {
            await modelsReady;
            const det = await umzaFace.detect(canvas);
            if (!det) {
                setFace('<i class="fa-solid fa-triangle-exclamation me-1"></i>No face found in the photo. Press <strong>Retake</strong>, move closer and face a light (not a window behind you).', 'text-danger');
            } else {
                if (!reference) {
                    setFace('<i class="fa-solid fa-spinner fa-spin me-1"></i>First time: setting up your face...', 'text-primary');
                    const ref = await getEnrolReference();
                    if (faceapi.euclideanDistance(ref, det.descriptor) > CFG.passportMax) {
                        throw new Error('This face does not match your registered photo. Retake facing the camera, or ask HR to update your photo.');
                    }
                    await enrol(det.descriptor);
                }
                const d = faceapi.euclideanDistance(reference, det.descriptor);
                if (d <= CFG.threshold) {
                    $('faceDescriptor').value = JSON.stringify(Array.from(det.descriptor));
                    state.faceOk = true;
                    setFace('<i class="fa-solid fa-circle-check me-1"></i>Face recognised (match ' + Math.round((1 - d) * 100) + '%).', 'text-success fw-bold');
                } else {
                    setFace('<i class="fa-solid fa-triangle-exclamation me-1"></i>Face not recognised. Press <strong>Retake</strong>, face the camera directly in good light, remove cap or dark glasses.', 'text-danger');
                }
            }
        } catch (e) {
            setFace('<i class="fa-solid fa-circle-xmark me-1"></i>' + (e.message || umzaFace.lastError) +
                ' <br><a href="#" id="retryFace">Try again</a>', 'text-danger');
            const r = document.getElementById('retryFace');
            if (r) r.addEventListener('click', function (ev) { ev.preventDefault(); location.reload(); });
        }
        btn.disabled = false;
        updateButton();
        maybeAutoClock();
    }

    function maybeAutoClock() {
        const btn = $('clockBtn');
        if (!CFG.autoClock || autoTimer || !btn || btn.disabled || !state.gpsOk || !state.faceOk || !$('facePhoto').value) return;
        let n = 3;
        const label = btn.innerHTML;
        const show = () => btn.innerHTML = '<i class="fa-solid fa-circle-check me-2"></i>Confirmed - recording in ' + n + '... (tap to record now)';
        show();
        autoTimer = setInterval(function () {
            n--;
            if (n <= 0) { clearInterval(autoTimer); btn.innerHTML = label; $('clockForm').requestSubmit ? $('clockForm').requestSubmit(btn) : $('clockForm').submit(); }
            else show();
        }, 1000);
    }

    function retake() {
        if (autoTimer) { clearInterval(autoTimer); autoTimer = null; }
        $('facePhoto').value = ''; $('faceDescriptor').value = '';
        state.faceOk = !CFG.requireFace;
        shot.classList.add('d-none'); video.classList.remove('d-none'); $('camGuide').classList.remove('d-none');
        $('btnCapture').classList.remove('d-none'); $('btnRetake').classList.add('d-none');
        setFace('Look straight at the camera and press <strong>Capture</strong>.', 'text-primary');
        updateButton();
    }
    $('btnCapture').addEventListener('click', capture);
    $('btnRetake').addEventListener('click', retake);

    $('clockForm').addEventListener('submit', function (e) {
        let msg = '';
        if (CFG.requireGps && !state.gpsOk) msg = 'You must be at your approved work location (check the Location box).';
        else if (CFG.requirePhoto && !$('facePhoto').value) msg = 'Please look at the camera so your face can be captured.';
        else if (CFG.requireFace && !state.faceOk) msg = 'Your face must be recognised before you can clock in or out.';
        if (msg) { e.preventDefault(); e.stopImmediatePropagation(); if (autoTimer) clearInterval(autoTimer); alert(msg); }
    }, true);
    window.addEventListener('beforeunload', () => { if (stream) stream.getTracks().forEach(t => t.stop()); });

    updateButton();
    readGps();
    startCamera();
})();
<?php endif; ?>
</script>

<?php require_once '../includes/footer.php'; ?>
