<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff View Memos & Circulars
 */

require_once '../includes/header.php';
require_feature('memos');

$user_id = $_SESSION['user_id'];

try {
    // Fetch all published memos
    // Company-wide memos plus memos sent to my department
    $stmt = $pdo->prepare("SELECT m.*, s.first_name, s.last_name, s.display_name, s.role, d.name AS dept_name
                          FROM `memos` m 
                          LEFT JOIN `staff` s ON m.created_by = s.id 
                          LEFT JOIN `departments` d ON m.department_id = d.id
                          WHERE m.status = 'Published' AND (m.audience = 'All' OR m.department_id = ? OR m.created_by = ?)
                          ORDER BY m.id DESC");
    $stmt->execute([$_SESSION['department_id'] ?? 0, $user_id]);
    $memos = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-bullhorn me-2"></i>Memos & Circulars</h2>
        <p class="text-muted">Stay informed with the latest policy directives, announcements, and corporate news.</p>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <?php if (count($memos) > 0): ?>
            <?php foreach ($memos as $m): ?>
                <div class="card shadow-sm border-0 mb-4 bg-white" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-header bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-aviation text-white p-2 mb-1" style="font-size:0.7rem;"><?php echo htmlspecialchars($m['type']); ?></span>
                            <?php if (($m['audience'] ?? 'All') === 'Department'): ?>
                                <span class="badge bg-warning text-dark p-2 mb-1" style="font-size:0.7rem;"><i class="fa-solid fa-users me-1"></i><?php echo htmlspecialchars($m['dept_name'] ?? 'Department'); ?> only</span>
                            <?php endif; ?>
                            <h5 class="fw-bold mb-0 text-aviation"><?php echo htmlspecialchars($m['title']); ?></h5>
                        </div>
                        <div class="text-end">
                            <small class="text-secondary d-block"><?php echo format_datetime($m['created_at']); ?></small>
                            <small class="text-muted">By: HR Administration</small>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <div class="row">
                            <div class="col-md-9 border-end">
                                <div class="text-dark" style="white-space: pre-wrap; font-size:0.9rem;">
                                    <?php echo htmlspecialchars($m['content']); ?>
                                </div>
                            </div>
                            <div class="col-md-3 ps-md-4 mt-3 mt-md-0 d-flex flex-column justify-content-between align-items-start">
                                <div>
                                    <h6 class="fw-bold text-aviation border-bottom pb-2 w-100"><i class="fa-solid fa-paperclip me-1"></i>Attachments</h6>
                                    <a href="<?php echo get_base_url(); ?>/staff/print-memo.php?id=<?php echo $m['id']; ?>" target="_blank" class="btn btn-sm btn-outline-dark w-100 mb-2"><i class="fa-solid fa-file-signature me-1"></i>Official Copy (Letterhead)</a>

                                     <?php if (!empty($m['file_path'])): ?>
                                         <?php 
                                         $ext = strtolower(pathinfo($m['file_path'], PATHINFO_EXTENSION));
                                         $file_name = basename($m['file_path']);
                                         ?>
                                         <div class="d-flex flex-column gap-2 w-100">
                                             <a href="<?php echo get_base_url() . '/' . $m['file_path']; ?>" target="_blank" class="btn btn-sm btn-outline-aviation w-100">
                                                 <i class="fa-solid fa-eye me-1"></i>View Inline
                                             </a>
                                             <a href="<?php echo get_base_url() . '/' . $m['file_path']; ?>" download="<?php echo htmlspecialchars($file_name); ?>" class="btn btn-sm btn-aviation w-100">
                                                 <i class="fa-solid fa-download me-1"></i>Download File
                                             </a>
                                         </div>
                                     <?php else: ?>
                                         <p class="text-muted small">No circular attachments.</p>
                                     <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card shadow-sm border-0 bg-white p-5 text-center" style="border-radius: 12px;">
                <i class="fa-solid fa-bullhorn fa-4x text-success mb-3"></i>
                <h4 class="fw-bold text-aviation">No Broadcasts Active</h4>
                <p class="text-muted mb-0">No company-wide memos or circulars have been published yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
