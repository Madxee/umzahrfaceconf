<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Grievance & Complaints submissions
 */

require_once '../includes/auth.php';
require_feature('complaints');
require_once '../includes/mail.php';
require_login();

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Handle complaint submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_complaint') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $type = $_POST['type'] ?? '';
    $description = trim($_POST['description'] ?? '');
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } elseif (isset($_SESSION['processed_csrf']) && $_SESSION['processed_csrf'] === $csrf_token) {
        header("Location: dashboard.php?success=" . urlencode("Your complaint has been logged successfully. You will receive email alerts as HR processes this case."));
        exit;
    } elseif (empty($title) || empty($type) || empty($description)) {
        $error = "Please fill in all complaint details.";
    } else {
        // Mark CSRF immediately to prevent concurrent duplicate submissions
        $_SESSION['processed_csrf'] = $csrf_token;
        
        try {
            // Generate Unique Tracking Code: CMP-[HEX]
            $tracking_number = 'CMP-' . strtoupper(bin2hex(random_bytes(3)));
            
            $pdo->beginTransaction();
            
            // Insert complaint
            $stmt = $pdo->prepare("INSERT INTO `complaints` (`tracking_number`, `staff_id`, `type`, `title`, `description`, `status`) 
                                   VALUES (?, ?, ?, ?, ?, 'Pending')");
            $stmt->execute([$tracking_number, $user_id, $type, $title, $description]);
            $complaint_id = $pdo->lastInsertId();
            
            // Handle file attachments (supporting docs, PDF, images)
            if (isset($_FILES['attachments']) && count($_FILES['attachments']['name']) > 0 && !empty($_FILES['attachments']['name'][0])) {
                $files = $_FILES['attachments'];
                
                for ($i = 0; $i < count($files['name']); $i++) {
                    $file_name = $files['name'][$i];
                    $file_tmp = $files['tmp_name'][$i];
                    $file_size = $files['size'][$i];
                    $file_err = $files['error'][$i];
                    
                    if ($file_err === UPLOAD_ERR_OK) {
                        $file_mime = get_file_mime($file_tmp, $files['type'][$i] ?? '');
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        
                        if ($file_size > UPLOAD_MAX_SIZE) {
                            throw new Exception("File {$file_name} exceeds 5MB size limit.");
                        } elseif (!in_array($file_ext, ALLOWED_EXTENSIONS) || !in_array($file_mime, ALLOWED_MIMES)) {
                            throw new Exception("File {$file_name} has an invalid type. Only PDF, JPG, PNG, DOC, and DOCX are allowed.");
                        } else {
                            $new_filename = 'complaint_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                            $upload_dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . 'complaints';
                            
                            if (!is_dir($upload_dir)) {
                                @mkdir($upload_dir, 0755, true);
                            }
                            
                            $dest_path = $upload_dir . DIRECTORY_SEPARATOR . $new_filename;
                            
                            if (move_uploaded_file($file_tmp, $dest_path)) {
                                $db_path = 'uploads/complaints/' . $new_filename;
                                $file_stmt = $pdo->prepare("INSERT INTO `complaint_files` (`complaint_id`, `file_name`, `file_path`, `file_type`) 
                                                             VALUES (?, ?, ?, ?)");
                                $file_stmt->execute([$complaint_id, $file_name, $db_path, $file_mime]);
                            } else {
                                throw new Exception("Failed to save uploaded file: {$file_name}.");
                            }
                        }
                    }
                }
            }
            
            $pdo->commit();
            
            log_activity($user_id, 'COMPLAINT_SUBMITTED', "Submitted complaint {$tracking_number}: $title");
            
            // Send email to HR Admins
            $hr_stmt = $pdo->query("SELECT `email`, `first_name` FROM `staff` WHERE `role` IN ('Super Admin', 'HR Director', 'HR Manager') AND `status` = 'Active'");
            $hr_admins = $hr_stmt->fetchAll();
            $employee_name = $_SESSION['name'];
            
            $hr_subject = "New Grievance Submitted - Tracking #$tracking_number";
            $hr_body = "
                <p>A new employee grievance has been filed on the HR Portal:</p>
                <ul>
                    <li><strong>Tracking Code:</strong> $tracking_number</li>
                    <li><strong>Submitted By:</strong> $employee_name</li>
                    <li><strong>Category:</strong> $type</li>
                    <li><strong>Subject:</strong> " . htmlspecialchars($title) . "</li>
                </ul>
                <p>Please log in to review and respond to this complaint.</p>
                <p><a href='" . get_base_url() . "/admin/complaints.php' class='btn'>Go to Complaints Board</a></p>";
            
            foreach ($hr_admins as $admin) {
                send_email($admin['email'], $admin['first_name'], $hr_subject, $hr_body);
            }
            
            $success = "Your complaint has been logged successfully under Tracking ID: <strong>$tracking_number</strong>. You will receive email alerts as HR processes this case.";
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
            unset($_SESSION['processed_csrf']); // Allow retry on failure
        }
    }
    
    // Redirect
    if (empty($error)) {
        header("Location: dashboard.php?success=" . urlencode($success));
    } else {
        header("Location: complaints.php?error=" . urlencode($error));
    }
    exit;
}

// Fetch user complaints
try {
    $stmt = $pdo->prepare("SELECT * FROM `complaints` WHERE `staff_id` = ? ORDER BY `id` DESC");
    $stmt->execute([$user_id]);
    $complaints = $stmt->fetchAll();

    // Fetch all attachments for displayed complaints to avoid N+1 queries
    $attachments_map = [];
    if (!empty($complaints)) {
        $complaint_ids = array_column($complaints, 'id');
        $in_clause = implode(',', array_fill(0, count($complaint_ids), '?'));
        $files_stmt = $pdo->prepare("SELECT * FROM `complaint_files` WHERE `complaint_id` IN ($in_clause)");
        $files_stmt->execute($complaint_ids);
        while ($row = $files_stmt->fetch()) {
            $attachments_map[$row['complaint_id']][] = $row;
        }
    }
} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-triangle-exclamation me-2"></i>My Complaints & Grievances</h2>
        <p class="text-muted">File a formal grievance, upload documents/evidence, and monitor resolution logs.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Submit New Complaint -->
    <div class="col-lg-5 col-md-6">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-square-plus me-2"></i>Submit Grievance</h5>
            <form method="POST" action="complaints.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="submit_complaint">
                
                <div class="mb-3">
                    <label class="form-label fw-bold" for="type">Complaint Category *</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="">Select Category</option>
                        <option value="HR Complaint">HR Complaint</option>
                        <option value="Management Complaint">Management Complaint</option>
                        <option value="Payroll Complaint">Payroll Complaint</option>
                        <option value="Workplace Complaint">Workplace Complaint</option>
                        <option value="Other Complaint">Other Complaint</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="title">Subject / Title *</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="Summary of grievance" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="description">Detailed Description *</label>
                    <textarea class="form-control" id="description" name="description" rows="5" placeholder="Describe the incident in detail, including dates, names, and facts..." required></textarea>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold" for="attachments">Attach Evidence Documents (PDF, Images - Max 5MB, Multi-upload)</label>
                    <input type="file" class="form-control" id="attachments" name="attachments[]" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" multiple>
                    <div class="form-text" style="font-size:0.75rem;">Hold Ctrl to upload multiple files. Only PDF, DOCX, and image formats allowed.</div>
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-paper-plane me-1"></i>File Complaint</button>
            </form>
        </div>
    </div>

    <!-- Right Column: Complaints List -->
    <div class="col-lg-7 col-md-6">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-clock-rotate-left me-2"></i>My Grievance History</h5>
            <?php if (count($complaints) > 0): ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($complaints as $c): ?>
                        <div class="list-group-item px-0 py-3">
                            <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                                <h6 class="mb-0 fw-bold text-aviation"><?php echo htmlspecialchars($c['title']); ?></h6>
                                <span class="badge bg-<?php echo $c['status'] === 'Resolved' ? 'success' : ($c['status'] === 'Closed' ? 'secondary' : ($c['status'] === 'Under Review' ? 'info' : 'warning')); ?>">
                                    <?php echo $c['status']; ?>
                                </span>
                            </div>
                            <small class="text-secondary d-block mb-2">Tracking ID: <strong><?php echo htmlspecialchars($c['tracking_number']); ?></strong> | Category: <?php echo htmlspecialchars($c['type']); ?> | Date: <?php echo format_date($c['created_at']); ?></small>
                            <p class="text-muted small mb-2 bg-light p-2 rounded"><?php echo nl2br(htmlspecialchars($c['description'])); ?></p>
                            
                            <?php if (!empty($c['hr_response'])): ?>
                                <div class="mt-2 p-2 border border-success-subtle bg-success-subtle rounded small text-dark mb-3">
                                    <strong><i class="fa-solid fa-reply me-1"></i>HR response:</strong>
                                    <p class="mb-0 mt-1"><?php echo nl2br(htmlspecialchars($c['hr_response'])); ?></p>
                                </div>
                            <?php endif; ?>

                            <!-- Attachments -->
                            <?php if (isset($attachments_map[$c['id']])): ?>
                                <div class="mt-2 mb-1">
                                    <span class="d-block small text-secondary fw-bold mb-1"><i class="fa-solid fa-paperclip me-1"></i>Uploaded Attachments:</span>
                                    <div class="row g-2">
                                        <?php foreach ($attachments_map[$c['id']] as $file): ?>
                                            <div class="col-md-6">
                                                <div class="d-flex align-items-center justify-content-between p-2 bg-light rounded border" style="font-size: 0.78rem;">
                                                    <span class="text-wrap text-aviation fw-semibold text-truncate" style="max-width: 60%;" title="<?php echo htmlspecialchars($file['file_name']); ?>">
                                                        <i class="fa-solid fa-file-lines me-1"></i>
                                                        <?php echo htmlspecialchars($file['file_name']); ?>
                                                    </span>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="<?php echo get_base_url() . '/' . $file['file_path']; ?>" target="_blank" class="btn btn-outline-aviation btn-sm py-0 px-2" title="View Document">
                                                            <i class="fa-solid fa-eye" style="font-size: 0.75rem;"></i> View
                                                        </a>
                                                        <a href="<?php echo get_base_url() . '/' . $file['file_path']; ?>" download="<?php echo htmlspecialchars($file['file_name']); ?>" class="btn btn-aviation btn-sm py-0 px-2" title="Download Document">
                                                            <i class="fa-solid fa-download" style="font-size: 0.75rem;"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">No complaints submitted yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
