<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Leave Requests Panel
 */

require_once '../includes/auth.php';
require_feature('leave');
require_once '../includes/mail.php';
require_login();

$user_id = $_SESSION['user_id'];
$current_year = intval(date('Y'));
$error = '';
$success = '';

// Handle Leave Request Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'request_leave') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $leave_type = $_POST['leave_type'] ?? '';
    $start_date = $_POST['start_date'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $reason = trim($_POST['reason'] ?? '');
    
    if (!verify_csrf_token($csrf_token)) {
        $error = "CSRF verification failed.";
    } elseif (empty($leave_type) || empty($start_date) || empty($end_date) || empty($reason)) {
        $error = "Please fill in all leave request fields.";
    } else {
        $start_ts = strtotime($start_date);
        $end_ts = strtotime($end_date);
        
        if ($start_ts === false || $end_ts === false) {
            $error = "Please provide valid date inputs.";
        } elseif ($start_ts > $end_ts) {
            $error = "Start date cannot be after the end date.";
        } elseif ($start_ts < strtotime(date('Y-m-d'))) {
            $error = "Start date cannot be in the past.";
        } else {
            // Calculate duration in days: (end - start) / 86400 + 1
            $duration = round(($end_ts - $start_ts) / 86400) + 1;
            
            try {
                // Check current quota
                $quota_stmt = $pdo->prepare("SELECT * FROM `leave_quotas` WHERE `staff_id` = ? AND `year` = ?");
                $quota_stmt->execute([$user_id, $current_year]);
                $quota = $quota_stmt->fetch();
                
                $allocated = $quota ? $quota['allocated'] : intval(get_setting('default_annual_leave_quota', 30));
                $remaining = $quota ? $quota['remaining'] : $allocated;
                
                if ($leave_type === 'Annual Leave' && $duration > $remaining) {
                    $error = "Request failed. You have applied for $duration days, but your remaining Annual Leave balance is only $remaining days.";
                } else {
                    // Handle Optional Attachment Upload
                    $attachment_path = null;
                    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['attachment']['tmp_name'];
                        $file_name = $_FILES['attachment']['name'];
                        $file_size = $_FILES['attachment']['size'];
                        
                        $file_mime = get_file_mime($file_tmp, $_FILES['attachment']['type'] ?? '');
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'pdf'];
                        
                        if ($file_size > UPLOAD_MAX_SIZE) {
                            $error = "Attachment size exceeds 5MB limit.";
                        } elseif (!in_array($file_ext, $allowed_exts, true) || (!str_starts_with($file_mime, 'image/') && $file_mime !== 'application/pdf')) {
                            $error = "Invalid attachment type. Only image files and PDFs are allowed.";
                        } else {
                            $new_filename = 'leave_' . bin2hex(random_bytes(8)) . '.' . $file_ext;
                            $upload_dir = UPLOAD_PATH . DIRECTORY_SEPARATOR . 'leaves';
                            if (!is_dir($upload_dir)) {
                                @mkdir($upload_dir, 0777, true);
                            }
                            $dest_path = $upload_dir . DIRECTORY_SEPARATOR . $new_filename;
                            
                            $uploaded = false;
                            if (move_uploaded_file($file_tmp, $dest_path)) {
                                $uploaded = true;
                            } else if (copy($file_tmp, $dest_path)) {
                                $uploaded = true;
                            } else if (file_put_contents($dest_path, file_get_contents($file_tmp)) !== false) {
                                $uploaded = true;
                            }
                            
                            if ($uploaded) {
                                $attachment_path = 'uploads/leaves/' . $new_filename;
                            } else {
                                $error = "Failed to save attachment to server directory. Please check folder permissions.";
                            }
                        }
                    }

                    if (empty($error)) {
                        // Save Request
                        $insert = $pdo->prepare("INSERT INTO `leave_requests` (`staff_id`, `leave_type`, `start_date`, `end_date`, `duration`, `reason`, `status`, `attachment_path`) 
                                                 VALUES (?, ?, ?, ?, ?, ?, 'Pending', ?)");
                        $insert->execute([$user_id, $leave_type, $start_date, $end_date, $duration, $reason, $attachment_path]);
                        
                        $leave_id = $pdo->lastInsertId();
                        
                        log_activity($user_id, 'LEAVE_REQUEST_SUBMITTED', "Submitted leave request ID $leave_id: $duration days of $leave_type");
                    
                    // Email HR Admins
                    $hr_stmt = $pdo->query("SELECT `email`, `first_name` FROM `staff` WHERE `role` IN ('Super Admin', 'HR Director', 'HR Manager') AND `status` = 'Active'");
                    $hr_admins = $hr_stmt->fetchAll();
                    $employee_name = $_SESSION['name'];
                    
                    $hr_subject = "New Leave Request Submitted - $employee_name";
                    $hr_body = "
                        <p>A new leave request has been submitted for review:</p>
                        <ul>
                            <li><strong>Employee:</strong> $employee_name</li>
                            <li><strong>Category:</strong> $leave_type</li>
                            <li><strong>Duration:</strong> $duration Days</li>
                            <li><strong>Date Range:</strong> " . format_date($start_date) . " to " . format_date($end_date) . "</li>
                            <li><strong>Reason:</strong> " . htmlspecialchars($reason) . "</li>
                        </ul>
                        <p>Please log in to the HR Portal Admin Panel to review and process this request.</p>
                        <p><a href='" . get_base_url() . "/admin/leave.php' class='btn'>Review Leave Request</a></p>";
                    
                    foreach ($hr_admins as $admin) {
                        send_email($admin['email'], $admin['first_name'], $hr_subject, $hr_body);
                    }
                    
                    $success = "Leave request submitted successfully! You will be notified via email once HR reviews it.";
                }
            }
        } catch (PDOException $e) {
                $error = "Failed to submit leave request: " . $e->getMessage();
            }
        }
    }
    
    // Redirect
    $redir_url = "leave.php?" . (empty($error) ? "success=" . urlencode($success) : "error=" . urlencode($error));
    header("Location: $redir_url");
    exit;
}

// Retrieve details
try {
    // 1. Fetch leave quota for current year
    $quota_stmt = $pdo->prepare("SELECT * FROM `leave_quotas` WHERE `staff_id` = ? AND `year` = ?");
    $quota_stmt->execute([$user_id, $current_year]);
    $quota = $quota_stmt->fetch();
    
    if (!$quota) {
        $default_quota = intval(get_setting('default_annual_leave_quota', 30));
        $quota = [
            'allocated' => $default_quota,
            'used' => 0,
            'remaining' => $default_quota
        ];
    }

    // 2. Fetch employee leaves history
    $leaves_stmt = $pdo->prepare("SELECT * FROM `leave_requests` WHERE `staff_id` = ? ORDER BY `id` DESC");
    $leaves_stmt->execute([$user_id]);
    $leaves = $leaves_stmt->fetchAll();

} catch (PDOException $e) {
    die("Database fetch error: " . $e->getMessage());
}

require_once '../includes/header.php';
?>

<div class="row mb-4">
    <div class="col-md-6">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-calendar-days me-2"></i>My Leave Manager</h2>
        <p class="text-muted">Apply for leave, track request statuses, and download official approval letters.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Left Column: Leave Quota & Application Form -->
    <div class="col-lg-5 col-md-6">
        <!-- Leave Quota Display -->
        <div class="card shadow-sm border-0 bg-white p-4 mb-4" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-plane-arrival me-2"></i>My Leave Allowance (<?php echo $current_year; ?>)</h5>
            <div class="row text-center my-2">
                <div class="col-4 border-end">
                    <small class="text-muted d-block small">Allocated</small>
                    <h3 class="fw-bold text-dark mb-0"><?php echo $quota['allocated']; ?></h3>
                </div>
                <div class="col-4 border-end">
                    <small class="text-muted d-block small">Used</small>
                    <h3 class="fw-bold text-danger mb-0"><?php echo $quota['used']; ?></h3>
                </div>
                <div class="col-4">
                    <small class="text-muted d-block small">Remaining</small>
                    <h3 class="fw-bold text-success mb-0"><?php echo $quota['remaining']; ?></h3>
                </div>
            </div>
        </div>

        <!-- Request Form -->
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-calendar-plus me-2"></i>Request Leave</h5>
            <form method="POST" action="leave.php" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <input type="hidden" name="action" value="request_leave">
                
                <div class="mb-3">
                    <label class="form-label fw-bold" for="leave_type">Leave Type *</label>
                    <select class="form-select" id="leave_type" name="leave_type" required>
                        <option value="">Choose Category</option>
                        <option value="Annual Leave">Annual Leave</option>
                        <option value="Sick Leave">Sick Leave</option>
                        <option value="Casual Leave">Casual Leave</option>
                        <option value="Maternity Leave">Maternity Leave</option>
                        <option value="Paternity Leave">Paternity Leave</option>
                        <option value="Emergency Leave">Emergency Leave</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="start_date">Start Date *</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-bold" for="end_date">End Date *</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="reason">Reason / Motivation *</label>
                    <textarea class="form-control" id="reason" name="reason" rows="3" placeholder="Provide complete justification context..." required></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold" for="attachment">Attach Supporting Document (Optional - PDF, Image - Max 5MB)</label>
                    <input type="file" class="form-control" id="attachment" name="attachment" accept=".pdf,.png,.jpg,.jpeg,.webp">
                </div>
                
                <button type="submit" class="btn btn-aviation w-100 py-2"><i class="fa-solid fa-calendar-check me-1"></i>Submit Application</button>
            </form>
        </div>
    </div>

    <!-- Right Column: Leave Request History -->
    <div class="col-lg-7 col-md-6">
        <div class="card shadow-sm border-0 bg-white p-4" style="border-radius:12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-clock-rotate-left me-2"></i>My Leave History</h5>
            <?php if (count($leaves) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" style="font-size:0.85rem; vertical-align:middle;">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Duration</th>
                                <th>Dates</th>
                                <th>Status</th>
                                <th class="text-end">Approval Letter</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($leaves as $leave): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($leave['leave_type']); ?></strong>
                                    </td>
                                    <td><strong><?php echo $leave['duration']; ?> Days</strong></td>
                                    <td>
                                        <?php echo format_date($leave['start_date']); ?> to <?php echo format_date($leave['end_date']); ?>
                                        <?php if (!empty($leave['hr_remarks'])): ?>
                                            <br><small class="text-secondary">Feedback: <?php echo htmlspecialchars($leave['hr_remarks']); ?></small>
                                        <?php endif; ?>
                                        <?php if (!empty($leave['attachment_path'])): ?>
                                            <?php $file_name = basename($leave['attachment_path']); ?>
                                            <div class="mt-2">
                                                <span class="d-block small text-muted mb-1"><i class="fa-solid fa-paperclip me-1"></i>Attachment:</span>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="<?php echo get_base_url() . '/' . $leave['attachment_path']; ?>" target="_blank" class="btn btn-outline-aviation py-0 px-2 btn-sm text-decoration-none" style="font-size:0.75rem;">
                                                        <i class="fa-solid fa-eye"></i> View
                                                    </a>
                                                    <a href="<?php echo get_base_url() . '/' . $leave['attachment_path']; ?>" download="<?php echo htmlspecialchars($file_name); ?>" class="btn btn-aviation py-0 px-2 btn-sm text-decoration-none" style="font-size:0.75rem;">
                                                        <i class="fa-solid fa-download"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $badge_c = 'warning';
                                        if ($leave['status'] === 'Approved') $badge_c = 'success';
                                        if ($leave['status'] === 'Rejected') $badge_c = 'danger';
                                        ?>
                                        <span class="badge bg-<?php echo $badge_c; ?>"><?php echo $leave['status']; ?></span>
                                    </td>
                                    <td class="text-end">
                                        <?php if ($leave['status'] === 'Approved'): ?>
                                            <a href="print-leave.php?id=<?php echo $leave['id']; ?>" target="_blank" class="btn btn-sm btn-outline-aviation">
                                                <i class="fa-solid fa-file-arrow-down"></i> Print/Download
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">Not Available</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-4 mb-0">No leave requests submitted yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
