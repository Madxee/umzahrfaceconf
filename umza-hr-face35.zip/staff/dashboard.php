<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Staff Dashboard Panel
 */

require_once '../includes/header.php';

$user_id = $_SESSION['user_id'];
$current_year = intval(date('Y'));
$today = date('Y-m-d');

try {
    // 1. Fetch user complete details
    $stmt = $pdo->prepare("SELECT s.*, d.name as department_name, p.title as position_title 
                           FROM `staff` s 
                           LEFT JOIN `departments` d ON s.department_id = d.id 
                           LEFT JOIN `positions` p ON s.position_id = p.id 
                           WHERE s.id = ?");
    $stmt->execute([$user_id]);
    $employee = $stmt->fetch();

    // 2. Fetch leave quota for current year
    $quota_stmt = $pdo->prepare("SELECT * FROM `leave_quotas` WHERE `staff_id` = ? AND `year` = ?");
    $quota_stmt->execute([$user_id, $current_year]);
    $quota = $quota_stmt->fetch();
    
    if (!$quota) {
        $default_quota = intval(get_setting('default_annual_leave_quota', 30));
        $quota = [
            'allocated' => $default_quota,
            'used' => 0,
            'remaining' => $default_quota
        ];
    }

    // 3. Fetch active issued queries
    $queries_stmt = $pdo->prepare("SELECT * FROM `queries` WHERE `staff_id` = ? AND `status` = 'Issued' ORDER BY `id` DESC");
    $queries_stmt->execute([$user_id]);
    $active_queries = $queries_stmt->fetchAll();

    // 4. Fetch recent memos & company news (Last 3)
    $memo_stmt = $pdo->prepare("SELECT m.*, s.first_name, s.last_name, s.display_name FROM `memos` m LEFT JOIN `staff` s ON m.created_by = s.id
                                WHERE m.status = 'Published' AND (m.audience = 'All' OR m.department_id = ?) ORDER BY m.id DESC LIMIT 3");
    $memo_stmt->execute([$_SESSION['department_id'] ?? 0]);
    $memos = $memo_stmt->fetchAll();

    // 5. Fetch recent in-app notifications
    $notif_stmt = $pdo->prepare("SELECT * FROM `notifications` WHERE `staff_id` = ? AND `is_read` = 0 ORDER BY `id` DESC LIMIT 10");
    $notif_stmt->execute([$user_id]);
    $recent_notifications = $notif_stmt->fetchAll();

    // 6. Fetch next flight schedule
    $next_flight_stmt = $pdo->prepare("SELECT * FROM `flight_schedules` WHERE `staff_id` = ? AND `departure_time` >= NOW() AND `status` = 'Scheduled' ORDER BY `departure_time` ASC LIMIT 1");
    $next_flight_stmt->execute([$user_id]);
    $next_flight = $next_flight_stmt->fetch();

    // 7. Check current attendance record for today (clock-in quick state)
    $attend_stmt = $pdo->prepare("SELECT * FROM `attendance` WHERE `staff_id` = ? AND `date` = ?");
    $attend_stmt->execute([$user_id, $today]);
    $attendance = $attend_stmt->fetch();

    // 8. Fetch aviation record details
    $rec_stmt = $pdo->prepare("SELECT * FROM `aviation_records` WHERE `staff_id` = ?");
    $rec_stmt->execute([$user_id]);
    $aviation_record = $rec_stmt->fetch();

} catch (PDOException $e) {
    die("Error loading staff dashboard details: " . $e->getMessage());
}

// Calculate countdown alert flags
$alerts = [];
if ($aviation_record) {
    if ($aviation_record['license_expiry'] && strtotime($aviation_record['license_expiry']) < strtotime($today)) {
        $alerts[] = ['type' => 'danger', 'msg' => 'YOUR PILOT/CREW LICENSE HAS EXPIRED!'];
    } elseif ($aviation_record['license_expiry'] && strtotime($aviation_record['license_expiry']) < strtotime('+30 days')) {
        $alerts[] = ['type' => 'warning', 'msg' => 'Your crew license expires in ' . round((strtotime($aviation_record['license_expiry']) - strtotime($today)) / 86400) . ' days.'];
    }
    
    if ($aviation_record['medical_expiry'] && strtotime($aviation_record['medical_expiry']) < strtotime($today)) {
        $alerts[] = ['type' => 'danger', 'msg' => 'YOUR CLASS MEDICAL CERTIFICATE HAS EXPIRED!'];
    } elseif ($aviation_record['medical_expiry'] && strtotime($aviation_record['medical_expiry']) < strtotime('+30 days')) {
        $alerts[] = ['type' => 'warning', 'msg' => 'Your medical certificate expires in ' . round((strtotime($aviation_record['medical_expiry']) - strtotime($today)) / 86400) . ' days.'];
    }
}
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="fw-bold text-aviation"><i class="fa-solid fa-table-columns me-2"></i>Staff Portal Dashboard</h2>
        <p class="text-muted">Welcome back, <strong><?php echo htmlspecialchars(display_name($employee)); ?></strong>. Have a safe flight operations day.</p>
    </div>
</div>

<!-- Warning Alerts: If issued queries are active or documents expired -->
<?php if (count($active_queries) > 0): ?>
    <div class="alert alert-danger border-0 shadow-sm mb-3 p-3 d-flex align-items-center" role="alert">
        <i class="fa-solid fa-triangle-exclamation fa-2x me-3 text-danger"></i>
        <div>
            <h6 class="alert-heading fw-bold mb-1">URGENT: DISCIPLINARY QUERY RECEIVED</h6>
            <p class="mb-0 small">You have received <strong><?php echo count($active_queries); ?></strong> formal query notice(s) from HR that require your immediate defense statement. 
               <a href="queries.php" class="alert-link text-decoration-underline fw-bold">Submit defense reply</a>.
            </p>
        </div>
    </div>
<?php endif; ?>

<?php foreach ($alerts as $alt): ?>
    <div class="alert alert-<?php echo $alt['type']; ?> border-0 shadow-sm mb-3 p-3 d-flex align-items-center" role="alert">
        <i class="fa-solid fa-plane-circle-exclamation fa-2x me-3 text-<?php echo $alt['type']; ?>"></i>
        <div>
            <h6 class="alert-heading fw-bold mb-1 text-uppercase"><?php echo $alt['type'] === 'danger' ? 'Critical Suspension Warning' : 'Document Renewal Alert'; ?></h6>
            <p class="mb-0 small"><?php echo $alt['msg']; ?> <a href="aviation.php" class="alert-link text-decoration-underline fw-bold">Update credentials</a>.</p>
        </div>
    </div>
<?php endforeach; ?>

<!-- Upper Grid: Stats Widgets -->
<div class="row g-3 mb-4">
    <!-- Card 1: Leave balance -->
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 h-100 glass-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="text-uppercase text-muted mb-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Leave Days (<?php echo $current_year; ?>)</h6>
                    <i class="fa-solid fa-calendar-alt text-aviation fs-4"></i>
                </div>
                <div class="row text-center">
                    <div class="col-4 border-end">
                        <small class="text-muted d-block" style="font-size:0.65rem;">Quota</small>
                        <h5 class="fw-bold text-dark mb-0"><?php echo $quota['allocated']; ?></h5>
                    </div>
                    <div class="col-4 border-end">
                        <small class="text-muted d-block" style="font-size:0.65rem;">Used</small>
                        <h5 class="fw-bold text-danger mb-0"><?php echo $quota['used']; ?></h5>
                    </div>
                    <div class="col-4">
                        <small class="text-muted d-block" style="font-size:0.65rem;">Left</small>
                        <h5 class="fw-bold text-success mb-0"><?php echo $quota['remaining']; ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 2: Attendance Clock Box -->
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 h-100 glass-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="text-uppercase text-muted mb-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Today's Duty Checkpoint</h6>
                    <i class="fa-solid fa-clock-pulse text-aviation fs-4"></i>
                </div>
                <div class="text-center py-1">
                    <?php if (!$attendance): ?>
                        <span class="badge bg-light text-danger border border-danger-subtle mb-2">NOT CHECKED IN</span>
                        <br><a href="attendance.php" class="btn btn-sm btn-aviation mt-1 py-1"><i class="fa-solid fa-right-to-bracket me-1"></i>Clock In Now</a>
                    <?php elseif (empty($attendance['clock_out'])): ?>
                        <span class="badge bg-light text-success border border-success-subtle mb-2">ON DUTY</span>
                        <br><a href="attendance.php" class="btn btn-sm btn-danger mt-1 py-1"><i class="fa-solid fa-right-from-bracket me-1"></i>Clock Out</a>
                    <?php else: ?>
                        <span class="badge bg-secondary mb-2">DUTY COMPLETED</span>
                        <div class="small text-muted">Clocked Out: <?php echo date('H:i', strtotime($attendance['clock_out'])); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 3: Next Flight Details -->
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 h-100 glass-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="text-uppercase text-muted mb-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Next Flight Duty</h6>
                    <i class="fa-solid fa-plane text-aviation fs-4"></i>
                </div>
                <div class="text-center">
                    <?php if ($next_flight): ?>
                        <h6 class="fw-bold mb-1 text-aviation"><?php echo htmlspecialchars($next_flight['flight_number']); ?></h6>
                        <div class="small text-dark fw-semibold">Route: <code><?php echo htmlspecialchars($next_flight['departure_airport']); ?></code> -> <code><?php echo htmlspecialchars($next_flight['arrival_airport']); ?></code></div>
                        <small class="text-muted"><?php echo format_datetime($next_flight['departure_time']); ?></small>
                    <?php else: ?>
                        <p class="text-muted small py-2 mb-0">No upcoming flights scheduled.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Card 4: Digital ID Quick Link -->
    <div class="col-md-3">
        <div class="card stat-card shadow-sm border-0 h-100 bg-aviation text-white">
            <div class="card-body d-flex flex-column justify-content-between">
                <div>
                    <h6 class="text-uppercase text-white-50 mb-1" style="font-size: 0.75rem; letter-spacing: 0.5px;">Digital ID Code</h6>
                    <h5 class="fw-bold mb-0 text-white"><?php echo htmlspecialchars($employee['staff_id']); ?></h5>
                    <small class="text-white-50"><?php echo htmlspecialchars($employee['position_title']); ?></small>
                </div>
                <div class="text-end mt-2">
                    <a href="id-card.php" class="btn btn-sm btn-light text-aviation fw-bold py-1">
                        <i class="fa-solid fa-qrcode me-1"></i>View Badge
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Section Split -->
<div class="row g-4">
    <!-- Left Column: Announcements/Memos (circulars) -->
    <div class="col-lg-8">
        <div class="card shadow-sm border-0 bg-white" style="border-radius: 16px; overflow: hidden;">
            <div class="card-header bg-aviation p-3">
                <h5 class="fw-bold text-white mb-0"><i class="fa-solid fa-bullhorn me-2"></i>Official Operations Bulletins & Memos</h5>
            </div>
            
            <div class="card-body p-4">
                <?php if (count($memos) > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($memos as $memo): ?>
                            <div class="list-group-item px-0 py-3">
                                <div class="d-flex w-100 justify-content-between align-items-center mb-1">
                                    <h6 class="mb-0 fw-bold text-aviation"><?php echo htmlspecialchars($memo['title']); ?></h6>
                                    <small class="text-secondary"><?php echo format_datetime($memo['created_at']); ?></small>
                                </div>
                                <span class="badge bg-light text-success border border-success-subtle mb-2"><?php echo htmlspecialchars($memo['type']); ?></span>
                                <p class="text-muted small mb-2"><?php echo nl2br(htmlspecialchars(substr($memo['content'], 0, 200))); ?>...</p>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="memos.php" class="text-aviation small fw-bold text-decoration-none">Read Full Bulletin <i class="fa-solid fa-arrow-right-long ms-1"></i></a>
                                    <?php if (!empty($memo['file_path'])): ?>
                                        <a href="<?php echo get_base_url() . '/' . $memo['file_path']; ?>" target="_blank" class="btn btn-sm btn-light border text-danger" style="font-size:0.75rem;">
                                            <i class="fa-solid fa-file-pdf me-1"></i>PDF File
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4 mb-0">No active company announcements found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column: Profile & Notifications -->
    <div class="col-lg-4">
        <!-- In-App Notifications List -->
        <div class="card shadow-sm border-0 bg-white p-3 mb-4" style="border-radius: 16px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3"><i class="fa-solid fa-bell me-2"></i>Notifications</h5>
            <?php if (count($recent_notifications) > 0): ?>
                <div class="list-group list-group-flush" style="max-height: 250px; overflow-y: auto;">
                    <?php foreach ($recent_notifications as $notif): ?>
                        <div class="list-group-item px-0 py-2">
                            <h6 class="fw-bold mb-0 text-aviation" style="font-size:0.85rem;"><?php echo htmlspecialchars($notif['title']); ?></h6>
                            <p class="text-muted mb-0" style="font-size:0.75rem;"><?php echo htmlspecialchars($notif['message']); ?></p>
                            <small class="text-secondary" style="font-size:0.65rem;"><?php echo format_datetime($notif['created_at']); ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-muted text-center py-3 mb-0" style="font-size:0.85rem;"><i class="fa-solid fa-bell-slash me-1"></i>No new notifications.</p>
            <?php endif; ?>
        </div>

        <!-- Personal Summary Card -->
        <div class="card shadow-sm border-0 bg-white p-3" style="border-radius: 12px;">
            <h5 class="fw-bold text-aviation border-bottom pb-2 mb-3">
                <i class="fa-solid fa-user-check me-2"></i>My Assignment
                <button class="btn btn-sm btn-outline-aviation float-end py-0 px-2" style="font-size: 0.75rem;" data-bs-toggle="modal" data-bs-target="#editNameModal">
                    <i class="fa-solid fa-user-pen"></i> Edit
                </button>
            </h5>
            <div class="text-start" style="font-size:0.85rem;">
                <p class="mb-2"><strong class="text-muted">Job Title:</strong> <span class="float-end text-dark"><?php echo htmlspecialchars($employee['position_title']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Department:</strong> <span class="float-end text-dark"><?php echo htmlspecialchars($employee['department_name']); ?></span></p>
                <p class="mb-2"><strong class="text-muted">Registered Email:</strong> <span class="float-end text-dark text-truncate" style="max-width: 150px;" title="<?php echo htmlspecialchars($employee['email']); ?>"><?php echo htmlspecialchars($employee['email']); ?></span></p>
                <p class="mb-0"><strong class="text-muted">Employment Date:</strong> <span class="float-end text-dark"><?php echo format_date($employee['employment_date']); ?></span></p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
