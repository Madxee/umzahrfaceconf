<?php
/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Resend the email-verification link
 */

require_once 'includes/auth.php';
require_once 'includes/mail.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim(strtolower($_POST['email'] ?? ''));
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = "Security validation failed. Please refresh and try again.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM `staff` WHERE `email` = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        // Same reply whether or not the address exists (privacy), except for clear cases.
        $generic = "If an unverified account exists for $email, a new verification link has been sent. Please check your inbox and Spam folder.";
        if ($user && (int)$user['email_verified'] === 1) {
            $message = "This email address is already verified. You can sign in" . ($user['status'] === 'Pending' ? " once HR approves your account." : ".");
        } elseif ($user) {
            $last = $user['verification_sent_at'] ? strtotime($user['verification_sent_at']) : 0;
            if ($last && time() - $last < 60) {
                $error = "A link was sent less than a minute ago. Please wait a moment before trying again.";
            } else {
                $token = $user['verification_token'] ?: bin2hex(random_bytes(32));
                $pdo->prepare("UPDATE `staff` SET `verification_token` = ? WHERE `id` = ?")->execute([$token, $user['id']]);
                if (send_verification_email($user['email'], display_name($user), $token)) {
                    log_activity($user['id'], 'VERIFICATION_RESENT', 'Verification email re-sent');
                    $message = $generic;
                } else {
                    $error = "The email could not be sent right now. Please contact HR to verify your account manually.";
                }
            }
        } else {
            $message = $generic;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMZA Aviation - Resend Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo get_base_url(); ?>/assets/css/style.css?v=<?php echo get_asset_version('assets/css/style.css'); ?>">
</head>
<body class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-header">
            <div class="id-card-logo-placeholder mx-auto"><i class="fa-solid fa-envelope-circle-check"></i></div>
            <h2 class="mt-2 fw-bold text-aviation">Verify Your Email</h2>
            <p class="text-muted">Get a new verification link</p>
        </div>
        <div class="auth-body">
            <?php if ($error): ?><div class="alert alert-danger border-0 shadow-sm"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            <?php if ($message): ?><div class="alert alert-success border-0 shadow-sm"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
            <form method="POST" action="resend-verification.php">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@umzaair.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                    <label for="email">Email you registered with</label>
                </div>
                <button type="submit" class="btn btn-aviation w-100 py-2 mb-3"><i class="fa-solid fa-paper-plane me-2"></i>Send Verification Link</button>
                <div class="text-center"><a href="index.php" class="text-aviation text-decoration-none"><i class="fa-solid fa-arrow-left me-1"></i>Back to Login</a></div>
            </form>
        </div>
    </div>
</body>
</html>
