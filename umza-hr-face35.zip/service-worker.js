// UMZA Aviation Services Ltd HR Portal Service Worker for PWA installation support
self.addEventListener('install', function(e) {
  // Service worker installed
});

self.addEventListener('fetch', function(e) {
  // Pass-through request fetch handler
});
