<?php
// Developer script: command line only (blocked in the browser for security)
if (php_sapi_name() !== 'cli') { http_response_code(403); exit('Forbidden'); }
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    $user_id = 5; // David Adeboye
    $leave_type = 'Annual Leave';
    $start_date = date('Y-m-d', strtotime('+5 days'));
    $end_date = date('Y-m-d', strtotime('+10 days'));
    $duration = 6;
    $reason = "Testing leave submission from CLI diagnostics script";
    
    echo "TESTING LEAVE REQUEST INSERTION...\n";
    $insert = $pdo->prepare("INSERT INTO `leave_requests` (`staff_id`, `leave_type`, `start_date`, `end_date`, `duration`, `reason`, `status`) 
                             VALUES (?, ?, ?, ?, ?, ?, 'Pending')");
    $insert->execute([$user_id, $leave_type, $start_date, $end_date, $duration, $reason]);
    echo "SUCCESS! Inserted leave request ID: " . $pdo->lastInsertId() . "\n\n";
    
    echo "TESTING COMPLAINT INSERTION...\n";
    $tracking_number = 'CMP-TEST';
    $type = 'HR Complaint';
    $title = 'Testing Grievance Submission';
    $description = 'Testing complaint submission from CLI diagnostics script';
    
    $stmt = $pdo->prepare("INSERT INTO `complaints` (`tracking_number`, `staff_id`, `type`, `title`, `description`, `status`) 
                           VALUES (?, ?, ?, ?, ?, 'Pending')");
    $stmt->execute([$tracking_number, $user_id, $type, $title, $description]);
    echo "SUCCESS! Inserted complaint ID: " . $pdo->lastInsertId() . "\n";
    
} catch (Exception $e) {
    echo "TEST FAILED: " . $e->getMessage() . "\n";
}
