/**
 * UMZA Aviation Services Ltd - HR Management Portal
 * Core Client-side JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
  // Sidebar Toggle
  const sidebarCollapse = document.getElementById('sidebarCollapse');
  const sidebar = document.getElementById('sidebar');
  if (sidebarCollapse && sidebar) {
    sidebarCollapse.addEventListener('click', function () {
      sidebar.classList.toggle('active');
    });
  }

  // Registration Form Validation (email domain is checked on the server)
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', function (e) {
      // Password Confirmation Check
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm_password').value;
      if (password !== confirmPassword) {
        e.preventDefault();
        alert('Passwords do not match. Please re-enter.');
        return false;
      }
    });
  }

  // Auto-hide alert notifications after 5 seconds
  const alerts = document.querySelectorAll('.alert-dismissible');
  alerts.forEach(function (alert) {
    setTimeout(function () {
      // Fade out effect
      alert.style.transition = 'opacity 0.5s ease';
      alert.style.opacity = '0';
      setTimeout(function () {
        alert.remove();
      }, 500);
    }, 5000);
  });

  // PWA Service Worker Registration
  if ('serviceWorker' in navigator) {
    const pathParts = window.location.pathname.split('/');
    // Get base folder (e.g. "umza-hr" or empty for root domain)
    const baseFolder = pathParts[1] && pathParts[1] !== 'admin' && pathParts[1] !== 'staff' ? '/' + pathParts[1] : '';
    navigator.serviceWorker.register(baseFolder + '/service-worker.js')
      .then(function(reg) {
        console.log('PWA Service Worker registered with scope: ', reg.scope);
      }).catch(function(err) {
        console.log('Service Worker registration failed: ', err);
      });
  }

  // Prevent form double submission
  const forms = document.querySelectorAll('form');
  forms.forEach(function (form) {
    form.addEventListener('submit', function () {
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        setTimeout(function () {
          submitBtn.disabled = true;
          const icon = submitBtn.querySelector('i');
          if (icon) {
            icon.className = 'fa-solid fa-spinner fa-spin me-1';
          } else {
            submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> ' + submitBtn.textContent;
          }
        }, 10);
      }
    });
  });
});
