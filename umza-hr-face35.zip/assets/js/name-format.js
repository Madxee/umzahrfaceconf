// Live preview of the "name to display" choices while typing first / other / last name.
(function () {
    var labels = { first: 'First', other: 'Other', last: 'Last' };
    document.querySelectorAll('select[name="name_display_format"]').forEach(function (sel) {
        var form = sel.form || document;
        function val(n) { var el = form.querySelector('[name="' + n + '"]'); return el ? el.value.trim() : ''; }
        function refresh() {
            var parts = { first: val('first_name'), other: val('other_name'), last: val('last_name') };
            Array.prototype.forEach.call(sel.options, function (opt) {
                var keys = opt.value.split('_');
                var shown = keys.map(function (k) { return parts[k] || ''; }).filter(Boolean).join(' ');
                var pattern = keys.map(function (k) { return labels[k]; }).join(' ');
                opt.textContent = (shown || pattern) + ' (' + pattern + ')';
            });
        }
        ['first_name', 'other_name', 'last_name'].forEach(function (n) {
            var el = form.querySelector('[name="' + n + '"]');
            if (el) el.addEventListener('input', refresh);
        });
        refresh();
    });
})();
