// Save the ID card (front and back) as PNG images using html2canvas.
function saveIdCards(baseName) {
    if (typeof html2canvas === 'undefined') {
        alert('Image tool is still loading. Please try again in a moment.');
        return;
    }
    var cards = document.querySelectorAll('.id-card');
    var sides = ['front', 'back'];
    var i = 0;
    function next() {
        if (i >= cards.length) return;
        var card = cards[i];
        html2canvas(card, { scale: 3, useCORS: true, backgroundColor: null }).then(function (canvas) {
            var a = document.createElement('a');
            a.download = baseName + '-' + (sides[i] || ('side' + (i + 1))) + '.png';
            a.href = canvas.toDataURL('image/png');
            document.body.appendChild(a);
            a.click();
            a.remove();
            i++;
            setTimeout(next, 400);
        });
    }
    next();
}
