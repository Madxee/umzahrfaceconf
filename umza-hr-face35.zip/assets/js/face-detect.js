// Shared face recognition helpers (registration + clock-in).
// Works on a single captured photo: press Capture, the photo is checked for a face,
// and its face pattern (descriptor) is used for recognition.
window.umzaFace = {
    modelUrl: '',
    loaded: false,
    ssdLoaded: false,
    lastError: '',
    _loading: null,

    /** Load the recognition models (with retries and a fallback for phones whose graphics chip fails). */
    /**
     * Load the recognition models. The files are first requested through face-model.php
     * (works on hosts that block .json/.bin downloads), then from the folder directly.
     * Retries and falls back to the CPU on phones whose graphics chip fails.
     */
    init(modelUrl) {
        if (this._loading) return this._loading;
        const self = this;
        const base = modelUrl.replace(/\/libs\/face-api\/model\/?$/, '');
        const sources = [base + '/face-model.php', base + '/libs/face-api/model'];
        this._loading = (async function () {
            if (typeof faceapi === 'undefined') {
                throw new Error('The face recognition file (libs/face-api/face-api.js) did not load. Check that the libs folder was uploaded.');
            }
            let lastErr = null;
            for (let attempt = 1; attempt <= 3; attempt++) {
                if (attempt === 3) {
                    // Some phones fail with the GPU backend: use the CPU instead
                    try { await faceapi.tf.setBackend('cpu'); await faceapi.tf.ready(); } catch (e) {}
                }
                for (const src of sources) {
                    try {
                        await faceapi.nets.tinyFaceDetector.loadFromUri(src);
                        await faceapi.nets.faceLandmark68Net.loadFromUri(src);
                        await faceapi.nets.faceRecognitionNet.loadFromUri(src);
                        self.modelUrl = src;
                        self.loaded = true;
                        return true;
                    } catch (e) {
                        lastErr = e;
                    }
                }
                await new Promise(r => setTimeout(r, 1200));
            }
            self._loading = null;
            self.lastError = self.explain(lastErr);
            throw new Error(self.lastError);
        })();
        return this._loading;
    },

    explain(e) {
        const msg = (e && e.message) ? e.message : String(e);
        if (/404|not found/i.test(msg)) return 'Face recognition files are missing on the server (upload the folder libs/face-api/model). Details: ' + msg;
        if (/403/.test(msg)) return 'The web server is blocking the face recognition files (403). Make sure face-model.php was uploaded. Details: ' + msg;
        if (/fetch|network|load/i.test(msg)) return 'Could not download the face recognition files from this website. Please reload the page. Details: ' + msg;
        return 'Face recognition could not start on this device. Details: ' + msg;
    },

    async loadSsd() {
        if (this.ssdLoaded) return;
        await faceapi.nets.ssdMobilenetv1.loadFromUri(this.modelUrl);
        this.ssdLoaded = true;
    },

    /** Copy the current camera frame into a canvas (not mirrored). */
    grab(video, canvas) {
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
        return canvas;
    },

    /** Average brightness 0-255 of a canvas (to reject black / not-ready camera frames). */
    brightness(canvas) {
        const w = 64, h = 48, c = document.createElement('canvas');
        c.width = w; c.height = h;
        const ctx = c.getContext('2d');
        ctx.drawImage(canvas, 0, 0, w, h);
        const d = ctx.getImageData(0, 0, w, h).data;
        let sum = 0;
        for (let i = 0; i < d.length; i += 4) sum += (d[i] + d[i + 1] + d[i + 2]) / 3;
        return sum / (w * h);
    },

    /** Find one face (with its pattern) in an image/canvas; tries several settings. Returns null if none. */
    async detect(input) {
        const tries = [
            new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.35 }),
            new faceapi.TinyFaceDetectorOptions({ inputSize: 608, scoreThreshold: 0.3 }),
            new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.3 })
        ];
        for (const opt of tries) {
            const d = await faceapi.detectSingleFace(input, opt).withFaceLandmarks().withFaceDescriptor();
            if (d) return d;
        }
        try {
            await this.loadSsd();
            const d = await faceapi.detectSingleFace(input, new faceapi.SsdMobilenetv1Options({ minConfidence: 0.25 })).withFaceLandmarks().withFaceDescriptor();
            if (d) return d;
        } catch (e) {}
        return null;
    }
};
